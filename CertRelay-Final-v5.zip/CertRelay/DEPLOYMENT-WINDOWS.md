# SSL Key Vault Portal — Windows Server deployment

## Package destination

Extract the ZIP directly to `C:\`. The project will be located at:

`C:\SSLKeyVaultMVP\Project`

The package intentionally excludes `.env`, the virtual environment, runtime database, certificates, passwords, and other secrets.

## 1. Install Python

Install 64-bit Python 3.12 on the server. During installation select **Add Python to PATH**.

Open a new PowerShell window and verify:

```powershell
python --version
python -m pip --version
```

## 2. Extract the package

Copy `SSLKeyVaultMVP-Deployment.zip` to the server, then run PowerShell as Administrator:

```powershell
Set-Location C:\
Expand-Archive -Path "$env:USERPROFILE\Downloads\SSLKeyVaultMVP-Deployment.zip" -DestinationPath C:\ -Force
Set-Location C:\SSLKeyVaultMVP\Project
Get-ChildItem
```

## 3. Permit the local deployment scripts

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
Unblock-File .\Setup-Portal.ps1
Unblock-File .\Start-Portal.ps1
```

This execution-policy change applies only to the current PowerShell process.

## 4. Create the environment and install dependencies

```powershell
.\Setup-Portal.ps1
```

The script creates `C:\SSLKeyVaultMVP\Project\.venv`, installs requirements, creates `.env` from `.env.example`, compiles the application, and runs the tests.

## 5. Configure `.env`

Generate a secret locally on the server:

```powershell
$rng = [Security.Cryptography.RandomNumberGenerator]::Create()
$bytes = New-Object byte[] 48
$rng.GetBytes($bytes)
$secret = [Convert]::ToBase64String($bytes)
$rng.Dispose()
(Get-Content .env) -replace '^APP_SECRET_KEY=.*$', "APP_SECRET_KEY=$secret" | Set-Content -Encoding ASCII .env
notepad .env
```

For Azure deployment, verify these values:

```text
APP_MODE=azure
ALLOWED_LOGIN_DOMAIN=blueshieldca.com
ADDITIONAL_LOGIN_DOMAINS=
DELIVERY_DOMAIN=bse.bscal.com
INITIAL_ADMIN_EMAIL=amalik02@blueshieldca.com
CONFIG_DB_PATH=data/portal_config.db
SMTP_HOST=<approved-relay-host>
SMTP_PORT=587
SMTP_USERNAME=<only-if-required>
SMTP_PASSWORD=<only-if-required>
SMTP_FROM=CertRelay <no-reply@blueshieldca.com>
SMTP_STARTTLS=true
```

Do not place certificate passwords, Azure client secrets, or certificates in `.env`.

## 6. Validate files and tests

```powershell
Test-Path .\.venv\Scripts\python.exe
Test-Path .\.env
Test-Path .\app\main.py
Test-Path .\app\templates\admin_login.html
Test-Path .\app\static\admin_login.js

.\.venv\Scripts\python.exe -m py_compile .\app\main.py .\app\security.py .\app\config_store.py
.\.venv\Scripts\python.exe -m pytest -q
```

Each `Test-Path` result must be `True`, and the test suite must pass.

## 7. Start the private portal listener for server testing

```powershell
.\Start-Portal.ps1
```

Uvicorn listens only on `127.0.0.1:8000`; it is not reachable remotely. From the server, open:

- User portal: `http://127.0.0.1:8000`
- Admin login: `http://127.0.0.1:8000/admin`

Press `Ctrl+C` to stop the test server.

## 8. Azure managed identity

On the Azure VM, enable **System assigned managed identity**. On each approved Key Vault, assign that VM identity the **Key Vault Certificates Officer** role.

The VM must reach the Key Vault data endpoint on TCP 443. For private endpoints, configure private DNS and routing before testing.

## 9. Configure the Admin Portal

Sign in at `/admin` using `amalik02@blueshieldca.com`, then configure:

1. Allowed login and delivery domains.
2. Actual Azure subscription names and subscription GUIDs.
3. Region tokens such as `cus` and `eus2`.
4. Exact Azure Key Vault resource names.
5. System-assigned or user-assigned managed identity.
6. OTP relay configuration.
7. OTP and idle-session timers.
8. In-memory certificate relay control.

Select an approved vault and run **Test managed identity**. Enable production transfer only after this succeeds.

## 10. Configure IIS HTTPS without port 8000 in the URL

The current hostname is set in one variable and can be changed later:

```powershell
$PortalHost = "sslrelay.bsc.bscal.com"
```

Create or update the DNS record so `$PortalHost` resolves to the VM, internal load balancer, or Application Gateway address.

Install IIS:

```powershell
Install-WindowsFeature Web-Server,Web-Mgmt-Tools -IncludeManagementTools
```

Install the approved Microsoft IIS **URL Rewrite** and **Application Request Routing (ARR)** modules. These modules are required before `web.config` can proxy traffic.

Enable ARR proxy and create the IIS site:

```powershell
Import-Module WebAdministration
$PortalHost = "sslrelay.bsc.bscal.com"
$PortalPath = "C:\SSLKeyVaultMVP\Project"
$AppCmd = "$env:windir\System32\inetsrv\appcmd.exe"

& $AppCmd set config /section:system.webServer/proxy /enabled:true /preserveHostHeader:true

if (Test-Path "IIS:\Sites\SSLRelayPortal") {
    Remove-Website -Name "SSLRelayPortal"
}
New-Website -Name "SSLRelayPortal" -PhysicalPath $PortalPath -Port 80 -HostHeader $PortalHost
& $AppCmd set config "SSLRelayPortal" /section:system.webServer/rewrite/allowedServerVariables /+"[name='HTTP_X_FORWARDED_PROTO']"
```

Import the HTTPS certificate into the Local Computer personal store. Replace the PFX path; the password prompt is secure and is not saved:

```powershell
$PfxPath = "C:\Install\sslrelay-cert.pfx"
$PfxPassword = Read-Host "PFX password" -AsSecureString
$ImportedCertificate = Import-PfxCertificate -FilePath $PfxPath -CertStoreLocation Cert:\LocalMachine\My -Password $PfxPassword
$Thumbprint = $ImportedCertificate.Thumbprint
```

Bind HTTPS using SNI:

```powershell
$PortalHost = "sslrelay.bsc.bscal.com"
if (-not (Get-WebBinding -Name "SSLRelayPortal" -Protocol https -ErrorAction SilentlyContinue)) {
    New-WebBinding -Name "SSLRelayPortal" -Protocol https -Port 443 -HostHeader $PortalHost -SslFlags 1
}
(Get-WebBinding -Name "SSLRelayPortal" -Protocol https).AddSslCertificate($Thumbprint, "My")
```

Open only HTTP/HTTPS, and explicitly remove any old portal rule for TCP 8000:

```powershell
New-NetFirewallRule -DisplayName "SSL Relay HTTPS 443" -Direction Inbound -Protocol TCP -LocalPort 443 -Action Allow -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "SSL Relay HTTP Redirect 80" -Direction Inbound -Protocol TCP -LocalPort 80 -Action Allow -ErrorAction SilentlyContinue
Remove-NetFirewallRule -DisplayName "SSL Key Vault Portal TCP 8000" -ErrorAction SilentlyContinue
```

After Uvicorn is running, browse to:

`https://sslrelay.bsc.bscal.com`

Port `8000` remains an internal loopback connection between IIS and Uvicorn. It never appears in the user URL.

### Changing the hostname later

Obtain a certificate containing the new hostname, update DNS, and change `$PortalHost` in the IIS commands. No Python source-code change is required.

## 11. Start the portal automatically after reboot

Create a Windows scheduled task running as the local system account:

```powershell
$TaskName = "SSL Key Vault Relay Portal"
$ScriptPath = "C:\SSLKeyVaultMVP\Project\Start-Portal.ps1"
$Action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$ScriptPath`""
$Trigger = New-ScheduledTaskTrigger -AtStartup
$Principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$Settings = New-ScheduledTaskSettingsSet -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Days 3650)
Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings -Force
Start-ScheduledTask -TaskName $TaskName
```

Verify the task and private listener:

```powershell
Get-ScheduledTask -TaskName "SSL Key Vault Relay Portal"
Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 8000 -State Listen
Invoke-WebRequest http://127.0.0.1:8000 -UseBasicParsing
```

## 12. Final functional test

1. Open a private browser window.
2. Confirm direct `/admin` access redirects to the separate administrator login.
3. Verify administrator OTP and logout.
4. Verify regular-user OTP and logout.
5. Leave the portal idle beyond the configured limit and confirm reauthentication is required.
6. Upload a non-production PFX certificate.
7. Review its name, SANs, issuer, and expiration.
8. Select the subscription, region, and exact matching Key Vault.
9. Confirm the transfer.
10. Verify the certificate under Azure Key Vault **Certificates**.
11. Verify the event appears in the portal's 48-hour audit view.

## Important production notes

- Certificates and passwords are processed only in request memory and are never intentionally written to disk.
- The SQLite database stores portal configuration and audit metadata only.
- The MVP's OTP and active-session state is held in one application process. Run one Uvicorn worker. A multi-worker or multi-server deployment requires a shared protected session store such as Redis.
- Back up `data\portal_config.db`; it contains configuration and audit metadata, not certificates or passwords.
