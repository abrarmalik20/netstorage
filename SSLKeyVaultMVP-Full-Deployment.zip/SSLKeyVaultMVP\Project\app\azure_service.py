# Written by AM — SSL Key Vault Certificate Relay Portal
from dataclasses import dataclass
from azure.identity import DefaultAzureCredential, ManagedIdentityCredential
from azure.mgmt.resource import SubscriptionClient
from azure.mgmt.keyvault import KeyVaultManagementClient
from azure.keyvault.certificates import CertificateClient


@dataclass(frozen=True)
class Subscription:
    id: str
    name: str


class AzureService:
    def __init__(self, settings):
        self.settings = settings
        self.credential = DefaultAzureCredential(exclude_interactive_browser_credential=True)

    def subscriptions(self) -> list[Subscription]:
        if self.settings.app_mode == "mock":
            return [Subscription("00000000-0000-0000-0000-000000000001", "bsc-npn"),
                    Subscription("00000000-0000-0000-0000-000000000002", "bsc-prd")]
        allowed = {x.lower() for x in self.settings.allowed_subscriptions}
        result = [Subscription(s.subscription_id, s.display_name) for s in SubscriptionClient(self.credential).subscriptions.list()]
        return [s for s in result if not allowed or s.name.lower() in allowed]

    @staticmethod
    def environment_token(subscription_name: str) -> str:
        """Return the first naming token after the exact `bsc-` prefix."""
        normalized = subscription_name.strip().lower()
        if not normalized.startswith("bsc-") or len(normalized) <= 4:
            raise ValueError("Subscription name must follow the bsc-<environment> naming convention.")
        return normalized[4:].split("-", 1)[0]

    @staticmethod
    def name_matches(vault_name: str, environment: str, region_token: str) -> bool:
        segments = {segment for segment in vault_name.lower().split("-") if segment}
        return environment.lower() in segments and region_token.lower() in segments

    def matching_vaults(self, subscription_id: str, subscription_name: str, region_token: str) -> list[str]:
        override = self.settings.vault_overrides.get(f"{subscription_id}|{region_token}")
        if override:
            return [override]
        environment = self.environment_token(subscription_name)
        if self.settings.app_mode == "mock":
            sample = [
                f"kv-nw-{environment}-ics-sc-{region_token}-22",
                f"kv-app-{environment}-shared-{region_token}-01",
                f"kv-nw-other-ics-sc-{region_token}-99",
                f"kv-nw-{environment}-ics-sc-other-98",
            ]
            return sorted(v for v in sample if self.name_matches(v, environment, region_token))
        vaults = list(KeyVaultManagementClient(self.credential, subscription_id).vaults.list())
        candidates = sorted(v.name for v in vaults if self.name_matches(v.name, environment, region_token))
        if not candidates:
            raise ValueError(
                f"No Key Vault matches environment '-{environment}-' and region '-{region_token}-'."
            )
        return candidates

    def import_certificate(self, vault_name: str, cert_name: str, pfx: bytes, password: bytes):
        if self.settings.app_mode == "mock":
            return {"id": f"https://{vault_name}.vault.azure.net/certificates/{cert_name}/mock-version"}
        client = CertificateClient(f"https://{vault_name}.vault.azure.net", self.credential)
        result = client.import_certificate(cert_name, pfx, password=password.decode() or None)
        return {"id": result.id}

    def relay_certificate(self, vault_name: str, cert_name: str, pfx: bytes, password: bytes,
                          production_enabled: bool, identity_type: str, client_id: str = ""):
        if not production_enabled:
            return {"id": f"https://{vault_name}.vault.azure.net/certificates/{cert_name}/mock-version"}
        credential = (ManagedIdentityCredential(client_id=client_id) if identity_type == "user" and client_id
                      else ManagedIdentityCredential())
        client = CertificateClient(f"https://{vault_name}.vault.azure.net", credential)
        result = client.import_certificate(cert_name, pfx, password=password.decode() or None)
        return {"id": result.id}

    def test_managed_identity(self, vault_name: str, identity_type: str, client_id: str = ""):
        credential = (ManagedIdentityCredential(client_id=client_id) if identity_type == "user" and client_id
                      else ManagedIdentityCredential())
        client = CertificateClient(f"https://{vault_name}.vault.azure.net", credential)
        next(iter(client.list_properties_of_certificates()), None)
        return True
