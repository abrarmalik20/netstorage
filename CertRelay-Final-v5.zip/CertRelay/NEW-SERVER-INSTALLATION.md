# CertRelay New Server Installation

Written by AM

This guide installs the CertRelay on a new Windows Server, validates it locally, connects it to Azure through the VM managed identity, and publishes it through IIS using HTTPS. The application listens privately on `127.0.0.1:8000`; users access IIS on standard HTTPS port 443, so port 8000 is never exposed in the browser URL.

## 1 Package contents and security

Extracting the deployment ZIP to `C:\` creates:

`C:\SSLKeyVaultMVP\Project`

The deployment ZIP excludes `.env`, the virtual environment, runtime database, caches, backups, logs, certificates, private keys, passwords, preshared keys, and OTP values.

The portal processes uploaded certificate bytes and passwords only in request memory. Audit records contain user identity, UTC time, action, status, subscription, region, Key Vault destination, and sanitized result codes. Certificate bytes, certificate names, thumbprints, serial numbers, passwords, private keys, preshared keys, and OTP values are not written to audit records.

## 2 Prerequisites

Complete these items before installation:

1. Use Windows Server 2019, 2022, or a later supported version.
2. Install 64-bit Python 3.12 and select Add Python to PATH.
3. Obtain an approved DNS name such as `certrelay.bsc.bscal.com`.
4. Obtain a server TLS certificate whose SAN contains the DNS name.
5. If HTTPS access by IP address is required, the certificate SAN must also contain that exact IP address. Otherwise browsers will report a certificate-name mismatch.
6. Enable a system-assigned or user-assigned managed identity on the Azure VM.
7. Grant that identity Key Vault Certificates Officer on each approved Key Vault.
8. Obtain the approved SMTP relay hostname and sender address for OTP delivery.
9. Confirm outbound TCP 443 access to Azure Key Vault and required Azure identity endpoints.

## 3 Copy and extract the package

Copy `SSLKeyVaultMVP-Full-Deployment.zip` to the new server. Open PowerShell as Administrator and run:

```powershell
Set-Location C:\
Expand-Archive `
    -LiteralPath "$env:USERPROFILE\Downloads\SSLKeyVaultMVP-Full-Deployment.zip" `
    -DestinationPath "C:\" `
    -Force

Set-Location C:\SSLKeyVaultMVP\Project
Get-ChildItem -Force
```

Confirm the core files exist:

```powershell
Test-Path .\app\main.py
Test-Path .\requirements.txt
Test-Path .\.env.example
Test-Path .\Setup-Portal.ps1
Test-Path .\Start-Portal.ps1
```

Every result must be `True`.

## 4 Verify Python

```powershell
python --version
python -m pip --version
```

If `python` is not found, close PowerShell, open a new Administrator PowerShell window, and run the commands again. If it is still missing, reinstall Python 3.12 with Add Python to PATH selected.

## 5 Run the setup script

```powershell
Set-Location C:\SSLKeyVaultMVP\Project
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
Unblock-File .\Setup-Portal.ps1
Unblock-File .\Start-Portal.ps1
.\Setup-Portal.ps1
```

The setup script creates `.venv`, upgrades pip, installs requirements, copies `.env.example` to `.env`, creates the data directory, compiles the application, and runs the automated tests.

Expected test result:

```text
8 passed
```

## 6 Configure the application secret

Generate the secret locally on the server. Do not email or copy this value to another system.

```powershell
$Rng = [Security.Cryptography.RandomNumberGenerator]::Create()
$Bytes = New-Object byte[] 48
$Rng.GetBytes($Bytes)
$Secret = [Convert]::ToBase64String($Bytes)
$Rng.Dispose()

(Get-Content .\.env) `
    -replace '^APP_SECRET_KEY=.*$', "APP_SECRET_KEY=$Secret" |
    Set-Content -Path .\.env -Encoding ASCII
```

`APP_SECRET_KEY` signs user and administrator session tokens and other short-lived application tokens. Changing it invalidates all existing sessions.

## 7 Configure production values

Open the environment file:

```powershell
notepad C:\SSLKeyVaultMVP\Project\.env
```

Set or verify:

```text
APP_MODE=azure
APP_SECRET_KEY=<generated value>
ALLOWED_LOGIN_DOMAIN=blueshieldca.com
ADDITIONAL_LOGIN_DOMAINS=
DELIVERY_DOMAIN=bse.bscal.com
INITIAL_ADMIN_EMAIL=amalik02@blueshieldca.com
CONFIG_DB_PATH=data/portal_config.db
OTP_TTL_HOURS=24
SESSION_TTL_HOURS=8
MAX_CERT_BYTES=5242880
ALLOWED_SUBSCRIPTIONS=["bsc-npn","bsc-prd"]
REGION_TOKENS={"Central US":"cus","East US 2":"eus2"}
VAULT_OVERRIDES={}
SMTP_HOST=<approved SMTP relay>
SMTP_PORT=587
SMTP_USERNAME=
SMTP_PASSWORD=
SMTP_FROM=CertRelay <no-reply@blueshieldca.com>
SMTP_STARTTLS=true
```

Remove `gmail.com` and other testing domains before production use. Do not place certificates, certificate passwords, Azure client secrets, private keys, or preshared keys in `.env`.

Operational OTP/session timers, SMTP relay enablement, audit retention, managed-identity selection, subscriptions, regions, and exact vault destinations can be managed through the protected Admin Portal.

## 8 Validate the installation

Locate the project Python executable and run validation:

```powershell
$Python = "C:\SSLKeyVaultMVP\Project\.venv\Scripts\python.exe"

Test-Path $Python
& $Python -m compileall -q app tests
& $Python -m pytest -q
```

Expected result: `8 passed`.

## 9 Test locally

```powershell
.\Start-Portal.ps1
```

From the server, open:

- User portal: `http://127.0.0.1:8000`
- Admin login: `http://127.0.0.1:8000/admin/login`

Press `Ctrl+C` in PowerShell to stop the test server.

## 10 Configure Azure managed identity

In the Azure portal:

1. Open the VM.
2. Open Identity.
3. Enable System assigned, or attach the approved user-assigned identity.
4. Open each approved Key Vault.
5. Open Access control IAM.
6. Assign Key Vault Certificates Officer to the VM identity.
7. Confirm private endpoint DNS and routing when the vault uses private access.

Do not create an Azure client secret for the application. The VM managed identity performs the certificate import.

## 11 Configure the Admin Portal

Start the portal, sign in through `/admin/login` as `amalik02@blueshieldca.com`, and configure:

1. Allowed login and OTP delivery domains.
2. Authorized users and administrators.
3. Azure subscription names and real subscription GUIDs.
4. Region tokens such as `cus` and `eus2`.
5. Exact Azure Key Vault names for each subscription and region.
6. System-assigned or user-assigned managed identity.
7. SMTP relay and OTP delivery.
8. Regular-user and administrator OTP/session timers.
9. Audit retention in hours, weeks, or 30-day months.
10. Certificate comparison and transfer-enforcement policies.

Run Test managed identity against an approved vault. Enable production transfer only after the identity test succeeds.

## 12 Install IIS and reverse-proxy components

Install IIS:

```powershell
Install-WindowsFeature Web-Server,Web-Mgmt-Tools -IncludeManagementTools
```

Install the approved Microsoft IIS URL Rewrite module and Application Request Routing module. Open IIS Manager, select the server, open Application Request Routing Cache, choose Server Proxy Settings, and enable proxy.

The supplied `web.config` redirects HTTP to HTTPS and proxies HTTPS requests internally to `http://127.0.0.1:8000`.

## 13 Create the IIS site

```powershell
Import-Module WebAdministration

$PortalHost = "certrelay.bsc.bscal.com"
$PortalPath = "C:\SSLKeyVaultMVP\Project"
$AppCmd = "$env:windir\System32\inetsrv\appcmd.exe"

& $AppCmd set config /section:system.webServer/proxy /enabled:true /preserveHostHeader:true

if (Test-Path "IIS:\Sites\SSLRelayPortal") {
    Remove-Website -Name "SSLRelayPortal"
}

New-Website `
    -Name "SSLRelayPortal" `
    -PhysicalPath $PortalPath `
    -Port 80 `
    -HostHeader $PortalHost

& $AppCmd set config "SSLRelayPortal" `
    /section:system.webServer/rewrite/allowedServerVariables `
    /+"[name='HTTP_X_FORWARDED_PROTO']"
```

Create or update DNS so `certrelay.bsc.bscal.com` resolves to the server, internal load balancer, or Application Gateway address.

## 14 Import and bind the HTTPS certificate

```powershell
$PfxPath = "C:\Install\certrelay-server.pfx"
$PfxPassword = Read-Host "TLS certificate password" -AsSecureString
$TlsCertificate = Import-PfxCertificate `
    -FilePath $PfxPath `
    -CertStoreLocation Cert:\LocalMachine\My `
    -Password $PfxPassword

$Thumbprint = $TlsCertificate.Thumbprint
$PortalHost = "certrelay.bsc.bscal.com"

New-WebBinding `
    -Name "SSLRelayPortal" `
    -Protocol https `
    -Port 443 `
    -HostHeader $PortalHost `
    -SslFlags 1

(Get-WebBinding -Name "SSLRelayPortal" -Protocol https).AddSslCertificate($Thumbprint, "My")
```

Users can now access:

`https://certrelay.bsc.bscal.com`

## 15 Optional HTTPS access by IP address

Use this only when the TLS certificate SAN contains the exact server IP address.

```powershell
New-WebBinding -Name "SSLRelayPortal" -Protocol https -IPAddress "*" -Port 443 -HostHeader "" -SslFlags 0

Push-Location IIS:\SslBindings
Get-Item "Cert:\LocalMachine\My\$Thumbprint" | New-Item "0.0.0.0!443" -Force
Pop-Location
```

Access the portal using `https://<server-ip>`. If the certificate does not contain that IP address, use the DNS URL instead.

## 16 Configure Windows Firewall

```powershell
New-NetFirewallRule `
    -DisplayName "SSL Relay HTTPS 443" `
    -Direction Inbound -Protocol TCP -LocalPort 443 -Action Allow `
    -ErrorAction SilentlyContinue

New-NetFirewallRule `
    -DisplayName "SSL Relay HTTP Redirect 80" `
    -Direction Inbound -Protocol TCP -LocalPort 80 -Action Allow `
    -ErrorAction SilentlyContinue

Remove-NetFirewallRule `
    -DisplayName "SSL Key Vault Portal TCP 8000" `
    -ErrorAction SilentlyContinue
```

Do not open inbound TCP 8000. IIS connects to it only through loopback.

## 17 Start automatically after reboot

```powershell
$TaskName = "SSL Key Vault Relay Portal"
$ScriptPath = "C:\SSLKeyVaultMVP\Project\Start-Portal.ps1"
$Action = New-ScheduledTaskAction `
    -Execute "PowerShell.exe" `
    -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$ScriptPath`""
$Trigger = New-ScheduledTaskTrigger -AtStartup
$Principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest
$TaskSettings = New-ScheduledTaskSettingsSet `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit (New-TimeSpan -Days 3650)

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action $Action `
    -Trigger $Trigger `
    -Principal $Principal `
    -Settings $TaskSettings `
    -Force

Start-ScheduledTask -TaskName $TaskName
```

Verify:

```powershell
Get-ScheduledTask -TaskName "SSL Key Vault Relay Portal"
Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 8000 -State Listen
Invoke-WebRequest http://127.0.0.1:8000 -UseBasicParsing
```

## 18 Final functional test

1. Browse to `https://certrelay.bsc.bscal.com`.
2. Request a regular-user OTP and confirm delivery by email.
3. Sign in to `/admin/login` with an administrator OTP.
4. Confirm regular users cannot open `/admin`.
5. Confirm Login audit and User activity audit are separate.
6. Confirm the configured retention period is shown and saved.
7. Run Test managed identity.
8. Upload a nonproduction test certificate and review its metadata.
9. Compare with an approved live FQDN when enabled.
10. Transfer only to the selected approved nonproduction Key Vault.
11. Confirm the destination in Azure Key Vault.
12. Confirm no certificate, password, private key, preshared key, serial number, thumbprint, or OTP value appears in the audit tables or application logs.

## 19 Create a clean ZIP from the existing server

Run these commands from the working server when creating a fresh deployment package:

```powershell
$Source = "C:\SSLKeyVaultMVP\Project"
$StageRoot = Join-Path $env:TEMP "SSLKeyVaultMVP-Package"
$StageProject = Join-Path $StageRoot "SSLKeyVaultMVP\Project"
$ZipPath = "C:\SSLKeyVaultMVP\SSLKeyVaultMVP-Full-Deployment.zip"

if (Test-Path $StageRoot) {
    Remove-Item $StageRoot -Recurse -Force
}

New-Item -ItemType Directory -Path $StageProject -Force | Out-Null

$Include = @(
    "app",
    "tests",
    ".env.example",
    ".gitignore",
    "AUTHOR.txt",
    "Dockerfile",
    "NEW-SERVER-INSTALLATION.md",
    "pyproject.toml",
    "README.md",
    "requirements.txt",
    "Setup-Portal.ps1",
    "Start-Portal.ps1",
    "web.config"
)

foreach ($Item in $Include) {
    Copy-Item (Join-Path $Source $Item) $StageProject -Recurse -Force
}

Get-ChildItem $StageProject -Directory -Recurse |
    Where-Object Name -eq "__pycache__" |
    Remove-Item -Recurse -Force

Get-ChildItem $StageProject -File -Recurse |
    Where-Object Extension -in ".pyc", ".pfx", ".p12", ".pem", ".key", ".cer" |
    Remove-Item -Force

if (Test-Path $ZipPath) {
    Remove-Item $ZipPath -Force
}

Compress-Archive `
    -Path (Join-Path $StageRoot "SSLKeyVaultMVP") `
    -DestinationPath $ZipPath `
    -CompressionLevel Optimal

Get-Item $ZipPath | Select-Object FullName, Length, LastWriteTime
```

This allow-list packaging method is safer than zipping the entire project directory because it cannot accidentally include `.env`, the runtime database, `.venv`, uploaded material, or backups.

## 20 Troubleshooting

**Python or Uvicorn is not found:** Always use `C:\SSLKeyVaultMVP\Project\.venv\Scripts\python.exe`. Run `Setup-Portal.ps1` if it does not exist.

**Requirements file is missing:** Confirm the current directory is `C:\SSLKeyVaultMVP\Project`, not `C:\SSLKeyVaultMVP`.

**The portal works locally but not through HTTPS:** Confirm Uvicorn is listening on `127.0.0.1:8000`, ARR proxy is enabled, URL Rewrite and ARR are installed, IIS bindings are correct, and Windows Firewall allows ports 80 and 443.

**Managed identity test fails:** Confirm the identity is enabled, the correct identity type is selected in Admin Portal, Key Vault Certificates Officer is assigned at the vault scope, and private DNS resolves the vault endpoint correctly.

**OTP is displayed instead of emailed:** Confirm APP_MODE is `azure`, enable OTP email relay in Admin Portal, configure the SMTP relay, and confirm the server is permitted to send through that relay.

**The browser reports a certificate-name error for IP access:** Use the DNS hostname or obtain a certificate whose SAN contains the IP address.
