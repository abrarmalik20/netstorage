# Written by AM — CertRelay
$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

Write-Host "SSL Key Vault Portal setup" -ForegroundColor Cyan

$PythonCommand = Get-Command python -ErrorAction SilentlyContinue
if (-not $PythonCommand) {
    throw "Python is not installed or is not in PATH. Install Python 3.12 (64-bit), select Add Python to PATH, and run this script again."
}

$VersionText = & python --version 2>&1
Write-Host "Detected $VersionText"

if (-not (Test-Path ".\.venv\Scripts\python.exe")) {
    Write-Host "Creating virtual environment..."
    & python -m venv .venv
}

$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
Write-Host "Updating pip..."
& $VenvPython -m pip install --upgrade pip

Write-Host "Installing dependencies..."
& $VenvPython -m pip install -r requirements.txt

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "Created .env from .env.example. Edit .env before production use." -ForegroundColor Yellow
} else {
    Write-Host "Existing .env preserved."
}

New-Item -ItemType Directory -Path "data" -Force | Out-Null

Write-Host "Checking Python files..."
& $VenvPython -m compileall -q app tests

Write-Host "Running tests..."
& $VenvPython -m pytest -q

Write-Host "Setup completed successfully." -ForegroundColor Green
Write-Host "Next: edit .env, then run .\Start-Portal.ps1"
