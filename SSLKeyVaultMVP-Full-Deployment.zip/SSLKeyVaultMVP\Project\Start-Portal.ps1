# Written by AM — SSL Key Vault Certificate Relay Portal
$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"

if (-not (Test-Path $VenvPython)) {
    throw "Virtual environment is missing. Run .\Setup-Portal.ps1 first."
}
if (-not (Test-Path (Join-Path $ProjectRoot ".env"))) {
    throw ".env is missing. Run .\Setup-Portal.ps1 first, then configure .env."
}

Set-Location $ProjectRoot
Write-Host "Starting private application listener on http://127.0.0.1:8000" -ForegroundColor Cyan
& $VenvPython -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --proxy-headers --forwarded-allow-ips 127.0.0.1
