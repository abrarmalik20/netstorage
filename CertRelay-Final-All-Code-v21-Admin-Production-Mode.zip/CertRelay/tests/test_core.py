# Written by AM — CertRelay
from datetime import datetime, timedelta, timezone
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
from app.certificates import inspect_certificate, prepare_as_pfx
from app.security import (OneTimeCodeStore, certificate_name_from_common_name,
                          normalize_authorized_email, safe_certificate_name)
from app.azure_service import AzureService
from app.config_store import ConfigStore
from app.live_compare import compare_metadata, comparison_policy_blockers, hostname_covered, normalize_fqdn
from app.assistant_service import knowledge_excerpt, knowledge_match, redact


def test_domain_enforced():
    domains = ["blueshieldca.com", "gmail.com"]
    assert normalize_authorized_email("User@blueshieldca.com", domains) == "user@blueshieldca.com"
    assert normalize_authorized_email("Tester@gmail.com", domains) == "tester@gmail.com"
    try: normalize_authorized_email("user@yahoo.com", domains); assert False
    except ValueError: pass


def test_otp_one_time():
    store = OneTimeCodeStore("a" * 32, 24); code = store.issue("u@blueshieldca.com")
    assert store.verify("u@blueshieldca.com", code)
    assert not store.verify("u@blueshieldca.com", code)


def test_name_validation():
    assert safe_certificate_name("API-Cert-01") == "api-cert-01"
    assert certificate_name_from_common_name("webtestcert.bsc.bscal.com") == "webtestcert-bsc-bscal-com"
    assert certificate_name_from_common_name("*.BSC.BSCAL.COM") == "wildcard-bsc-bscal-com"


def test_pem_converts_to_pfx():
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "api.example.com")])
    cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(issuer).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(days=1))
            .not_valid_after(datetime.now(timezone.utc)+timedelta(days=30)).sign(key, hashes.SHA256()))
    pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()) + cert.public_bytes(serialization.Encoding.PEM)
    result = prepare_as_pfx(pem, "bundle.pem", "")
    assert result.pfx and result.password and result.common_name == "api.example.com"
    metadata = inspect_certificate(result.pfx, "bundle.pfx", result.password.decode())
    assert metadata["common_name"] == "api.example.com"
    assert metadata["expires_utc"] and metadata["issuer"]
    assert len(metadata["sha256_thumbprint"]) == 64


def test_vault_name_filter_uses_exact_environment_and_region_segments():
    assert AzureService.environment_token("bsc-npn") == "npn"
    assert AzureService.name_matches("kv-nw-npn-ics-sc-cus-22", "npn", "cus")
    assert AzureService.name_matches("kv-app-npn-shared-cus-01", "npn", "cus")
    assert not AzureService.name_matches("kv-nw-npn-ics-sc-eus2-22", "npn", "cus")
    assert not AzureService.name_matches("kv-nw-npnext-ics-sc-cus-22", "npn", "cus")


def test_key_vault_certificate_name_reuses_exact_cn_match():
    result = AzureService.choose_certificate_name(
        "WebTestCert.BSC.BSCAL.COM.",
        [("application-gateway-tls", "webtestcert.bsc.bscal.com"),
         ("unrelated-certificate", "other.bsc.bscal.com")],
        "webtestcert-bsc-bscal-com",
    )
    assert result == {"name": "application-gateway-tls", "matched_existing": True}


def test_key_vault_certificate_name_uses_cn_when_no_match_exists():
    result = AzureService.choose_certificate_name(
        "new.bsc.bscal.com",
        [("existing-application", "old.bsc.bscal.com")],
        "new-bsc-bscal-com",
    )
    assert result == {"name": "new-bsc-bscal-com", "matched_existing": False}


def test_key_vault_certificate_name_blocks_ambiguous_cn_matches():
    try:
        AzureService.choose_certificate_name(
            "api.bsc.bscal.com",
            [("api-listener-one", "api.bsc.bscal.com"),
             ("api-listener-two", "API.BSC.BSCAL.COM")],
            "api-bsc-bscal-com",
        )
        assert False
    except ValueError as exc:
        assert "More than one Key Vault certificate" in str(exc)


def test_key_vault_certificate_name_blocks_unrelated_name_collision():
    try:
        AzureService.choose_certificate_name(
            "new.bsc.bscal.com",
            [("new-bsc-bscal-com", "different.bsc.bscal.com")],
            "new-bsc-bscal-com",
        )
        assert False
    except ValueError as exc:
        assert "prevent updating the wrong certificate object" in str(exc)


def test_mock_mode_labels_key_vault_lookup_as_not_performed():
    service = AzureService.__new__(AzureService)
    service.settings = type("MockSettings", (), {"app_mode": "mock"})()
    result = service.resolve_certificate_name(
        "kv-test", "webtestcert.bsc.bscl.com", "webtestcert-bsc-bscl-com", "system")
    assert result == {"name": "webtestcert-bsc-bscl-com",
                      "matched_existing": False,
                      "lookup_performed": False}


def test_production_setting_overrides_bootstrap_mock_for_azure_lookup(monkeypatch):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([x509.NameAttribute(
        NameOID.COMMON_NAME, "webtestcert.bsc.bscl.com")])
    cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(subject)
            .public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(datetime.now(timezone.utc) - timedelta(days=1))
            .not_valid_after(datetime.now(timezone.utc) + timedelta(days=30))
            .sign(key, hashes.SHA256()))
    der = cert.public_bytes(serialization.Encoding.DER)

    class FakeCertificateClient:
        def __init__(self, *_args, **_kwargs):
            pass

        def list_properties_of_certificates(self):
            return [type("Properties", (), {"name": "application-gateway-tls"})()]

        def get_certificate(self, _name):
            return type("Current", (), {"cer": der})()

    monkeypatch.setattr("app.azure_service.CertificateClient", FakeCertificateClient)
    monkeypatch.setattr(
        AzureService, "_managed_credential",
        staticmethod(lambda _identity_type, _client_id="": object()))
    service = AzureService.__new__(AzureService)
    service.settings = type("MockSettings", (), {"app_mode": "mock"})()
    result = service.resolve_certificate_name(
        "kv-test", "webtestcert.bsc.bscl.com", "webtestcert-bsc-bscl-com",
        "system", production_enabled=True)
    assert result == {"name": "application-gateway-tls",
                      "matched_existing": True,
                      "lookup_performed": True}


def test_live_certificate_comparison_highlights_missing_and_additional_names():
    future = (datetime.now(timezone.utc) + timedelta(days=90)).isoformat()
    later = (datetime.now(timezone.utc) + timedelta(days=365)).isoformat()
    live = {"sans": ["api.bsc.bscal.com", "legacy.bsc.bscal.com"], "common_name": "api.bsc.bscal.com",
            "expires_utc": future, "key_size": 2048, "issuer": "CN=Old CA", "key_type": "RSA",
            "serial_number": "ABC123"}
    new = {"sans": ["api.bsc.bscal.com", "new.bsc.bscal.com"], "common_name": "api.bsc.bscal.com",
           "expires_utc": later, "key_size": 2048, "issuer": "CN=New CA", "key_type": "RSA",
           "serial_number": "ABC123"}
    result = compare_metadata("api.bsc.bscal.com", live, new)
    assert result["missing_in_new"] == ["legacy.bsc.bscal.com"]
    assert result["additional_in_new"] == ["new.bsc.bscal.com"]
    assert result["new_covers_fqdn"] is True
    assert result["result"] == "review"
    differences = {item["field"]: item for item in result["field_differences"]}
    assert differences["issuer"]["live_value"] == "CN=Old CA"
    assert differences["issuer"]["new_value"] == "CN=New CA"
    assert differences["issuer"]["severity"] == "review"
    assert differences["expires_utc"]["severity"] == "information"
    assert "key_type" not in differences
    assert "different certificate authority" in " ".join(result["warnings"])
    assert result["issuer_matches"] is False
    assert result["serial_numbers_match"] is True
    blockers = comparison_policy_blockers(result, {
        "live_compare_block_issuer_mismatch": True,
        "live_compare_block_missing_names": True,
        "live_compare_block_same_serial": True,
    })
    assert len(blockers) == 3


def test_live_comparison_fqdn_allowlist_and_wildcard_matching():
    assert normalize_fqdn("App.BSC.BSCAL.COM.", ["bsc.bscal.com"]) == "app.bsc.bscal.com"
    assert hostname_covered("app.bsc.bscal.com", ["*.bsc.bscal.com"])
    assert not hostname_covered("deep.app.bsc.bscal.com", ["*.bsc.bscal.com"])
    try:
        normalize_fqdn("example.com", ["bsc.bscal.com"])
        assert False
    except ValueError:
        pass


def test_admin_store_users_domains_and_destinations(tmp_path):
    store = ConfigStore(str(tmp_path / "portal.db"), "amalik02@blueshieldca.com")
    assert store.one("users", "amalik02@blueshieldca.com")["role"] == "admin"
    store.upsert("domains", {"domain": "bsc.bscal.com", "delivery_domain": "bsc.bscal.com", "active": 1})
    store.upsert("users", {"email": "engineer@bsc.bscal.com", "role": "user", "active": 1})
    assert store.one("users", "engineer@bsc.bscal.com")["role"] == "user"
    assert store.matching_vaults("00000000-0000-0000-0000-000000000001", "cus") == ["kv-nw-npn-ics-sc-cus-22"]
    replacement_id = "11111111-1111-1111-1111-111111111111"
    store.save_subscription(replacement_id, "bsc-npn", "npn",
                            "00000000-0000-0000-0000-000000000001")
    assert store.one("subscriptions", replacement_id)["name"] == "bsc-npn"
    assert store.one("subscriptions", "00000000-0000-0000-0000-000000000001") is None
    assert store.matching_vaults(replacement_id, "cus") == ["kv-nw-npn-ics-sc-cus-22"]
    store.save_region("centralus", "Central US", "cus")
    assert store.one("regions", "cus") is None
    assert store.matching_vaults(replacement_id, "centralus") == ["kv-nw-npn-ics-sc-cus-22"]
    store.save_vault("kv-nw-npn-ics-sc-centralus-22", replacement_id, "centralus",
                     "kv-nw-npn-ics-sc-cus-22")
    assert store.one("vaults", "kv-nw-npn-ics-sc-cus-22") is None
    assert store.matching_vaults(replacement_id, "centralus") == ["kv-nw-npn-ics-sc-centralus-22"]
    store.update_settings({"relay_enabled": True, "certificate_fields": ["issuer", "expires_utc"]})
    assert store.settings()["relay_enabled"] is True
    assert store.settings()["live_compare_enabled"] is True
    assert store.settings()["live_compare_allowed_suffixes"] == ["bsc.bscal.com"]
    store.update_settings({"live_compare_block_issuer_mismatch": True,
                           "live_compare_block_missing_names": True,
                           "live_compare_block_same_serial": True})
    assert store.settings()["live_compare_block_same_serial"] is True
    store.add_audit(user_email="engineer@bsc.bscal.com", action="transfer", status="success",
                    vault_name="kv-nw-npn-ics-sc-cus-22")
    assert store.audit_history()[0]["certificate_name"] is None
    store.update_settings({"audit_retention_value": 2, "audit_retention_unit": "weeks"})
    assert store.settings()["audit_retention_value"] == 2
    assert store.settings()["audit_retention_unit"] == "weeks"
    store.clear_audit()
    assert store.audit_last_48_hours() == []


def test_certificate_name_history_and_retention(tmp_path):
    store = ConfigStore(str(tmp_path / "portal.db"), "amalik02@blueshieldca.com")
    first = store.next_certificate_name("api.bsc.bscal.com")
    assert first["name"].endswith("-01")
    assert first["previous_name"] is None
    store.add_certificate_history(
        common_name="api.bsc.bscal.com", generated_name=first["name"],
        user_email="engineer@blueshieldca.com", subscription_name="bsc-npn",
        region="cus", vault_name="kv-nw-npn-ics-sc-cus-22", ticket_number="CHG0012345",
        expires_utc="2027-12-31T23:59:59+00:00",
    )
    second = store.next_certificate_name("api.bsc.bscal.com")
    assert second["name"].endswith("-02")
    assert second["previous_name"] == first["name"]
    rows = store.search_certificate_history("api.bsc")
    assert len(rows) == 1
    assert rows[0]["user_email"] == "engineer@blueshieldca.com"
    assert rows[0]["ticket_number"] == "CHG0012345"
    assert rows[0]["expires_utc"].startswith("2027-12-31")
    assert store.certificate_report(1)[0]["generated_name"] == first["name"]
    assert len(store.search_certificate_history("chg0012345")) == 1
    assert store.settings()["approved_ticket_required"] is False
    store.update_settings({"approved_ticket_required": True})
    assert store.settings()["approved_ticket_required"] is True
    store.update_settings({"smp_enabled": True, "smp_required": True,
                           "smp_api_url": "https://smp.example.com/api",
                           "smp_credential_vault": "kv-certrelay-secrets"})
    assert store.settings()["smp_required"] is True
    store.update_settings({"certificate_history_retention_years": 3})
    assert store.settings()["certificate_history_retention_years"] == 3
    try:
        store.update_settings({"certificate_history_retention_years": 4})
        assert False
    except ValueError:
        pass


def test_cn_only_naming_reuses_name_and_keeps_history(tmp_path):
    store = ConfigStore(str(tmp_path / "portal.db"), "amalik02@blueshieldca.com")
    first = store.certificate_name("api.bsc.bscal.com", append_year_sequence=False)
    assert first["name"] == "api-bsc-bscal-com"
    store.add_certificate_history(
        common_name="api.bsc.bscal.com", generated_name=first["name"],
        user_email="user@blueshieldca.com", subscription_name="bsc-npn",
        region="cus", vault_name="kv-nw-npn-ics-sc-cus-22")
    second = store.certificate_name("api.bsc.bscal.com", append_year_sequence=False)
    assert second["name"] == first["name"]
    store.add_certificate_history(
        common_name="api.bsc.bscal.com", generated_name=second["name"],
        user_email="user@blueshieldca.com", subscription_name="bsc-npn",
        region="cus", vault_name="kv-nw-npn-ics-sc-cus-22")
    assert len(store.search_certificate_history("api-bsc-bscal-com")) == 2


def test_assistant_knowledge_role_filter_and_redaction(tmp_path):
    store = ConfigStore(str(tmp_path / "portal.db"), "amalik02@blueshieldca.com")
    store.save_assistant_knowledge(title="Upload certificate", content="Inspect, select a vault, and confirm.",
                                   audience="all", source_type="qa")
    store.save_assistant_knowledge(title="SMTP administrator steps", content="Configure the relay in Admin.",
                                   audience="admin", source_type="document")
    assert store.assistant_knowledge("user", "upload certificate")[0]["title"] == "Upload certificate"
    assert all(item["audience"] != "admin" for item in store.assistant_knowledge("user", "SMTP administrator"))
    assert store.assistant_knowledge("admin", "SMTP administrator")[0]["audience"] == "admin"
    safe = redact("password=secret123 otp: 123456\n-----BEGIN PRIVATE KEY-----\nabc\n-----END PRIVATE KEY-----")
    assert "secret123" not in safe and "123456" not in safe and "abc" not in safe


def test_assistant_extracts_one_matching_document_section():
    item = {"source_type": "document", "content": "# Guide\nIntro\n## Upload certificate\nSelect the file and inspect it.\n## SMTP settings\nConfigure the approved relay."}
    answer = knowledge_excerpt(item, "How do I upload a certificate?")
    assert "Upload certificate" in answer
    assert "Select the file" in answer
    assert "SMTP settings" not in answer


def test_assistant_error_question_prefers_troubleshooting_section():
    item = {"source_type": "document", "content": "## What is a certificate password?\nIt decrypts a PFX.\n## Why do I receive a password error?\nConfirm the PFX password and file integrity."}
    answer = knowledge_excerpt(item, "I am getting an invalid password error")
    assert "Why do I receive a password error" in answer
    assert "file integrity" in answer
    assert "What is a certificate password" not in answer


def test_assistant_rejects_unrelated_approved_answer():
    item = {"title": "Certificate decoding error", "source_type": "document",
            "content": "## Why can a certificate not be decoded?\nCheck the PFX password and file format."}
    match = knowledge_match(item, "I cannot find the key vault")
    assert match["confident"] is False
    assert match["text"] == ""


def test_assistant_close_match_tolerates_key_vault_typo():
    item = {"title": "CertRelay user guide", "source_type": "document",
            "content": "## Why are no matching Key Vaults displayed?\nCheck the subscription and region mapping.\n"
                       "## Certificate password errors\nCheck the uploaded PFX password."}
    match = knowledge_match(item, "I can not find the key valut")
    assert match["confident"] is True
    assert "matching Key Vaults" in match["text"]
    assert "password errors" not in match["text"]


def test_assistant_does_not_turn_general_inspect_question_into_decode_error():
    item = {"title": "CertRelay user guide", "source_type": "document",
            "content": "## Why does certificate inspection say the file cannot be decoded?\n"
                       "The password or file format may be incorrect."}
    match = knowledge_match(item, "what is inspect certificate")
    assert match["confident"] is False
    assert match["text"] == ""


def test_admin_delete_protects_linked_destinations(tmp_path):
    store = ConfigStore(str(tmp_path / "portal.db"), "amalik02@blueshieldca.com")
    try:
        store.delete("subscriptions", "00000000-0000-0000-0000-000000000001")
        assert False
    except ValueError as exc:
        assert "linked Key Vault" in str(exc)
    store.delete("vaults", "kv-nw-npn-ics-sc-cus-22")
    store.delete("subscriptions", "00000000-0000-0000-0000-000000000001")
    assert store.one("subscriptions", "00000000-0000-0000-0000-000000000001") is None


def test_session_survives_store_reopen_without_storing_raw_token(tmp_path):
    path = str(tmp_path / "portal.db")
    store = ConfigStore(path, "amalik02@blueshieldca.com")
    token = "signed-session-token-that-must-not-be-stored"
    store.create_session(token, "engineer@blueshieldca.com", "user", 3600)
    reopened = ConfigStore(path, "amalik02@blueshieldca.com")
    assert reopened.touch_session(token, "engineer@blueshieldca.com", "user", 900)
    with reopened._connect() as db:
        row = db.execute("SELECT token_hash FROM portal_sessions").fetchone()
        assert row["token_hash"] != token
    reopened.delete_session(token)
    assert not reopened.touch_session(token, "engineer@blueshieldca.com", "user", 900)
