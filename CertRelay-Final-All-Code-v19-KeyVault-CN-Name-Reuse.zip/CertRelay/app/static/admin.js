/* Written by AM — CertRelay */
const $ = id => document.getElementById(id);
async function api(url, body) {
  const response = await fetch(url, {method: body ? 'POST' : 'GET', headers: body ? {'Content-Type': 'application/json'} : {}, body: body ? JSON.stringify(body) : undefined});
  const data = await response.json();
  if (!response.ok) throw new Error(data.detail || 'Request failed');
  return data;
}
const keys = {domains: 'domain', users: 'email', subscriptions: 'id', regions: 'token', vaults: 'name'};
const allFields = {common_name: 'Certificate name', sans: 'Subdomains / SANs', issuer: 'Issuer', expires_utc: 'Expiration date', days_remaining: 'Days remaining', not_before_utc: 'Valid from', subject: 'Subject', serial_number: 'Serial number', sha256_thumbprint: 'SHA-256 thumbprint', key_type: 'Key type', key_size: 'Key size', chain_count: 'Chain certificates'};
function fill(select, items) { select.innerHTML = ''; items.forEach(([label, value]) => select.add(new Option(label, value))); }
function rowList(kind, rows) {
  const target = $(kind); target.innerHTML = '';
  rows.forEach(row => {
    const line = document.createElement('div'); line.className = 'admin-row';
    const label = document.createElement('span'); label.textContent = Object.entries(row).filter(([key]) => key !== 'active').map(([, value]) => value).join(' · ');
    const actions = document.createElement('div'); actions.className = 'admin-actions';
    const edit = document.createElement('button'); edit.type = 'button'; edit.className = 'secondary'; edit.textContent = 'Edit';
      edit.onclick = () => {
        const form = document.querySelector(`form[data-kind="${kind}"]`);
        if (kind === 'domains') {
          form.elements.domain.value = row.domain;
          form.elements.delivery_domain.value = row.delivery_domain;
        } else if (kind === 'users') {
          form.elements.email.value = row.email;
          form.elements.role.value = row.role;
        } else if (kind === 'subscriptions') {
          form.elements.original_id.value = row.id;
          form.elements.id.value = row.id;
          form.elements.name.value = row.name;
          form.elements.environment.value = row.environment;
        } else if (kind === 'regions') {
          form.elements.original_token.value = row.token;
          form.elements.token.value = row.token;
          form.elements.display_name.value = row.display_name;
        } else {
          form.elements.original_name.value = row.name;
          form.elements.name.value = row.name;
          form.elements.subscription_id.value = row.subscription_id;
          form.elements.region.value = row.region_token;
        }
        form.scrollIntoView({behavior: 'smooth', block: 'center'});
        (form.elements.domain || form.elements.email || form.elements.id || form.elements.token || form.elements.name).focus();
      };
    const button = document.createElement('button'); button.textContent = row.active ? 'Deactivate' : 'Activate';
    button.onclick = async () => { await api('/api/admin/active', {table: kind, key: row[keys[kind]], active: !row.active}); await load(); };
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'danger'; remove.textContent = 'Delete';
    remove.onclick = async () => {
      const key = row[keys[kind]];
      if (!confirm(`Permanently delete ${kind.slice(0, -1)} "${key}"?`)) return;
      try { await api('/api/admin/delete', {table: kind, key}); $('adminStatus').textContent = 'Deleted successfully.'; await load(); }
      catch (error) { $('adminStatus').textContent = error.message; }
    };
    actions.append(edit, button, remove);
    line.append(label, actions); target.append(line);
  });
}
function auditRow(target, values) { const row = document.createElement('tr'); values.forEach(value => { const cell = document.createElement('td'); cell.textContent = value ?? ''; row.append(cell); }); target.append(row); }
function renderKnowledge(rows){const target=$('assistantKnowledgeList');target.innerHTML='';rows.forEach(item=>{const line=document.createElement('div');line.className='admin-row';const label=document.createElement('span');label.textContent=`${item.title} · ${item.audience} · ${item.source_type}`;const actions=document.createElement('div');actions.className='admin-actions';const edit=document.createElement('button');edit.type='button';edit.className='secondary';edit.textContent='Edit';edit.onclick=()=>{$('knowledgeId').value=item.id;$('knowledgeTitle').value=item.title;$('knowledgeAudience').value=item.audience;$('knowledgeType').value=item.source_type;$('knowledgeContent').value=item.content;$('assistantKnowledgeForm').scrollIntoView({behavior:'smooth'})};const remove=document.createElement('button');remove.type='button';remove.className='danger';remove.textContent='Delete';remove.onclick=async()=>{if(confirm(`Delete approved knowledge "${item.title}"?`)){await api('/api/admin/assistant/knowledge/delete',{id:item.id});await load()}};actions.append(edit,remove);line.append(label,actions);target.append(line)})}
async function load() {
  const data = await api('/api/admin/config');
  Object.keys(keys).forEach(key => rowList(key, data[key]));
  fill($('adminSub'), data.subscriptions.filter(x => x.active).map(x => [x.name, x.id]));
  fill($('adminRegion'), data.regions.filter(x => x.active).map(x => [x.display_name, x.token]));
  fill($('identityVault'), data.vaults.filter(x => x.active).map(x => [x.name, x.name]));
  const settings = data.settings;
  const values = {certificateHistoryYears: settings.certificate_history_retention_years || 2, smtpHost: settings.smtp_host || '', smtpPort: settings.smtp_port || 587, smtpFrom: settings.smtp_from || '', identityType: settings.managed_identity_type || 'system', identityClientId: settings.managed_identity_client_id || '', userOtpMinutes: settings.user_otp_minutes || 15, userIdleMinutes: settings.user_idle_minutes || 15, adminOtpMinutes: settings.admin_otp_minutes || 10, adminIdleMinutes: settings.admin_idle_minutes || 15, auditRetentionValue: settings.audit_retention_value || 48, auditRetentionUnit: settings.audit_retention_unit || 'hours', liveCompareSuffixes: (settings.live_compare_allowed_suffixes || []).join(', '), liveCompareTimeout: settings.live_compare_timeout_seconds || 5, smpApiUrl: settings.smp_api_url || '', smpAuthType: settings.smp_auth_type || 'token', smpCredentialVault: settings.smp_credential_vault || '', smpTokenSecretName: settings.smp_token_secret_name || '', smpUsernameSecretName: settings.smp_username_secret_name || '', smpPasswordSecretName: settings.smp_password_secret_name || '', smpApprovedStatuses: (settings.smp_approved_statuses || ['approved']).join(', '), aiAnswerMode: settings.ai_answer_mode || 'approved_plus_external', aiProvider: settings.ai_provider || 'none', aiCredentialVault: settings.ai_credential_vault || '', openaiSecretName: settings.openai_api_key_secret_name || '', openaiModel: settings.openai_model || 'gpt-4.1-mini', copilotSecretName: settings.copilot_directline_secret_name || '', copilotDirectlineUrl: settings.copilot_directline_url || 'https://directline.botframework.com/v3/directline'};
  Object.entries(values).forEach(([id, value]) => { $(id).value = value; });
  const checks = {productionEnabled: settings.production_enabled, relayEnabled: settings.relay_enabled, approvedTicketRequired: settings.approved_ticket_required, userChatbotEnabled: settings.user_chatbot_enabled, adminChatbotEnabled: settings.admin_chatbot_enabled, aiAllowTroubleshooting: settings.ai_allow_troubleshooting !== false, aiAllowAuditReports: settings.ai_allow_audit_reports !== false, smpEnabled: settings.smp_enabled, smpRequired: settings.smp_required, smtpTls: settings.smtp_starttls, memoryRelayEnabled: settings.memory_relay_enabled !== false, liveCompareEnabled: settings.live_compare_enabled !== false, liveCompareRequired: settings.live_compare_required, liveCompareAllowPrivate: settings.live_compare_allow_private !== false, blockIssuerMismatch: settings.live_compare_block_issuer_mismatch, blockMissingNames: settings.live_compare_block_missing_names, blockSameSerial: settings.live_compare_block_same_serial};
  Object.entries(checks).forEach(([id, value]) => { $(id).checked = !!value; });
  const choices = $('fieldChoices'); choices.innerHTML = '';
  Object.entries(allFields).forEach(([key, label]) => { const wrap = document.createElement('label'); const box = document.createElement('input'); box.type = 'checkbox'; box.value = key; box.checked = (settings.certificate_fields || []).includes(key); wrap.append(box, document.createTextNode(' ' + label)); choices.append(wrap); });
  const loginBody = $('loginAuditRows'), activityBody = $('activityAuditRows');
  const loginActions = new Set(['user_otp_request', 'user_login', 'user_logout', 'admin_login', 'admin_logout']);
  loginBody.innerHTML = ''; activityBody.innerHTML = '';
  data.audit.forEach(entry => {
    if (loginActions.has(entry.action)) auditRow(loginBody, [entry.occurred_utc, entry.user_email, entry.action, entry.status, entry.detail || '']);
    else auditRow(activityBody, [entry.occurred_utc, entry.user_email, entry.action, entry.vault_name || '', entry.status, entry.detail || '']);
  });
  renderKnowledge(data.assistant_knowledge || []);
  window.certRelayAssistant?.show(!!settings.admin_chatbot_enabled, data.current_admin || '');
}
document.querySelectorAll('form[data-kind]').forEach(form => form.onsubmit = async event => {
  event.preventDefault();
  try { await api('/api/admin/' + form.dataset.kind, Object.fromEntries(new FormData(form))); $('adminStatus').textContent = 'Saved successfully.'; form.reset(); await load(); }
  catch (error) { $('adminStatus').textContent = error.message; }
});
$('settingsForm').onsubmit = async event => {
  event.preventDefault(); const button = $('saveSettings'), message = $('settingsStatus'); button.disabled = true; button.textContent = 'Saving...'; message.textContent = '';
  try {
    await api('/api/admin/settings', {certificate_history_retention_years: Number($('certificateHistoryYears').value), production_enabled: $('productionEnabled').checked, relay_enabled: $('relayEnabled').checked, approved_ticket_required: $('approvedTicketRequired').checked, smp_enabled: $('smpEnabled').checked, smp_required: $('smpRequired').checked, smp_api_url: $('smpApiUrl').value, smp_auth_type: $('smpAuthType').value, smp_credential_vault: $('smpCredentialVault').value, smp_token_secret_name: $('smpTokenSecretName').value, smp_username_secret_name: $('smpUsernameSecretName').value, smp_password_secret_name: $('smpPasswordSecretName').value, smp_approved_statuses: $('smpApprovedStatuses').value.split(',').map(x=>x.trim()).filter(Boolean), smtp_host: $('smtpHost').value, smtp_port: Number($('smtpPort').value), smtp_from: $('smtpFrom').value, smtp_starttls: $('smtpTls').checked, managed_identity_type: $('identityType').value, managed_identity_client_id: $('identityClientId').value, user_otp_minutes: Number($('userOtpMinutes').value), user_idle_minutes: Number($('userIdleMinutes').value), admin_otp_minutes: Number($('adminOtpMinutes').value), admin_idle_minutes: Number($('adminIdleMinutes').value), audit_retention_value: Number($('auditRetentionValue').value), audit_retention_unit: $('auditRetentionUnit').value, memory_relay_enabled: $('memoryRelayEnabled').checked, live_compare_enabled: $('liveCompareEnabled').checked, live_compare_required: $('liveCompareRequired').checked, live_compare_allowed_suffixes: $('liveCompareSuffixes').value.split(',').map(x => x.trim()).filter(Boolean), live_compare_timeout_seconds: Number($('liveCompareTimeout').value), live_compare_allow_private: $('liveCompareAllowPrivate').checked, live_compare_block_issuer_mismatch: $('blockIssuerMismatch').checked, live_compare_block_missing_names: $('blockMissingNames').checked, live_compare_block_same_serial: $('blockSameSerial').checked, certificate_fields: [...$('fieldChoices').querySelectorAll('input:checked')].map(x => x.value)});
    await api('/api/admin/settings', {user_chatbot_enabled: $('userChatbotEnabled').checked, admin_chatbot_enabled: $('adminChatbotEnabled').checked, ai_answer_mode: $('aiAnswerMode').value, ai_provider: $('aiProvider').value, ai_credential_vault: $('aiCredentialVault').value, openai_api_key_secret_name: $('openaiSecretName').value, openai_model: $('openaiModel').value, copilot_directline_secret_name: $('copilotSecretName').value, copilot_directline_url: $('copilotDirectlineUrl').value, ai_allow_troubleshooting: $('aiAllowTroubleshooting').checked, ai_allow_audit_reports: $('aiAllowAuditReports').checked});
    message.textContent = 'Settings saved successfully.'; message.className = 'inline-status success'; await load();
  } catch (error) { message.textContent = error.message; message.className = 'inline-status status'; }
  finally { button.disabled = false; button.textContent = 'Save operational settings'; }
};
$('testIdentity').onclick = async () => { try { const result=await api('/api/admin/test-identity', {vault_name: $('identityVault').value}); $('adminStatus').textContent = result.certificate_get_tested?'Managed identity certificate List and Get access succeeded.':'Managed identity certificate List access succeeded. The vault is empty, so Get could not be tested.'; } catch (error) { $('adminStatus').textContent = error.message; } };
$('clearAudit').onclick = async () => { if (confirm('Clear all login and activity audit history?')) { await api('/api/admin/audit/clear', {}); await load(); } };
$('searchHistory').onclick = async () => { try { const data = await api('/api/admin/certificate-history?q=' + encodeURIComponent($('historySearch').value)); const body = $('certificateHistoryRows'); body.innerHTML = ''; data.rows.forEach(row => auditRow(body, [row.uploaded_utc,row.generated_name,row.common_name,row.ticket_number || '',row.user_email,row.subscription_name,row.region,row.vault_name])); $('historySummary').textContent = `${data.rows.length} matching upload record(s).`; } catch (error) { $('adminStatus').textContent = error.message; } };
let reportRows=[];
$('createReport').onclick=async()=>{try{const data=await api('/api/admin/certificate-report?years='+encodeURIComponent($('reportYears').value));reportRows=data.rows;const body=$('certificateReportRows');body.innerHTML='';reportRows.forEach(row=>auditRow(body,[row.expires_utc||'Unknown',row.uploaded_utc,row.generated_name,row.common_name,row.ticket_number||'',row.user_email,row.subscription_name,row.region,row.vault_name]));$('reportSummary').textContent=`${reportRows.length} certificate record(s) for the selected range. Generated ${data.generated_utc}.`;}catch(error){$('adminStatus').textContent=error.message;}};
$('emailReport').onclick=async()=>{const button=$('emailReport');try{button.disabled=true;button.textContent='Sending...';const data=await api('/api/admin/certificate-report/email',{years:Number($('reportYears').value)});$('reportSummary').textContent=`CSV report with ${data.rows} record(s) sent to ${data.recipient}.`;}catch(error){$('adminStatus').textContent=error.message;}finally{button.disabled=false;button.textContent='Email CSV to me';}};
$('assistantKnowledgeForm').onsubmit=async event=>{event.preventDefault();try{await api('/api/admin/assistant/knowledge',{id:$('knowledgeId').value?Number($('knowledgeId').value):null,title:$('knowledgeTitle').value,content:$('knowledgeContent').value,audience:$('knowledgeAudience').value,source_type:$('knowledgeType').value});event.target.reset();$('knowledgeId').value='';$('adminStatus').textContent='Approved assistant knowledge saved.';await load()}catch(error){$('adminStatus').textContent=error.message}};
$('cancelKnowledgeEdit').onclick=()=>{$('assistantKnowledgeForm').reset();$('knowledgeId').value=''};
$('knowledgeFile').onchange=async()=>{const file=$('knowledgeFile').files[0];if(!file)return;if(file.size>100000){$('adminStatus').textContent='Knowledge file must be 100 KB or smaller.';$('knowledgeFile').value='';return}if(!$('knowledgeTitle').value)$('knowledgeTitle').value=file.name.replace(/\.[^.]+$/,'');$('knowledgeType').value='document';$('knowledgeContent').value=await file.text()};
$('adminLogout').onclick = async () => { await api('/api/admin/auth/logout', {}); window.location = '/admin/login'; };
load().catch(error => { if (error.message.includes('sign-in') || error.message.includes('expired')) window.location = '/admin/login'; else $('adminStatus').textContent = error.message; });
