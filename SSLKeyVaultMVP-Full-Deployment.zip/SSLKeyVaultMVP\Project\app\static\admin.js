/* Written by AM — SSL Key Vault Certificate Relay Portal */
const $ = id => document.getElementById(id);
async function api(url, body) {
  const response = await fetch(url, {method: body ? 'POST' : 'GET', headers: body ? {'Content-Type': 'application/json'} : {}, body: body ? JSON.stringify(body) : undefined});
  const data = await response.json();
  if (!response.ok) throw new Error(data.detail || 'Request failed');
  return data;
}
const keys = {domains: 'domain', users: 'email', subscriptions: 'id', regions: 'token', vaults: 'name'};
const allFields = {common_name: 'Certificate name', sans: 'Subdomains / SANs', issuer: 'Issuer', expires_utc: 'Expiration date', days_remaining: 'Days remaining', not_before_utc: 'Valid from', subject: 'Subject', serial_number: 'Serial number', sha256_thumbprint: 'SHA-256 thumbprint', key_type: 'Key type', key_size: 'Key size', chain_count: 'Chain certificates'};
function fill(select, items) { select.innerHTML = ''; items.forEach(([label, value]) => select.add(new Option(label, value))); }
function rowList(kind, rows) {
  const target = $(kind); target.innerHTML = '';
  rows.forEach(row => {
    const line = document.createElement('div'); line.className = 'admin-row';
    const label = document.createElement('span'); label.textContent = Object.entries(row).filter(([key]) => key !== 'active').map(([, value]) => value).join(' · ');
    const button = document.createElement('button'); button.textContent = row.active ? 'Deactivate' : 'Activate';
    button.onclick = async () => { await api('/api/admin/active', {table: kind, key: row[keys[kind]], active: !row.active}); await load(); };
    line.append(label, button); target.append(line);
  });
}
function auditRow(target, values) { const row = document.createElement('tr'); values.forEach(value => { const cell = document.createElement('td'); cell.textContent = value ?? ''; row.append(cell); }); target.append(row); }
async function load() {
  const data = await api('/api/admin/config');
  Object.keys(keys).forEach(key => rowList(key, data[key]));
  fill($('adminSub'), data.subscriptions.filter(x => x.active).map(x => [x.name, x.id]));
  fill($('adminRegion'), data.regions.filter(x => x.active).map(x => [x.display_name, x.token]));
  fill($('identityVault'), data.vaults.filter(x => x.active).map(x => [x.name, x.name]));
  const settings = data.settings;
  const values = {smtpHost: settings.smtp_host || '', smtpPort: settings.smtp_port || 587, smtpFrom: settings.smtp_from || '', identityType: settings.managed_identity_type || 'system', identityClientId: settings.managed_identity_client_id || '', userOtpMinutes: settings.user_otp_minutes || 15, userIdleMinutes: settings.user_idle_minutes || 15, adminOtpMinutes: settings.admin_otp_minutes || 10, adminIdleMinutes: settings.admin_idle_minutes || 15, auditRetentionValue: settings.audit_retention_value || 48, auditRetentionUnit: settings.audit_retention_unit || 'hours', liveCompareSuffixes: (settings.live_compare_allowed_suffixes || []).join(', '), liveCompareTimeout: settings.live_compare_timeout_seconds || 5};
  Object.entries(values).forEach(([id, value]) => { $(id).value = value; });
  const checks = {productionEnabled: settings.production_enabled, relayEnabled: settings.relay_enabled, smtpTls: settings.smtp_starttls, memoryRelayEnabled: settings.memory_relay_enabled !== false, liveCompareEnabled: settings.live_compare_enabled !== false, liveCompareRequired: settings.live_compare_required, liveCompareAllowPrivate: settings.live_compare_allow_private !== false, blockIssuerMismatch: settings.live_compare_block_issuer_mismatch, blockMissingNames: settings.live_compare_block_missing_names, blockSameSerial: settings.live_compare_block_same_serial};
  Object.entries(checks).forEach(([id, value]) => { $(id).checked = !!value; });
  const choices = $('fieldChoices'); choices.innerHTML = '';
  Object.entries(allFields).forEach(([key, label]) => { const wrap = document.createElement('label'); const box = document.createElement('input'); box.type = 'checkbox'; box.value = key; box.checked = (settings.certificate_fields || []).includes(key); wrap.append(box, document.createTextNode(' ' + label)); choices.append(wrap); });
  const loginBody = $('loginAuditRows'), activityBody = $('activityAuditRows');
  const loginActions = new Set(['user_otp_request', 'user_login', 'user_logout', 'admin_login', 'admin_logout']);
  loginBody.innerHTML = ''; activityBody.innerHTML = '';
  data.audit.forEach(entry => {
    if (loginActions.has(entry.action)) auditRow(loginBody, [entry.occurred_utc, entry.user_email, entry.action, entry.status, entry.detail || '']);
    else auditRow(activityBody, [entry.occurred_utc, entry.user_email, entry.action, entry.vault_name || '', entry.status, entry.detail || '']);
  });
}
document.querySelectorAll('form[data-kind]').forEach(form => form.onsubmit = async event => {
  event.preventDefault();
  try { await api('/api/admin/' + form.dataset.kind, Object.fromEntries(new FormData(form))); $('adminStatus').textContent = 'Saved successfully.'; form.reset(); await load(); }
  catch (error) { $('adminStatus').textContent = error.message; }
});
$('settingsForm').onsubmit = async event => {
  event.preventDefault(); const button = $('saveSettings'), message = $('settingsStatus'); button.disabled = true; button.textContent = 'Saving...'; message.textContent = '';
  try {
    await api('/api/admin/settings', {production_enabled: $('productionEnabled').checked, relay_enabled: $('relayEnabled').checked, smtp_host: $('smtpHost').value, smtp_port: Number($('smtpPort').value), smtp_from: $('smtpFrom').value, smtp_starttls: $('smtpTls').checked, managed_identity_type: $('identityType').value, managed_identity_client_id: $('identityClientId').value, user_otp_minutes: Number($('userOtpMinutes').value), user_idle_minutes: Number($('userIdleMinutes').value), admin_otp_minutes: Number($('adminOtpMinutes').value), admin_idle_minutes: Number($('adminIdleMinutes').value), audit_retention_value: Number($('auditRetentionValue').value), audit_retention_unit: $('auditRetentionUnit').value, memory_relay_enabled: $('memoryRelayEnabled').checked, live_compare_enabled: $('liveCompareEnabled').checked, live_compare_required: $('liveCompareRequired').checked, live_compare_allowed_suffixes: $('liveCompareSuffixes').value.split(',').map(x => x.trim()).filter(Boolean), live_compare_timeout_seconds: Number($('liveCompareTimeout').value), live_compare_allow_private: $('liveCompareAllowPrivate').checked, live_compare_block_issuer_mismatch: $('blockIssuerMismatch').checked, live_compare_block_missing_names: $('blockMissingNames').checked, live_compare_block_same_serial: $('blockSameSerial').checked, certificate_fields: [...$('fieldChoices').querySelectorAll('input:checked')].map(x => x.value)});
    message.textContent = 'Settings saved successfully.'; message.className = 'inline-status success'; await load();
  } catch (error) { message.textContent = error.message; message.className = 'inline-status status'; }
  finally { button.disabled = false; button.textContent = 'Save operational settings'; }
};
$('testIdentity').onclick = async () => { try { await api('/api/admin/test-identity', {vault_name: $('identityVault').value}); $('adminStatus').textContent = 'Managed identity access succeeded.'; } catch (error) { $('adminStatus').textContent = error.message; } };
$('clearAudit').onclick = async () => { if (confirm('Clear all login and activity audit history?')) { await api('/api/admin/audit/clear', {}); await load(); } };
$('adminLogout').onclick = async () => { await api('/api/admin/auth/logout', {}); window.location = '/admin/login'; };
load().catch(error => { if (error.message.includes('sign-in') || error.message.includes('expired')) window.location = '/admin/login'; else $('adminStatus').textContent = error.message; });
