# Written by AM — SSL Key Vault Certificate Relay Portal
from email.message import EmailMessage
import aiosmtplib


async def send_code(settings, recipient: str, code: str, portal_settings: dict | None = None) -> None:
    runtime = portal_settings or {}
    if not runtime.get("production_enabled") or not runtime.get("relay_enabled"):
        return
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = runtime.get("smtp_from") or settings.smtp_from, recipient, "SSL portal sign-in code"
    msg.set_content(f"Your one-time sign-in code is {code}. It expires in {settings.otp_ttl_hours} hours.\n\nIf you did not request it, ignore this message.")
    await aiosmtplib.send(msg, hostname=runtime.get("smtp_host") or settings.smtp_host,
                         port=int(runtime.get("smtp_port") or settings.smtp_port),
                         username=settings.smtp_username or None, password=settings.smtp_password or None,
                         start_tls=bool(runtime.get("smtp_starttls", settings.smtp_starttls)))
