# CertRelay User FAQ and Certificate Process

Written by AM

## Purpose

CertRelay securely validates a certificate in server memory and relays it to an approved Azure Key Vault. It is a certificate relay, not certificate storage. Certificate files, private keys, and passwords are not written to server storage.

## Complete certificate-transfer process

1. Open the approved CertRelay HTTPS address.
2. Enter your authorized email address and request a one-time code.
3. Retrieve the code from email, enter it, and select **Continue**.
4. Select the certificate file. Supported formats are PFX/P12 and supported PEM bundles.
5. Enter the certificate password when the uploaded certificate or private key is encrypted.
6. Select **Inspect certificate**.
7. Review the CN, SANs, issuer, serial number, validity, expiration, and other fields enabled by the administrator.
8. Enter the approved change, request, project, or SMP ticket when required.
9. Select the Azure subscription and region.
10. Select **Find matching Key Vaults** and choose the approved destination.
11. Wait while CertRelay checks that Key Vault for a certificate with the same CN.
12. Review the resolved Key Vault certificate name. An existing CN match reuses its exact object name; otherwise CertRelay proposes a normalized CN name.
13. If enabled, compare the new certificate with the existing live certificate by entering the application FQDN.
14. If required, verify the SMP ticket.
15. Review all confirmation information.
16. Select **Confirm and transfer certificate**.
17. Wait for the success message containing the destination vault, certificate name, and expiration date.
18. Sign out when finished.

## Frequently asked questions

### What file formats can I upload?

Use PFX/P12 or a supported PEM bundle. A PEM bundle must contain the certificate and corresponding private key. CertRelay converts supported PEM input to PFX in memory before importing it into Azure Key Vault.

### Does CertRelay save my certificate?

No. The certificate, private key, and certificate password are processed in memory for the request and are not intentionally written to disk or the portal database.

### Why do I need a certificate password?

The password decrypts an encrypted PFX or private key. It is used only while processing the request. Do not enter an Azure, network, email, or personal password in this field.

### What happens if the certificate has no password?

Leave the certificate-password field blank. If the file is encrypted, inspection will fail and request the correct certificate password.

### Why do I receive a certificate password error or invalid password message?

Confirm that you entered the password for the uploaded PFX/P12 or encrypted private key—not your Windows, email, Azure, or portal password. Passwords are case-sensitive and may contain special characters. Re-select the original file, type the password instead of pasting when hidden characters are suspected, and select **Inspect certificate** again. If the file has no password, leave the field blank. If the error continues, verify the PFX locally with an approved certificate tool or ask the certificate owner to confirm/export a valid PFX containing the certificate and matching private key. Never send the password, PFX, or private key through email, chatbot, screenshots, or tickets.

### Why does certificate inspection say the file cannot be decoded, deserialized, or opened?

The password may be incorrect, the PFX may be damaged, the PEM may not contain a matching private key, or the file format/extension may be wrong. Confirm the original file and password, verify that the certificate and private key match, and create a new approved export when necessary. Do not repeatedly guess passwords or upload unrelated files.

### What information is displayed after inspection?

Depending on Admin policy, CertRelay can display CN, SANs, issuer, subject, serial number, start date, expiration, remaining days, public-key type and size, chain count, signature information, and SHA-256 thumbprint.

### What is the certificate CN?

The Common Name identifies the primary certificate name. For example, a CN may be `webtestcert.bsc.bscal.com`.

### What are SANs?

Subject Alternative Names are additional DNS names covered by the certificate. Confirm that every required application hostname is present before transferring the certificate.

### Why does the Azure certificate name use hyphens instead of periods?

Azure Key Vault object names allow letters, numbers, and hyphens. A CN such as `webtestcert.bsc.bscal.com` becomes `webtestcert-bsc-bscal-com`. The CN and SAN values inside the certificate are not changed.

### How does CertRelay select the Key Vault certificate name?

After you choose a destination, CertRelay checks the latest public certificate for every certificate object in that Key Vault:

- If exactly one current certificate has the same CN, CertRelay reuses that certificate object's exact Key Vault name. The import creates a new version under the same name.
- If none has the same CN, CertRelay creates a new name from the normalized CN. For example, `webtestcert.bsc.bscal.com` becomes `webtestcert-bsc-bscal-com`.
- If more than one object has the same CN, CertRelay blocks the transfer because selecting one would be ambiguous. Contact the Network Team or CertRelay administrator.
- If the normalized CN name is already used by a certificate with a different or unreadable CN, CertRelay blocks the transfer to avoid updating the wrong object.

The server repeats this lookup immediately before import. A browser request cannot override the resolved name.

### Why must an existing Key Vault certificate name be reused?

Azure Application Gateway should reference the certificate through a versionless Key Vault secret URI. Keeping the same Key Vault object name lets a renewal create a new version that Application Gateway can retrieve without changing the configured secret name.

### Can I change the resolved certificate name?

No. The name is selected from the existing Key Vault CN match or derived from the uploaded CN when no match exists. This prevents a renewal from being imported under an unrelated name.

### What is the approved ticket number?

It is the change, request, project, Jira, RITM, or SMP number authorizing the transfer. Enter the exact approved identifier. The portal never treats a typed ticket as approved unless required verification succeeds.

### Why is the ticket field required?

The administrator enabled the approved-ticket policy, SMP verification policy, or both. Obtain the correct approved ticket before continuing.

### What is SMP verification?

SMP verification checks the entered ticket through the configured company SMP service. When mandatory, the transfer remains blocked until the ticket has an approved status and matches the selected destination requirements.

### Why did SMP verification fail?

Confirm the ticket number, status, approval window, subscription, region, and Key Vault. If they are correct, provide the sanitized error and ticket number to the support team. Never send certificate passwords or private keys.

### Why do I select a subscription and region?

They restrict the destination search to Admin-approved Key Vaults for that environment and Azure region.

### Why are no matching Key Vaults displayed?

Confirm the selected subscription and region. The administrator must configure an active destination for that exact combination. Contact the CertRelay administrator if the correct destination is missing.

### Why is only one Key Vault displayed?

Only active Key Vault destinations matching both the selected subscription and region are shown. Other vaults are intentionally excluded.

### What is live-certificate comparison?

CertRelay connects to an approved application FQDN on TCP 443, reads the publicly presented TLS certificate, and compares its metadata with the new certificate without storing either certificate.

### What should I enter in the FQDN field?

Enter only the application hostname, such as `application.bsc.bscal.com`. Do not enter `https://`, a URL path, username, password, or query string.

### What does issuer mismatch mean?

The issuer shown on the existing live certificate differs from the issuer of the new certificate. The administrator can make this informational or block the transfer.

### What does missing DNS or SAN name mean?

A hostname covered by the current live certificate is absent from the new certificate. Transferring it could break TLS for that hostname. The administrator can block the transfer.

### Why must the serial numbers be different?

Every newly issued certificate should normally have a new serial number. If the new and live serial numbers match, the same certificate may have been uploaded again. Admin policy can block this condition.

### What are additional names?

They are DNS names present in the new certificate but not in the currently presented certificate. Review them to confirm that they are expected.

### Why is transfer blocked after comparison?

The administrator enabled enforcement for issuer mismatch, missing DNS/SAN names, matching serial numbers, or required comparison. Correct the certificate or ask the administrator to review the approved policy. Users should not bypass the policy.

### What does “comparison expired” mean?

Comparison authorization is temporary. Inspect the certificate and run the comparison again without changing the certificate or destination.

### Why did the certificate change after comparison?

CertRelay binds comparison approval to the inspected certificate. Selecting a different file or modifying the destination requires a new comparison.

### What does production transfer mean?

Production mode permits the backend to import the certificate into Azure Key Vault. When production mode is disabled, the portal can validate the workflow without performing the Azure transfer.

### How does CertRelay authenticate to Azure?

It uses the configured VM system-assigned or user-assigned managed identity. End users do not enter Azure credentials.

### What permissions does the user need in Azure?

The user does not need direct Key Vault credentials for the portal transfer. The server's managed identity must be able to list and read certificate metadata for CN matching and import the certificate.

### What does managed-identity failure mean?

The VM identity may be disabled, the wrong identity may be configured, Key Vault permissions may be missing, the destination may be incorrect, or network access may be blocked. Contact the CertRelay administrator.

### Why was the transfer rejected even though the screen allowed a name?

The backend always applies current Admin policy. It validates the destination, ticket, comparison, SMP token, certificate name, file, and managed-identity configuration again before import.

### What should I record after a successful transfer?

Record the ticket number, destination Key Vault, final Key Vault certificate name, completion time, and expiration date. Do not record or share the certificate password or private key.

### Can another user see my password or certificate?

The application is designed not to store these values. Password fields are cleared after processing, and certificates/private keys are not included in audit records or chatbot prompts.

### Why did I not receive an OTP email?

Check spam/quarantine, verify the email address, and wait for the configured delivery period. If no message arrives, contact the administrator to test SMTP relay configuration. Do not repeatedly request codes unnecessarily.

### Why is an OTP displayed on the page?

This can occur in local/development mode or for the configured Admin flow. Production regular-user authentication normally uses the enabled email relay.

### Why is my OTP invalid or expired?

Use the latest code, enter all six digits, and ensure it is within the configured validity period. OTPs are one-time use. Request a new code when necessary.

### Why did my session expire?

The configured idle timer expired, the application restarted, the session was revoked, or the browser did not return the secure session cookie. Sign in again. Persistent remote problems should be reported to the administrator.

### Why does remote login fail after OTP while localhost works?

The HTTPS/IIS reverse proxy may not be forwarding the original HTTPS protocol, or the secure session cookie may not be returned. The administrator should check IIS proxy headers, HTTPS bindings, hostname/IP access, and cookie settings.

### What does a 401 error mean?

The session is absent, invalid, expired, or unauthorized. Sign in again. If it repeats immediately, report the URL used and the time of the failure.

### What does a 403 error mean?

The account, domain, role, destination, or requested feature is not authorized by policy.

### What does a 502 error mean?

The reverse proxy or backend dependency could not complete the request. The portal service may not be running, IIS may not reach `127.0.0.1:8000`, or an external service may be unavailable.

### What does “in-memory relay disabled” mean?

An administrator disabled certificate/password processing. No certificate can be inspected or transferred until it is re-enabled.

### Can I use the chatbot for certificate instructions?

Yes, when the User Chatbot is enabled. It can answer from Admin-approved Q&A and instruction files and, when configured, use ChatGPT or Microsoft Copilot for additional explanation.

### What information should I give the chatbot?

Provide the error text, general step, subscription name, region, Key Vault name, and ticket number when appropriate. Never provide certificate content, private keys, certificate passwords, OTPs, session tokens, SMTP credentials, or API keys.

### Can the chatbot transfer the certificate for me?

No. It provides guidance and explanations. The authenticated user must review and confirm the transfer through the controlled certificate workflow.

### Can the chatbot see other users’ activity?

No. The User Chatbot is restricted to permitted user-level context. Organization-wide audit, history, and reporting information is reserved for authorized administrators.

### How do I report a problem safely?

Provide the date/time, portal URL, step, sanitized error, ticket number, subscription, region, and Key Vault. Do not send the certificate file, private key, password, OTP, session cookie, or secret values through chat or email.
