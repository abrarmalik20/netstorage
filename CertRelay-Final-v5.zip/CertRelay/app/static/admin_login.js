/* Written by AM — CertRelay */
const $=id=>document.getElementById(id);
async function call(url,body){const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await response.json();if(!response.ok)throw new Error(data.detail||'Request failed');return data}
function show(message,success=false){const target=$('adminLoginStatus');target.textContent=message;target.className='status '+(success?'success':'')}
$('adminSend').onclick=async()=>{try{const data=await call('/api/admin/auth/request-code',{email:$('adminEmail').value});$('adminCodeArea').hidden=false;show(data.message+(data.development_code?` Code: ${data.development_code}`:''),true)}catch(error){show(error.message)}};
$('adminVerify').onclick=async()=>{try{await call('/api/admin/auth/verify',{email:$('adminEmail').value,code:$('adminCode').value});window.location='/admin'}catch(error){show(error.message)}};
