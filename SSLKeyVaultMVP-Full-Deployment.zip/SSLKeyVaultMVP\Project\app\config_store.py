# Written by AM — SSL Key Vault Certificate Relay Portal
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta, timezone
import json


class ConfigStore:
    """Portal metadata only; never OTPs, certificates, keys, or passwords."""
    TABLE_KEYS = {"domains": "domain", "users": "email", "subscriptions": "id",
                  "regions": "token", "vaults": "name"}

    def __init__(self, path: str, initial_admin: str):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._initialize(initial_admin.lower())

    def _connect(self):
        db = sqlite3.connect(self.path)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        return db

    def _initialize(self, admin: str):
        with self._connect() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS domains (domain TEXT PRIMARY KEY, delivery_domain TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS users (email TEXT PRIMARY KEY, role TEXT NOT NULL CHECK(role IN ('admin','user')), active INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS subscriptions (id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, environment TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS regions (token TEXT PRIMARY KEY, display_name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS vaults (name TEXT PRIMARY KEY, subscription_id TEXT NOT NULL, region_token TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
              FOREIGN KEY(subscription_id) REFERENCES subscriptions(id), FOREIGN KEY(region_token) REFERENCES regions(token));
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS audit (
              id INTEGER PRIMARY KEY AUTOINCREMENT, occurred_utc TEXT NOT NULL, user_email TEXT NOT NULL,
              action TEXT NOT NULL, certificate_name TEXT, thumbprint TEXT, subscription_name TEXT,
              region TEXT, vault_name TEXT, status TEXT NOT NULL, detail TEXT);
            """)
            db.execute("INSERT OR IGNORE INTO domains VALUES (?,?,1)", ("blueshieldca.com", "bse.bscal.com"))
            db.execute("INSERT OR IGNORE INTO users VALUES (?,'admin',1)", (admin,))
            db.execute("INSERT OR IGNORE INTO subscriptions VALUES (?,?,?,1)", ("00000000-0000-0000-0000-000000000001", "bsc-npn", "npn"))
            db.execute("INSERT OR IGNORE INTO subscriptions VALUES (?,?,?,1)", ("00000000-0000-0000-0000-000000000002", "bsc-prd", "prd"))
            db.execute("INSERT OR IGNORE INTO regions VALUES (?,?,1)", ("cus", "Central US"))
            db.execute("INSERT OR IGNORE INTO regions VALUES (?,?,1)", ("eus2", "East US 2"))
            db.execute("INSERT OR IGNORE INTO vaults VALUES (?,?,?,1)", ("kv-nw-npn-ics-sc-cus-22", "00000000-0000-0000-0000-000000000001", "cus"))
            db.execute("INSERT OR IGNORE INTO vaults VALUES (?,?,?,1)", ("kv-nw-prd-ics-sc-cus-22", "00000000-0000-0000-0000-000000000002", "cus"))
            defaults = {
                "production_enabled": False, "relay_enabled": False,
                "smtp_host": "", "smtp_port": 587, "smtp_starttls": True,
                "smtp_from": "SSL Certificate Portal <no-reply@blueshieldca.com>",
                "managed_identity_type": "system", "managed_identity_client_id": "",
                "user_otp_minutes": 15, "user_idle_minutes": 15,
                "admin_otp_minutes": 10, "admin_idle_minutes": 15,
                "audit_retention_value": 48, "audit_retention_unit": "hours",
                "memory_relay_enabled": True,
                "live_compare_enabled": True, "live_compare_required": False,
                "live_compare_allowed_suffixes": ["bsc.bscal.com"],
                "live_compare_timeout_seconds": 5, "live_compare_allow_private": True,
                "live_compare_block_issuer_mismatch": False,
                "live_compare_block_missing_names": False,
                "live_compare_block_same_serial": False,
                "certificate_fields": ["common_name", "sans", "issuer", "expires_utc", "days_remaining", "sha256_thumbprint"],
            }
            for key, value in defaults.items():
                db.execute("INSERT OR IGNORE INTO settings VALUES (?,?)", (key, json.dumps(value)))
            # Privacy migration: remove certificate identifiers from any legacy audit rows.
            db.execute("UPDATE audit SET certificate_name=NULL, thumbprint=NULL WHERE certificate_name IS NOT NULL OR thumbprint IS NOT NULL")

    def one(self, table: str, key: str):
        column = self.TABLE_KEYS[table]
        with self._connect() as db:
            row = db.execute(f"SELECT * FROM {table} WHERE {column}=?", (key.lower(),)).fetchone()
            return dict(row) if row else None

    def active_options(self):
        with self._connect() as db:
            subscriptions = [dict(x) for x in db.execute("SELECT id,name,environment FROM subscriptions WHERE active=1 ORDER BY name")]
            regions = [dict(x) for x in db.execute("SELECT token,display_name AS name FROM regions WHERE active=1 ORDER BY display_name")]
            return subscriptions, regions

    def matching_vaults(self, subscription_id: str, region: str):
        with self._connect() as db:
            return [x[0] for x in db.execute("SELECT name FROM vaults WHERE subscription_id=? AND region_token=? AND active=1 ORDER BY name", (subscription_id, region))]

    def snapshot(self):
        with self._connect() as db:
            result = {table: [dict(x) for x in db.execute(f"SELECT * FROM {table} ORDER BY 1")]
                      for table in self.TABLE_KEYS}
        result["settings"] = self.settings()
        result["audit"] = self.audit_history()
        return result

    def settings(self):
        with self._connect() as db:
            return {row["key"]: json.loads(row["value"]) for row in db.execute("SELECT key,value FROM settings")}

    def update_settings(self, values: dict):
        allowed = {"production_enabled", "relay_enabled", "smtp_host", "smtp_port", "smtp_starttls",
                   "smtp_from", "managed_identity_type", "managed_identity_client_id", "certificate_fields",
                   "user_otp_minutes", "user_idle_minutes", "admin_otp_minutes", "admin_idle_minutes",
                   "memory_relay_enabled", "audit_retention_value", "audit_retention_unit"}
        allowed.update({"live_compare_enabled", "live_compare_required", "live_compare_allowed_suffixes",
                        "live_compare_timeout_seconds", "live_compare_allow_private",
                        "live_compare_block_issuer_mismatch", "live_compare_block_missing_names",
                        "live_compare_block_same_serial"})
        for key in ("user_otp_minutes", "user_idle_minutes", "admin_otp_minutes", "admin_idle_minutes"):
            if key in values and not 1 <= int(values[key]) <= 1440:
                raise ValueError(f"{key} must be between 1 and 1440 minutes.")
        if "live_compare_timeout_seconds" in values and not 1 <= int(values["live_compare_timeout_seconds"]) <= 30:
            raise ValueError("live_compare_timeout_seconds must be between 1 and 30 seconds.")
        if "audit_retention_unit" in values and values["audit_retention_unit"] not in {"hours", "weeks", "months"}:
            raise ValueError("audit_retention_unit must be hours, weeks, or months.")
        if "audit_retention_value" in values and not 1 <= int(values["audit_retention_value"]) <= 120:
            raise ValueError("audit_retention_value must be between 1 and 120.")
        if "live_compare_allowed_suffixes" in values:
            values["live_compare_allowed_suffixes"] = [
                str(x).strip().lower().lstrip(".").rstrip(".")
                for x in values["live_compare_allowed_suffixes"] if str(x).strip()
            ]
            if not values["live_compare_allowed_suffixes"]:
                raise ValueError("At least one approved FQDN suffix is required.")
        effective = {**self.settings(), **values}
        blocking_enabled = any(effective.get(key, False) for key in (
            "live_compare_block_issuer_mismatch", "live_compare_block_missing_names",
            "live_compare_block_same_serial"))
        if blocking_enabled and not effective.get("live_compare_enabled", True):
            raise ValueError("Live certificate comparison must be enabled when a transfer-blocking policy is enabled.")
        with self._connect() as db:
            for key, value in values.items():
                if key not in allowed:
                    raise ValueError(f"Unsupported setting: {key}")
                db.execute("INSERT INTO settings VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                           (key, json.dumps(value)))
        self.purge_expired_audit()

    def _audit_cutoff(self):
        runtime = self.settings()
        value = int(runtime.get("audit_retention_value", 48))
        unit = runtime.get("audit_retention_unit", "hours")
        duration = {"hours": timedelta(hours=value), "weeks": timedelta(weeks=value),
                    "months": timedelta(days=30 * value)}[unit]
        return (datetime.now(timezone.utc) - duration).isoformat()

    def purge_expired_audit(self):
        cutoff = self._audit_cutoff()
        with self._connect() as db:
            db.execute("DELETE FROM audit WHERE occurred_utc < ?", (cutoff,))

    def add_audit(self, *, user_email: str, action: str, status: str,
                  subscription_name=None, region=None, vault_name=None, detail=None):
        now = datetime.now(timezone.utc).isoformat()
        safe_detail = (detail or "")[:300]
        with self._connect() as db:
            db.execute("INSERT INTO audit (occurred_utc,user_email,action,certificate_name,thumbprint,subscription_name,region,vault_name,status,detail) VALUES (?,?,?,?,?,?,?,?,?,?)",
                       (now, user_email, action, None, None, subscription_name, region, vault_name, status, safe_detail))
        self.purge_expired_audit()

    def audit_history(self):
        self.purge_expired_audit()
        with self._connect() as db:
            return [dict(x) for x in db.execute("SELECT * FROM audit ORDER BY occurred_utc DESC")]

    def audit_last_48_hours(self):
        """Backward-compatible alias that uses the configured retention period."""
        return self.audit_history()

    def clear_audit(self):
        with self._connect() as db:
            db.execute("DELETE FROM audit")

    def upsert(self, table: str, values: dict):
        columns = list(values)
        key = self.TABLE_KEYS[table]
        assignments = ",".join(f"{c}=excluded.{c}" for c in columns if c != key)
        with self._connect() as db:
            db.execute(f"INSERT INTO {table} ({','.join(columns)}) VALUES ({','.join('?' for _ in columns)}) "
                       f"ON CONFLICT({key}) DO UPDATE SET {assignments}", tuple(values.values()))

    def set_active(self, table: str, key: str, active: bool):
        column = self.TABLE_KEYS.get(table)
        if not column:
            raise ValueError("Invalid configuration type.")
        with self._connect() as db:
            db.execute(f"UPDATE {table} SET active=? WHERE {column}=?", (int(active), key.lower()))
