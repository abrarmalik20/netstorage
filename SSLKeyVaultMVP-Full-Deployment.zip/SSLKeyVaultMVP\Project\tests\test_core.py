﻿# Written by AM â€” SSL Key Vault Certificate Relay Portal
from datetime import datetime, timedelta, timezone
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
from app.certificates import inspect_certificate, prepare_as_pfx
from app.security import OneTimeCodeStore, normalize_authorized_email, safe_certificate_name
from app.azure_service import AzureService
from app.config_store import ConfigStore
from app.live_compare import compare_metadata, comparison_policy_blockers, hostname_covered, normalize_fqdn


def test_domain_enforced():
    domains = ["blueshieldca.com", "gmail.com"]
    assert normalize_authorized_email("User@blueshieldca.com", domains) == "user@blueshieldca.com"
    assert normalize_authorized_email("Tester@gmail.com", domains) == "tester@gmail.com"
    try: normalize_authorized_email("user@yahoo.com", domains); assert False
    except ValueError: pass


def test_otp_one_time():
    store = OneTimeCodeStore("a" * 32, 24); code = store.issue("u@blueshieldca.com")
    assert store.verify("u@blueshieldca.com", code)
    assert not store.verify("u@blueshieldca.com", code)


def test_name_validation():
    assert safe_certificate_name("API-Cert-01") == "api-cert-01"


def test_pem_converts_to_pfx():
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "api.example.com")])
    cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(issuer).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(days=1))
            .not_valid_after(datetime.now(timezone.utc)+timedelta(days=30)).sign(key, hashes.SHA256()))
    pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()) + cert.public_bytes(serialization.Encoding.PEM)
    result = prepare_as_pfx(pem, "bundle.pem", "")
    assert result.pfx and result.password and result.common_name == "api.example.com"
    metadata = inspect_certificate(result.pfx, "bundle.pfx", result.password.decode())
    assert metadata["common_name"] == "api.example.com"
    assert metadata["expires_utc"] and metadata["issuer"]
    assert len(metadata["sha256_thumbprint"]) == 64


def test_vault_name_filter_uses_exact_environment_and_region_segments():
    assert AzureService.environment_token("bsc-npn") == "npn"
    assert AzureService.name_matches("kv-nw-npn-ics-sc-cus-22", "npn", "cus")
    assert AzureService.name_matches("kv-app-npn-shared-cus-01", "npn", "cus")
    assert not AzureService.name_matches("kv-nw-npn-ics-sc-eus2-22", "npn", "cus")
    assert not AzureService.name_matches("kv-nw-npnext-ics-sc-cus-22", "npn", "cus")


def test_live_certificate_comparison_highlights_missing_and_additional_names():
    future = (datetime.now(timezone.utc) + timedelta(days=90)).isoformat()
    later = (datetime.now(timezone.utc) + timedelta(days=365)).isoformat()
    live = {"sans": ["api.bsc.bscal.com", "legacy.bsc.bscal.com"], "common_name": "api.bsc.bscal.com",
            "expires_utc": future, "key_size": 2048, "issuer": "CN=Old CA", "key_type": "RSA",
            "serial_number": "ABC123"}
    new = {"sans": ["api.bsc.bscal.com", "new.bsc.bscal.com"], "common_name": "api.bsc.bscal.com",
           "expires_utc": later, "key_size": 2048, "issuer": "CN=New CA", "key_type": "RSA",
           "serial_number": "ABC123"}
    result = compare_metadata("api.bsc.bscal.com", live, new)
    assert result["missing_in_new"] == ["legacy.bsc.bscal.com"]
    assert result["additional_in_new"] == ["new.bsc.bscal.com"]
    assert result["new_covers_fqdn"] is True
    assert result["result"] == "review"
    differences = {item["field"]: item for item in result["field_differences"]}
    assert differences["issuer"]["live_value"] == "CN=Old CA"
    assert differences["issuer"]["new_value"] == "CN=New CA"
    assert differences["issuer"]["severity"] == "review"
    assert differences["expires_utc"]["severity"] == "information"
    assert "key_type" not in differences
    assert "different certificate authority" in " ".join(result["warnings"])
    assert result["issuer_matches"] is False
    assert result["serial_numbers_match"] is True
    blockers = comparison_policy_blockers(result, {
        "live_compare_block_issuer_mismatch": True,
        "live_compare_block_missing_names": True,
        "live_compare_block_same_serial": True,
    })
    assert len(blockers) == 3


def test_live_comparison_fqdn_allowlist_and_wildcard_matching():
    assert normalize_fqdn("App.BSC.BSCAL.COM.", ["bsc.bscal.com"]) == "app.bsc.bscal.com"
    assert hostname_covered("app.bsc.bscal.com", ["*.bsc.bscal.com"])
    assert not hostname_covered("deep.app.bsc.bscal.com", ["*.bsc.bscal.com"])
    try:
        normalize_fqdn("example.com", ["bsc.bscal.com"])
        assert False
    except ValueError:
        pass


def test_admin_store_users_domains_and_destinations(tmp_path):
    store = ConfigStore(str(tmp_path / "portal.db"), "amalik02@blueshieldca.com")
    assert store.one("users", "amalik02@blueshieldca.com")["role"] == "admin"
    store.upsert("domains", {"domain": "bsc.bscal.com", "delivery_domain": "bsc.bscal.com", "active": 1})
    store.upsert("users", {"email": "engineer@bsc.bscal.com", "role": "user", "active": 1})
    assert store.one("users", "engineer@bsc.bscal.com")["role"] == "user"
    assert store.matching_vaults("00000000-0000-0000-0000-000000000001", "cus") == ["kv-nw-npn-ics-sc-cus-22"]
    store.update_settings({"relay_enabled": True, "certificate_fields": ["issuer", "expires_utc"]})
    assert store.settings()["relay_enabled"] is True
    assert store.settings()["live_compare_enabled"] is True
    assert store.settings()["live_compare_allowed_suffixes"] == ["bsc.bscal.com"]
    store.update_settings({"live_compare_block_issuer_mismatch": True,
                           "live_compare_block_missing_names": True,
                           "live_compare_block_same_serial": True})
    assert store.settings()["live_compare_block_same_serial"] is True
    store.add_audit(user_email="engineer@bsc.bscal.com", action="transfer", status="success",
                    vault_name="kv-nw-npn-ics-sc-cus-22")
    assert store.audit_history()[0]["certificate_name"] is None
    store.clear_audit()
    assert store.audit_last_48_hours() == []
