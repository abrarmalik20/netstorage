# Written by AM — CertRelay
import json
from functools import lru_cache
from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_secret_key: str = "dev-only-change-me-please-32-characters"
    app_mode: str = "mock"
    allowed_login_domain: str = "blueshieldca.com"
    additional_login_domains: str = ""
    delivery_domain: str = "bse.bscal.com"
    initial_admin_email: str = "amalik02@blueshieldca.com"
    config_db_path: str = "data/portal_config.db"
    otp_ttl_hours: int = 24
    session_ttl_hours: int = 8
    max_cert_bytes: int = 5 * 1024 * 1024
    allowed_subscriptions: list[str] = []
    region_tokens: dict[str, str] = {"Central US": "cus", "East US 2": "eus2"}
    vault_overrides: dict[str, str] = {}
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from: str = "CertRelay <no-reply@blueshieldca.com>"
    smtp_starttls: bool = True

    @property
    def allowed_login_domains(self) -> list[str]:
        extra = [x.strip().lower() for x in self.additional_login_domains.split(",") if x.strip()]
        return [self.allowed_login_domain.lower(), *extra]

    @field_validator("allowed_subscriptions", mode="before")
    @classmethod
    def split_csv(cls, value):
        if isinstance(value, str):
            return [item.strip() for item in value.split(",") if item.strip()]
        return value

    @field_validator("region_tokens", "vault_overrides", mode="before")
    @classmethod
    def parse_json(cls, value):
        return json.loads(value) if isinstance(value, str) else value


@lru_cache
def get_settings() -> Settings:
    return Settings()
