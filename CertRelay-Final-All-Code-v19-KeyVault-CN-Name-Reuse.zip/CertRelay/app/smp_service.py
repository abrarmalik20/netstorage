# Written by AM — CertRelay
from urllib.parse import quote
import base64
import httpx
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from starlette.concurrency import run_in_threadpool


def _credential(runtime: dict):
    client_id = runtime.get("managed_identity_client_id", "")
    if runtime.get("managed_identity_type") == "user" and client_id:
        return ManagedIdentityCredential(client_id=client_id)
    return ManagedIdentityCredential()


async def verify_smp_ticket(ticket_number: str, runtime: dict) -> dict:
    base_url = runtime.get("smp_api_url", "").strip().rstrip("/")
    vault = runtime.get("smp_credential_vault", "").strip()
    if not base_url.startswith("https://"):
        raise ValueError("SMP API URL must use HTTPS.")
    if not vault:
        raise ValueError("SMP credential Key Vault is not configured.")
    credential = _credential(runtime)
    secrets = SecretClient(f"https://{vault}.vault.azure.net", credential)

    def secret(name_key: str) -> str:
        name = runtime.get(name_key, "").strip()
        if not name:
            raise ValueError(f"SMP secret name is missing: {name_key}.")
        return secrets.get_secret(name).value

    auth_type = runtime.get("smp_auth_type", "token")
    if auth_type == "token":
        token = await run_in_threadpool(secret, "smp_token_secret_name")
        headers = {"Authorization": f"Bearer {token}"}
    else:
        username = await run_in_threadpool(secret, "smp_username_secret_name")
        password = await run_in_threadpool(secret, "smp_password_secret_name")
        encoded = base64.b64encode(f"{username}:{password}".encode()).decode()
        headers = {"Authorization": f"Basic {encoded}"}
    try:
        async with httpx.AsyncClient(timeout=10.0, follow_redirects=False) as client:
            response = await client.get(f"{base_url}/tickets/{quote(ticket_number, safe='')}", headers=headers)
            response.raise_for_status()
            data = response.json()
    finally:
        headers.clear()
    status = str(data.get("status", "")).strip().lower()
    approved_statuses = {x.lower() for x in runtime.get("smp_approved_statuses", ["approved"])}
    approved = bool(data.get("approved", status in approved_statuses)) and status in approved_statuses
    return {"ticket_number": str(data.get("ticket_number") or ticket_number).upper(),
            "status": status or "unknown", "approved": approved,
            "change_start": data.get("change_start"), "change_end": data.get("change_end"),
            "subscription": data.get("subscription"), "region": data.get("region"),
            "key_vault": data.get("key_vault")}
