# CertRelay

**Written by AM** — Project owner and primary maintainer.

A Python/FastAPI browser portal that validates a corporate user, converts PEM certificate bundles to PFX in process memory, selects a Key Vault from subscription + region, requires destination confirmation, and imports the certificate without intentionally writing certificate bytes or passwords to the VM filesystem.

## Optional live-certificate comparison

Users can enter an approved application FQDN and compare the certificate currently presented on TCP 443 with the uploaded replacement certificate before transfer. The portal displays both certificates, highlights DNS SANs missing from the new certificate, identifies additional SANs, checks FQDN coverage, and compares issuer, expiration, thumbprint, key type/size, and signature algorithm. The feature is enabled by default but optional; an administrator can require a cryptographically bound comparison before transfer.

Live retrieval is restricted to administrator-approved DNS suffixes and TCP 443. Loopback, link-local, multicast, reserved, and Azure metadata addresses are blocked. Approved internal/private destinations can be enabled for internal applications. Live and uploaded certificate bytes are processed in memory and are not stored.

## User flow

1. Enter `name@blueshieldca.com` or, in test mode, `name@gmail.com`.
2. Receive a one-time code at `name@bse.bscal.com`; the code expires after 24 hours and is valid once.
3. Upload PFX/P12 or a PEM bundle containing the private key and certificate chain.
4. Enter the source certificate password when applicable.
5. Choose an allowed Azure subscription and region.
6. Select from a dropdown containing only vault names with exact environment and region segments. For example, `bsc-npn + cus` requires both `-npn-` and `-cus-` in the vault name.
7. Review the selected vault, then confirm import.
8. Watch progress and receive the imported certificate name, vault, and expiry.

## Admin portal

`amalik02@blueshieldca.com` is the initial administrator. Only admins see the Admin Portal link. Admins can add or deactivate allowed login domains and OTP delivery-domain mappings, authorized usernames and roles, subscriptions, regions, and exact Key Vault destinations. Regular users receive HTTP 403 if they try the admin page or APIs directly.

## Run the safe demo

```powershell
cd ssl-keyvault-mvp
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000`. Demo mode returns the OTP in the browser and simulates Azure; it does not upload anywhere.

## Azure mode

1. Deploy behind HTTPS on Azure App Service, Container Apps, or an internal VM.
2. Enable a system-assigned or user-assigned managed identity. `DefaultAzureCredential` uses that identity in Azure; no Azure client secret is required.
3. Grant only **Key Vault Certificates Officer** (or a custom role containing certificate import) on approved vaults. Add Reader access at the appropriate subscription scope only if automatic vault discovery is used.
4. Set `APP_MODE=azure`, a 32+ character `APP_SECRET_KEY`, the allowed subscription names, region tokens, explicit vault overrides, and approved SMTP relay settings as platform environment variables.
   Remove `gmail.com` from `ADDITIONAL_LOGIN_DOMAINS` before production deployment.
5. Keep explicit `VAULT_OVERRIDES` in production. Automatic token matching stops if zero or multiple vaults match.
6. Disable request-body logging in the reverse proxy/APM and enforce a 5 MB body limit there too.

Example exact mapping:

```text
VAULT_OVERRIDES={"<subscription-guid>|cus":"kv-nw-npn-ics-sc-cus-22"}
```

## Security boundaries

- Key Vault certificate names are generated from the certificate CN, UTC year, and sequence (for example `api-bsc-bscal-com-2026-01`).
- Successful production-transfer naming history stores only CN/name, uploader, destination, and time. Admins can search it and retain it for 1–3 years.
- Certificate bytes, passwords, private keys, SAN lists, serial numbers, and thumbprints are never stored in naming history.

- The browser sends JSON from an in-memory `ArrayBuffer`, avoiding server multipart temp files.
- The server holds certificate bytes/passwords only in process memory for the request and never logs them.
- HTTP responses use `Cache-Control: no-store`; the password input is cleared after import.
- OTPs are HMAC digests in process memory, single-use, and locked after five failed attempts.
- This is best-effort memory handling in Python: garbage collection/copies cannot be cryptographically guaranteed erased. For production, use private networking, TLS, managed identity, locked-down telemetry, and a short worker lifetime.
- A 24-hour OTP is longer than recommended. Prefer Microsoft Entra ID SSO + Conditional Access/MFA for production and reduce OTP validity to 10–15 minutes if OTP remains.
- The application service identity—not the signed-in human—performs the import. Audit logs record actor, subscription, region, vault, certificate name, and UTC time, but no secrets.

## Tests

```powershell
pytest -q
```

## Important PEM requirement

A PEM containing only the public certificate cannot become a usable PFX. It must also contain the corresponding private key; include intermediates in the same PEM when needed.
