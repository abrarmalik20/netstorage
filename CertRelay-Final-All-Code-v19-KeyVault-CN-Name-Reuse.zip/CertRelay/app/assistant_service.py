# Written by AM — CertRelay
import asyncio
import os
import re
import uuid
import httpx
from starlette.concurrency import run_in_threadpool


def _credential(runtime: dict):
    from azure.identity import ManagedIdentityCredential
    client_id = runtime.get("managed_identity_client_id", "")
    if runtime.get("managed_identity_type") == "user" and client_id:
        return ManagedIdentityCredential(client_id=client_id)
    return ManagedIdentityCredential()


async def _secret(runtime: dict, setting: str) -> str:
    from azure.keyvault.secrets import SecretClient
    vault = runtime.get("ai_credential_vault", "").strip()
    name = runtime.get(setting, "").strip()
    if not vault or not name:
        raise ValueError("AI credential Key Vault and secret name must be configured.")
    client = SecretClient(f"https://{vault}.vault.azure.net", _credential(runtime))
    return await run_in_threadpool(lambda: client.get_secret(name).value)


def redact(text: str) -> str:
    """Remove common secret/certificate material before external AI calls."""
    text = re.sub(r"-----BEGIN [^-]+-----.*?-----END [^-]+-----", "[REDACTED CERTIFICATE OR KEY]", text,
                  flags=re.I | re.S)
    text = re.sub(r"(?i)(password|passwd|secret|api[_ -]?key|otp|token)\s*[:=]\s*\S+",
                  r"\1=[REDACTED]", text)
    text = re.sub(r"\b\d{6}\b", "[REDACTED OTP]", text)
    return text[:8000]


_MATCH_STOP_WORDS = {
    "about", "after", "again", "also", "answer", "because", "before", "being", "can", "cannot",
    "could", "does", "error", "failed", "failure", "find", "from", "getting", "have",
    "help", "incorrect", "invalid", "into", "issue", "need", "not", "please", "problem", "show", "that", "the",
    "their", "there", "these", "they", "this", "unable", "want", "what", "when", "where",
    "which", "with", "would", "your",
}


def _match_tokens(text: str) -> list[str]:
    return [word for word in re.findall(r"[a-z0-9]+", text.lower())
            if len(word) >= 3 and word not in _MATCH_STOP_WORDS]


def _token_matches(word: str, candidate: str) -> bool:
    if word == candidate:
        return True
    word_root = word[:-1] if word.endswith("s") and len(word) > 4 else word
    candidate_root = candidate[:-1] if candidate.endswith("s") and len(candidate) > 4 else candidate
    if word_root == candidate_root:
        return True
    if len(word_root) < 4 or len(candidate_root) < 4:
        return False
    # Permit only a single typo, not broad word similarity. Adjacent transposition
    # handles "valut" -> "vault" without treating "inspect" as "inspection".
    if len(word_root) == len(candidate_root):
        differences = [index for index, pair in enumerate(zip(word_root, candidate_root))
                       if pair[0] != pair[1]]
        if len(differences) == 1:
            return True
        if len(differences) == 2 and differences[1] == differences[0] + 1:
            left = differences[0]
            return (word_root[left] == candidate_root[left + 1]
                    and word_root[left + 1] == candidate_root[left])
    if abs(len(word_root) - len(candidate_root)) == 1:
        shorter, longer = sorted((word_root, candidate_root), key=len)
        return any(longer[:index] + longer[index + 1:] == shorter
                   for index in range(len(longer)))
    return False


def knowledge_match(item: dict, question: str) -> dict:
    """Return the best excerpt plus a conservative confidence score.

    A match must cover the user's meaningful terms. Generic words such as "error"
    and "issue" cannot make an unrelated approved answer eligible.
    """
    content = item["content"].strip()
    title = item.get("title", "").strip()
    sections = ([content] if item.get("source_type") != "document"
                else [section.strip() for section in re.split(r"(?m)^(?=##+\s+)", content) if section.strip()])
    query_tokens = list(dict.fromkeys(_match_tokens(question)))
    error_intent = bool(re.search(
        r"\b(error|failed|failure|invalid|incorrect|unable|cannot|can't|problem|issue|troubleshoot)\b",
        question.lower()))
    if not query_tokens:
        return {"text": "", "score": 0.0, "confident": False, "matched_terms": []}

    def evaluate(section: str) -> tuple[float, list[str], float]:
        lines = section.splitlines()
        heading = (title + " " + (lines[0] if lines else "")).strip()
        heading_tokens = _match_tokens(heading)
        body_tokens = _match_tokens(section)
        matched = []
        heading_hits = 0
        for word in query_tokens:
            if any(_token_matches(word, candidate) for candidate in heading_tokens):
                matched.append(word)
                heading_hits += 1
            elif any(_token_matches(word, candidate) for candidate in body_tokens):
                matched.append(word)
        coverage = len(matched) / len(query_tokens)
        heading_coverage = heading_hits / len(query_tokens)
        value = coverage * 0.75 + heading_coverage * 0.25
        if matched and error_intent and re.search(
                r"\b(error|failed|failure|invalid|incorrect|unable|cannot|problem|issue|troubleshoot)\b",
                heading.lower()):
            value += 0.05
        return value, matched, heading_coverage

    ranked = sorted(((evaluate(section), section) for section in sections),
                    key=lambda value: value[0][0], reverse=True)
    (score, matched, heading_coverage), best = ranked[0] if ranked else ((0.0, [], 0.0), "")
    # Approved answers must closely match the section's question/title, not
    # merely mention the user's words somewhere in a long answer body.
    confident = bool(matched) and score >= 0.58 and heading_coverage >= 0.60
    return {"text": best[:5000] if confident else "", "score": round(min(score, 1.0), 3),
            "confident": confident, "matched_terms": matched}


def knowledge_excerpt(item: dict, question: str) -> str:
    """Backward-compatible helper that never returns a weak match."""
    return knowledge_match(item, question)["text"]


async def _openai(question: str, context: str, role: str, runtime: dict) -> str:
    key = os.getenv("OPENAI_API_KEY", "").strip()
    if not key:
        key = await _secret(runtime, "openai_api_key_secret_name")
    model = runtime.get("openai_model", "gpt-4.1-mini").strip()
    instructions = (
        "You are the CertRelay support assistant. Answer only about certificate relay, portal configuration, "
        "Azure Key Vault, authentication, audit/reporting, SMTP, SMP, IIS, and approved procedures. "
        f"The caller role is {role}. Never reveal credentials, OTPs, tokens, certificate bytes, private keys, "
        "or information belonging to another user. Use the approved context first. If uncertain, say so and "
        "recommend escalation. Do not claim that an action was completed."
    )
    payload = {"model": model, "instructions": instructions,
               "input": f"APPROVED CONTEXT\n{context}\n\nQUESTION\n{redact(question)}"}
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=False) as client:
            response = await client.post("https://api.openai.com/v1/responses", headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
    finally:
        headers.clear()
        key = ""
    parts = []
    for item in data.get("output", []):
        for content in item.get("content", []):
            if content.get("type") == "output_text" and content.get("text"):
                parts.append(content["text"])
    if not parts:
        raise ValueError("ChatGPT returned no answer.")
    return "\n".join(parts).strip()


async def _copilot(question: str, context: str, role: str, runtime: dict) -> str:
    secret = await _secret(runtime, "copilot_directline_secret_name")
    base = runtime.get("copilot_directline_url", "https://directline.botframework.com/v3/directline").rstrip("/")
    if not base.startswith("https://"):
        raise ValueError("Copilot Direct Line URL must use HTTPS.")
    headers = {"Authorization": f"Bearer {secret}", "Content-Type": "application/json"}
    user_id = "certrelay-" + uuid.uuid4().hex
    prompt = (f"CertRelay caller role: {role}. Use this approved context and do not expose secrets or other users' data.\n"
              f"{context}\n\nQuestion: {redact(question)}")
    try:
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=False) as client:
            created = await client.post(f"{base}/conversations", headers=headers)
            created.raise_for_status()
            conversation_id = created.json()["conversationId"]
            sent = await client.post(f"{base}/conversations/{conversation_id}/activities", headers=headers,
                                     json={"type": "message", "from": {"id": user_id}, "text": prompt})
            sent.raise_for_status()
            watermark = None
            for _ in range(12):
                await asyncio.sleep(0.5)
                params = {"watermark": watermark} if watermark else None
                received = await client.get(f"{base}/conversations/{conversation_id}/activities",
                                            headers=headers, params=params)
                received.raise_for_status()
                body = received.json()
                watermark = body.get("watermark")
                messages = [a.get("text", "") for a in body.get("activities", [])
                            if a.get("type") == "message" and a.get("from", {}).get("id") != user_id
                            and a.get("text")]
                if messages:
                    return messages[-1].strip()
    finally:
        headers.clear()
        secret = ""
    raise ValueError("Microsoft Copilot did not return an answer before the timeout.")


async def external_answer(provider: str, question: str, context: str, role: str, runtime: dict) -> str:
    safe_context = redact(context)
    if provider == "openai":
        return await _openai(question, safe_context, role, runtime)
    if provider == "copilot":
        return await _copilot(question, safe_context, role, runtime)
    raise ValueError("No external AI provider is selected.")
