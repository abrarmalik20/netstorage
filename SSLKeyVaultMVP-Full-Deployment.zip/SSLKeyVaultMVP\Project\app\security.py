# Written by AM — SSL Key Vault Certificate Relay Portal
import hashlib
import hmac
import secrets
import time
from dataclasses import dataclass


@dataclass
class CodeRecord:
    digest: bytes
    expires_at: float
    attempts: int = 0


class OneTimeCodeStore:
    """Process-memory-only OTP store. Use a distributed TTL cache for multi-instance production."""
    def __init__(self, secret: str, ttl_hours: int):
        self._key = secret.encode()
        self._ttl = ttl_hours * 3600
        self._records: dict[str, CodeRecord] = {}

    def _digest(self, email: str, code: str) -> bytes:
        return hmac.new(self._key, f"{email}:{code}".encode(), hashlib.sha256).digest()

    def issue(self, email: str, ttl_minutes: int | None = None) -> str:
        code = f"{secrets.randbelow(1_000_000):06d}"
        ttl = max(1, int(ttl_minutes)) * 60 if ttl_minutes is not None else self._ttl
        self._records[email] = CodeRecord(self._digest(email, code), time.time() + ttl)
        return code

    def verify(self, email: str, code: str) -> bool:
        record = self._records.get(email)
        if not record or record.expires_at < time.time() or record.attempts >= 5:
            self._records.pop(email, None)
            return False
        record.attempts += 1
        if not hmac.compare_digest(record.digest, self._digest(email, code)):
            return False
        self._records.pop(email, None)
        return True


def normalize_authorized_email(raw: str, allowed_domains: str | list[str]) -> str:
    email = raw.strip().lower()
    domains = [allowed_domains] if isinstance(allowed_domains, str) else allowed_domains
    domains = [d.strip().lower().lstrip("@") for d in domains if d.strip()]
    if email.count("@") != 1 or email.rsplit("@", 1)[1] not in domains:
        allowed = " or ".join(f"@{d}" for d in domains)
        raise ValueError(f"Only {allowed} accounts can sign in.")
    return email


def delivery_address(authorized_email: str, delivery_domain: str) -> str:
    return f"{authorized_email.split('@', 1)[0]}@{delivery_domain}"


def safe_certificate_name(name: str) -> str:
    value = name.strip().lower()
    if not value or len(value) > 127 or value[0] == "-" or value[-1] == "-":
        raise ValueError("Certificate name must be 1–127 characters.")
    if any(not (c.isalnum() or c == "-") for c in value):
        raise ValueError("Certificate name may contain only letters, numbers, and hyphens.")
    return value
