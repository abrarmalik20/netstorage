# Written by AM — SSL Key Vault Certificate Relay Portal
import ipaddress
import re
import socket
import ssl
from datetime import datetime, timezone

from cryptography import x509

from .certificates import certificate_metadata


HOST_RE = re.compile(r"^(?=.{1,253}\.?$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.?$", re.I)


def normalize_fqdn(value: str, allowed_suffixes: list[str]) -> str:
    fqdn = value.strip().lower().rstrip(".")
    if not HOST_RE.fullmatch(fqdn):
        raise ValueError("Enter a valid fully qualified domain name.")
    suffixes = [x.strip().lower().lstrip(".").rstrip(".") for x in allowed_suffixes if x.strip()]
    if not suffixes:
        raise ValueError("No FQDN suffixes are approved for live certificate comparison.")
    if not any(fqdn == suffix or fqdn.endswith("." + suffix) for suffix in suffixes):
        raise ValueError("This FQDN is not in an administrator-approved domain suffix.")
    return fqdn


def _approved_addresses(fqdn: str, port: int, allow_private: bool) -> list[str]:
    addresses = []
    for result in socket.getaddrinfo(fqdn, port, type=socket.SOCK_STREAM):
        address = result[4][0]
        ip = ipaddress.ip_address(address)
        if ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified or ip.is_reserved:
            continue
        if ip == ipaddress.ip_address("169.254.169.254"):
            continue
        if ip.is_private and not allow_private:
            continue
        if address not in addresses:
            addresses.append(address)
    if not addresses:
        raise ValueError("The FQDN did not resolve to an approved destination address.")
    return addresses


def fetch_live_certificate(fqdn: str, *, port: int = 443, timeout: int = 5,
                           allowed_suffixes: list[str] | None = None,
                           allow_private: bool = True) -> x509.Certificate:
    if port != 443:
        raise ValueError("Live certificate comparison is restricted to TCP port 443.")
    host = normalize_fqdn(fqdn, allowed_suffixes or [])
    addresses = _approved_addresses(host, port, allow_private)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    last_error = None
    for address in addresses:
        try:
            with socket.create_connection((address, port), timeout=timeout) as tcp:
                with context.wrap_socket(tcp, server_hostname=host) as tls:
                    der = tls.getpeercert(binary_form=True)
                    if not der:
                        raise ValueError("The endpoint did not present a TLS certificate.")
                    return x509.load_der_x509_certificate(der)
        except (OSError, ssl.SSLError, ValueError) as exc:
            last_error = exc
    raise ValueError("Unable to retrieve the live TLS certificate from the approved endpoint.") from last_error


def _dns_names(metadata: dict) -> list[str]:
    names = metadata.get("sans") or []
    if not names and metadata.get("common_name"):
        names = [metadata["common_name"]]
    return sorted({str(x).lower().rstrip(".") for x in names})


def hostname_covered(fqdn: str, names: list[str]) -> bool:
    host = fqdn.lower().rstrip(".")
    for name in names:
        pattern = name.lower().rstrip(".")
        if pattern == host:
            return True
        if pattern.startswith("*."):
            suffix = pattern[2:]
            if host.endswith("." + suffix) and host.count(".") == suffix.count(".") + 1:
                return True
    return False


def _comparison_value(value):
    if isinstance(value, list):
        return sorted(str(item) for item in value)
    return value


def _field_differences(live: dict, new: dict) -> list[dict]:
    fields = [
        ("issuer", "Issuer", "review"),
        ("subject", "Subject", "review"),
        ("key_type", "Public key type", "review"),
        ("key_size", "Public key size", "review"),
        ("signature_algorithm", "Signature algorithm", "review"),
        ("key_usage", "Key usage", "review"),
        ("extended_key_usage", "Extended key usage", "review"),
        ("not_before_utc", "Valid from", "information"),
        ("expires_utc", "Expiration", "information"),
        ("chain_count", "Chain certificate count", "review"),
    ]
    differences = []
    for key, label, severity in fields:
        live_value = live.get(key)
        new_value = new.get(key)
        if live_value is None and new_value is None:
            continue
        if _comparison_value(live_value) != _comparison_value(new_value):
            differences.append({"field": key, "label": label, "live_value": live_value,
                                "new_value": new_value, "severity": severity})
    return differences


def compare_metadata(fqdn: str, live: dict, new: dict) -> dict:
    live_names = _dns_names(live)
    new_names = _dns_names(new)
    missing = sorted(set(live_names) - set(new_names))
    additional = sorted(set(new_names) - set(live_names))
    shared = sorted(set(live_names) & set(new_names))
    live_expiry = datetime.fromisoformat(live["expires_utc"])
    new_expiry = datetime.fromisoformat(new["expires_utc"])
    warnings = []
    if not hostname_covered(fqdn, new_names):
        warnings.append("The new certificate does not cover the entered FQDN.")
    if missing:
        warnings.append(f"The new certificate is missing {len(missing)} DNS name(s) present in the live certificate.")
    if new_expiry <= datetime.now(timezone.utc):
        warnings.append("The new certificate is expired.")
    if new_expiry < live_expiry:
        warnings.append("The new certificate expires before the live certificate.")
    if (new.get("key_size") or 0) < (live.get("key_size") or 0):
        warnings.append("The new certificate uses a smaller public key than the live certificate.")
    field_differences = _field_differences(live, new)
    issuer_matches = _comparison_value(live.get("issuer")) == _comparison_value(new.get("issuer"))
    live_serial = str(live.get("serial_number") or "").upper()
    new_serial = str(new.get("serial_number") or "").upper()
    serial_numbers_match = bool(live_serial and new_serial and live_serial == new_serial)
    if any(item["field"] == "issuer" for item in field_differences):
        warnings.append("The new certificate was issued by a different certificate authority.")
    return {
        "fqdn": fqdn,
        "live": live,
        "new": new,
        "missing_in_new": missing,
        "additional_in_new": additional,
        "shared_names": shared,
        "field_differences": field_differences,
        "issuer_matches": issuer_matches,
        "serial_numbers_match": serial_numbers_match,
        "live_covers_fqdn": hostname_covered(fqdn, live_names),
        "new_covers_fqdn": hostname_covered(fqdn, new_names),
        "warnings": warnings,
        "result": "review" if warnings else "match",
    }


def comparison_policy_blockers(result: dict, runtime: dict) -> list[str]:
    blockers = []
    if runtime.get("live_compare_block_issuer_mismatch") and not result.get("issuer_matches", False):
        blockers.append("Transfer blocked: the live and new certificate issuers are different.")
    if runtime.get("live_compare_block_missing_names") and result.get("missing_in_new"):
        blockers.append("Transfer blocked: the new certificate is missing DNS/SAN names from the live certificate.")
    if runtime.get("live_compare_block_same_serial") and result.get("serial_numbers_match", False):
        blockers.append("Transfer blocked: the live and new certificates have the same serial number.")
    return blockers


def live_metadata(cert: x509.Certificate) -> dict:
    return certificate_metadata(cert, 0)
