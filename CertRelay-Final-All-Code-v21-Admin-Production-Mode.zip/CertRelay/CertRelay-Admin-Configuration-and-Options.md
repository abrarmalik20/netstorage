# CertRelay Admin Configuration and Options Guide

Written by AM

## Purpose and security model

CertRelay validates certificates in memory and relays them to an approved Azure Key Vault through VM managed identity. The portal database stores configuration and authorized metadata, not certificate bytes, private keys, certificate passwords, OTP plaintext, SMTP passwords, API keys, or raw session tokens.

## Recommended deployment baseline

- Run one Uvicorn worker on `127.0.0.1:8000`.
- Publish HTTP/HTTPS through IIS reverse proxy.
- Use HTTPS for remote OTP login and secure cookies.
- Configure IIS to forward the original protocol.
- Enable production transfer only after managed identity and Key Vault permissions pass testing.
- Keep certificates/passwords in request memory enabled only while the relay is operational.
- Store external-service credentials in Azure Key Vault.
- Give the VM identity only required permissions.
- Keep both chatbots disabled until their approved knowledge and provider are configured.

## Allowed domains

### Login domain

Domain whose users may request regular-user OTP authentication, for example `blueshieldca.com`. Enter only the domain without `@`, protocol, path, or spaces.

### OTP delivery domain

Optional mapped email-delivery domain, for example `bse.bscal.com`. CertRelay can authorize `user@blueshieldca.com` while delivering the code to the corresponding approved internal address. Confirm the mapping with the email/security team.

### Activate, deactivate, and delete

- **Deactivate** temporarily prevents use while preserving configuration.
- **Activate** restores use.
- **Delete** permanently removes the record. Use only when dependencies and compliance requirements allow it.

## Authorized users

### Email

Exact authorized address. Domain authorization permits regular users, while this list is also used for explicitly authorized accounts and administrator roles.

### Role

- **User**: certificate portal and permitted User Chatbot access.
- **Admin**: OTP-protected Admin portal, configuration, organization-level audits/reports, and Admin Chatbot access.

An administrator cannot deactivate their own currently authenticated Admin account. Maintain at least two controlled Admin accounts for recovery.

## Subscriptions

### Subscription ID

The real Azure subscription GUID containing the Key Vault. Placeholder IDs must be replaced before production use.

### Name

Human-readable subscription/environment name, for example `bsc-npn`, `bsc-pp`, or `bsc-prd`.

### Environment token

Short token expected in the organization’s Key Vault naming pattern, such as `npn`, `pp`, or `prd`.

Editing a subscription ID updates linked configured Key Vault destinations. The new ID must not already exist.

## Regions

### Region token

Short organization token used in the Key Vault name, for example:

- `cus` for Central US
- `eus2` for East US 2

Use lowercase without spaces.

### Display name

User-facing Azure region name, such as `Central US` or `East US 2`. Spaces and capitalization are appropriate here.

Changing a region token updates linked configured destinations.

## Key Vault destinations

### Vault name

Exact Azure Key Vault resource name, such as `kv-nw-npn-ics-sc-cus-22`.

### Subscription

Configured subscription that owns the destination.

### Region

Configured region token corresponding to the destination.

Only active destinations matching both the selected subscription and region are presented to users. The configured name must match the real Azure Key Vault name exactly.

For an Application Gateway renewal, CertRelay inspects the selected vault and reuses the exact existing Key Vault certificate object name when exactly one latest certificate has the same X.509 Common Name. This allows the import to create a new version under the stable name already referenced by Application Gateway.

## Production, email relay, and identity

### Enable production transfers

- **Off**: validation/test workflow; no Azure import.
- **On**: immediately turns off demo behavior and permits real Azure Key Vault import through managed identity. Saving the Admin setting does not require an application restart or `.env` edit.

In `APP_MODE=azure`, the read-only existing-certificate CN lookup still runs while production transfers are off. This allows administrators to validate name matching without importing a certificate. If the bootstrap setting is `APP_MODE=mock`, enabling production overrides it at runtime and performs the real Azure lookup and import; disabling production returns to demo behavior.

Recommended: leave production transfers off until the correct destination and managed-identity test succeed. This setting is independent of OTP email delivery.

### Enable OTP email relay for regular users

Controls whether regular-user OTPs are sent through SMTP. In production, enable it only after SMTP testing succeeds.

### Approved ticket required for certificate transfer

When enabled, transfer is blocked unless a ticket number is entered. This validates presence and format; use SMP verification when status confirmation is required.

### SMTP relay host

Approved internal SMTP relay DNS name or IP. Do not include `smtp://` or a path.

### SMTP port

Use the company-approved port:

- `25` commonly represents an internal relay, often without STARTTLS depending on company policy.
- `587` commonly represents authenticated message submission with STARTTLS.

Confirm the correct port and security requirements with the email team.

### Sender address

Approved sender identity, for example `CertRelay <no-reply@blueshieldca.com>`. The relay must permit this address.

### Use STARTTLS

Enable only when the relay supports or requires STARTTLS on the selected port. For a port-25 relay that does not support STARTTLS, leave unchecked. Follow company security policy.

### Managed identity type

- **VM system-assigned**: uses the identity attached directly to the CertRelay VM.
- **User-assigned**: uses a separately managed Azure identity.

### User-assigned client ID

Required only when **User-assigned** is selected. Enter the identity’s Azure client ID, not object ID, subscription ID, secret, or password.

### Test managed identity

Select a configured Key Vault and run the test before enabling production. A successful test confirms authentication and certificate-list access. The production identity must also be able to read the latest public certificate and import a certificate.

## Azure managed-identity requirements

1. Enable the selected identity on the VM.
2. Grant the minimum Key Vault data-plane permissions needed to list certificates, get the latest public certificate, and import certificates. The built-in **Key Vault Certificates Officer** role is suitable when Azure RBAC is used; a custom role must include equivalent operations.
3. Confirm Key Vault firewall/private-endpoint access from the VM.
4. Confirm DNS resolution for the Key Vault endpoint.
5. Configure the exact vault, subscription, and region in CertRelay.
6. Test identity access.
7. Enable production transfers.

Do not configure end-user Azure usernames/passwords in CertRelay.

## SMP ticket verification

### Enable SMP ticket verification

Allows users to verify ticket status through the configured SMP API.

### Require successful SMP verification before transfer

Blocks transfer until verification succeeds. The enable checkbox must also be selected.

### SMP API base URL

HTTPS base address of the approved SMP API. Do not enter a UI page if a REST API endpoint is required.

### Authentication type

- **Bearer token**: retrieves the configured token secret.
- **Username and password**: retrieves the configured username/password secrets and sends Basic authentication only over HTTPS.

### Credential Key Vault name

Azure Key Vault holding SMP credential secrets. Store only this vault name and the following secret names in CertRelay.

### Approved statuses

Comma-separated lowercase status values considered approved, such as `approved, implemented`. Use values exactly as returned by the SMP API.

### Token, username, and password secret names

Names of secrets in the credential Key Vault. Do not enter the credential values themselves.

## OTP and session controls

### Regular-user OTP validity

Number of minutes a newly issued regular-user code remains valid. Recommended starting point: 10–15 minutes.

### Regular-user idle timeout

Minutes without authenticated activity before the user must sign in again. Recommended starting point: 15 minutes.

### Admin OTP validity

Minutes an Admin OTP remains valid. Recommended starting point: 5–10 minutes.

### Admin idle timeout

Minutes without Admin activity before reauthentication. Recommended starting point: 15 minutes.

OTP validity and session idle timeout are different. Time spent waiting for an OTP occurs before the authenticated idle session starts.

### Session behavior

Sessions are represented by signed cookies. The database stores only a one-way session-token hash. HTTPS, forwarded-protocol headers, cookie path, hostname/IP, and IIS configuration must be correct for remote login.

## Audit controls

### Audit retention value and unit

Controls retention for login and activity audits. Units are hours, weeks, or 30-day months. Choose a period consistent with operational and compliance policy.

### Login audit

Contains OTP request, user login/logout, and Admin login/logout events, including success/failure and sanitized reason.

### User activity audit

Contains inspection, comparison, destination lookup, transfer, assistant, report-email, and configuration-related events. It excludes certificate bytes, private keys, passwords, OTP values, raw tokens, and thumbprints retained by old builds.

### Clear all audit history

Permanently deletes current login and activity audit rows. Use only according to retention/compliance policy.

## Certificate history and reporting

### Certificate-name history retention

Retains successful production-transfer metadata for one to three years. It includes names, uploader, time, ticket, destination, and expiration—not certificate bytes or passwords.

### Search history

Search by generated Key Vault certificate name, certificate CN, or ticket number.

### Certificate expiration report

Choose a one-, two-, or three-year import range and select **Create report**. The report includes expiration/import metadata held by CertRelay.

### Email CSV to me

Generates the report CSV in memory and sends it through the configured SMTP relay only to the signed-in administrator. The CSV is not intentionally written to server storage.

## Certificate/password request-memory control

### Enable in-memory certificate/password relay

- **On**: permits inspection, conversion, comparison, and transfer.
- **Off**: blocks certificate/password processing.

This is an operational emergency control. It does not enable persistent certificate storage.

## Key Vault certificate naming

The naming rule is enforced and is not user-editable:

1. CertRelay lists certificate objects in the selected Key Vault.
2. It reads each object's latest public X.509 certificate in request memory and compares its CN with the uploaded certificate CN, ignoring case and one trailing period.
3. Exactly one match reuses that object's exact Key Vault name and the import creates a new version.
4. No match creates a normalized CN name, such as `webtestcert-bsc-bscal-com`.
5. More than one match blocks the transfer for administrator review; CertRelay never guesses which object Application Gateway uses.
6. A normalized-name collision with a different or unreadable certificate also blocks the transfer.
7. The backend repeats the lookup immediately before import and ignores any certificate name supplied by the browser.

Certificate bytes used for the lookup are not written to CertRelay storage. Azure Key Vault object names do not permit periods, and the certificate's internal CN/SAN values are not changed.

### Application Gateway requirement

Configure Application Gateway with the **versionless** Key Vault secret URI:

```text
https://<vault-name>.vault.azure.net/secrets/<certificate-object-name>/
```

Do not pin the URI to a secret version. Reusing the object name then allows Application Gateway to retrieve the renewed version. The Application Gateway identity separately requires secret-read access and network connectivity to the Key Vault.

## Live certificate comparison

### Enable comparison

Shows the FQDN comparison feature and permits retrieval of an approved live TLS certificate on TCP 443.

### Require completed comparison

Blocks transfer until a successful, unexpired comparison is completed for the same uploaded certificate.

### Approved FQDN suffixes

Comma-separated suffix allowlist, for example `bsc.bscal.com`. Enter host suffixes only—no protocol, wildcard, path, port, or credentials.

### Connection timeout

Seconds allowed for DNS/TCP/TLS retrieval. Recommended: 5–10 seconds. Allowed range: 1–30 seconds.

### Allow approved internal/private DNS destinations

Allows approved company internal/private destinations. Loopback, link-local, multicast, reserved, and Azure metadata destinations remain blocked.

### Block issuer mismatch

Blocks transfer when the live certificate issuer differs from the new certificate issuer.

### Block missing DNS/SAN names

Blocks transfer when a DNS name present in the live certificate is absent from the new certificate.

### Block matching serial number

Blocks transfer when the live and new certificates have the same serial number, helping prevent reimport of the same certificate.

Enabling any blocking comparison policy requires live comparison to remain enabled.

## Certificate fields shown to users

Admin may select fields including:

- **Certificate name / CN**: primary subject identity.
- **Subdomains / SANs**: additional covered DNS names.
- **Issuer**: certificate authority/issuer identity.
- **Expiration date**: end of validity.
- **Days remaining**: calculated time before expiration.
- **Valid from**: beginning of validity.
- **Subject**: complete subject distinguished name.
- **Serial number**: issuer-assigned unique certificate identifier.
- **SHA-256 thumbprint**: certificate fingerprint; display only when policy permits.
- **Key type and key size**: public-key algorithm and strength.
- **Chain certificates**: number of included chain certificates.

## AI Assistant controls

### Enable chatbot for certificate portal users

Shows the User Chatbot after successful user authentication and enables its backend endpoint. When unchecked, the widget is hidden and requests are rejected.

### Enable chatbot for administrators

Shows the Admin Chatbot after Admin authentication and enables its backend endpoint. This is independent of the User Chatbot.

### Answer mode

- **Admin-approved Q&A only**: no external AI; answers from approved stored content.
- **Approved Q&A with external AI**: external AI explains the question using approved context.
- **Approved answer first; external AI when no match**: uses a matching approved answer directly and calls external AI only when no match exists.
- **External AI with approved context**: sends sanitized question and approved context to the selected provider.

Recommended production starting mode: **Approved answer first; external AI when no match**.

### AI provider

- **No external AI**: approved knowledge only.
- **ChatGPT / OpenAI**: OpenAI Responses API.
- **Microsoft Copilot Studio**: Copilot Studio agent through Direct Line.

### AI credential Key Vault

Key Vault holding the external AI secret. The selected VM managed identity must have permission to read only the required secret.

### ChatGPT API-key secret name

Name of the Key Vault secret containing the OpenAI API key. Do not enter the key itself.

### ChatGPT model

Approved model identifier available to the organization’s OpenAI account. Confirm availability and cost with the account administrator.

### Local ChatGPT testing

For local development only, set `OPENAI_API_KEY` in the process environment before starting the portal. Do not save a real key in source code, `.env.example`, the database, screenshots, email, or approved knowledge.

### Copilot Direct Line secret name

Name of the Key Vault secret containing the Copilot Studio Direct Line secret.

### Copilot Direct Line URL

Default: `https://directline.botframework.com/v3/directline`. Change only when Microsoft/company architecture requires a different approved Direct Line endpoint.

### Allow troubleshooting assistance

Permits troubleshooting guidance. Approved knowledge should define supported systems, safe diagnostic steps, and escalation boundaries.

### Allow role-authorized audit and report assistance

Permits the Admin chatbot to receive sanitized audit/report metadata and regular users to receive only their own permitted activity context. It never authorizes users to access other users’ records.

## Assistant approved knowledge

### Question or title

Short search-friendly title, such as `How to resolve OTP delivery failure`.

### Audience

- **Users and administrators**: general process content.
- **Users only**: user workflow information.
- **Administrators only**: infrastructure, audit, provider, or privileged configuration information.

### Content type

- **Question and answer**: focused FAQ entry.
- **Instruction document**: longer process or troubleshooting procedure.

### Load text or Markdown file

Loads `.txt`, `.md`, or `.csv` content up to 100 KB into the editor. Admin must review it before saving. The file is used to populate portal documentation; do not upload secrets or certificate/key material.

### Approved answer or instructions

Authoritative content used by the assistant. Keep it current, scoped, and free of secrets. Use Edit to revise and Delete to permanently remove an item.

## Chatbot data-safety rules

Never include:

- Certificate/PFX/PEM bytes
- Private keys
- Certificate passwords
- OTP values
- Session cookies or tokens
- SMTP credentials
- API keys or Direct Line secrets
- Azure access tokens
- Key Vault secret values

CertRelay redacts common secret patterns before external AI requests, but administrators and users must still avoid entering sensitive content.

## ChatGPT local configuration

1. Obtain an authorized OpenAI API key.
2. In the same PowerShell window used to start CertRelay, set:

   `$env:OPENAI_API_KEY = "YOUR-KEY"`

3. Start CertRelay.
4. Sign in to Admin.
5. Select the required User/Admin chatbot checkboxes.
6. Choose the answer mode.
7. Select **ChatGPT / OpenAI**.
8. Enter an approved model identifier.
9. Save settings.
10. Add/review approved knowledge.
11. Test with non-sensitive questions.
12. Remove the environment value after testing by closing the process/window or explicitly clearing it.

## ChatGPT production configuration

1. Store the API key as a secret in the approved Azure Key Vault.
2. Grant the VM identity minimum secret-read permission.
3. Configure **AI credential Key Vault**.
4. Configure **ChatGPT API-key secret name**.
5. Select the approved model and answer mode.
6. Enable only the required chatbot(s).
7. Test role isolation and redaction with non-sensitive data.

## Microsoft Copilot Studio configuration

1. Create or select the company-approved Copilot Studio agent.
2. Add its governed knowledge and instructions.
3. Enable the approved Direct Line/custom website channel according to Microsoft/company policy.
4. Store the Direct Line secret in Azure Key Vault.
5. Grant the CertRelay VM identity minimum read access to that secret.
6. Configure the AI credential Key Vault and Direct Line secret name in Admin.
7. Select **Microsoft Copilot Studio**.
8. Keep the default Direct Line URL unless company architecture specifies another endpoint.
9. Select the answer mode.
10. Enable User and/or Admin Chatbot.
11. Save and test both roles with non-sensitive questions.

## Troubleshooting common platform errors

### Port 8000 already in use

Another process is listening. Find the owning process before starting a second instance. Keep one Uvicorn worker for the current session/OTP architecture.

### IIS 502 Bad Gateway

Confirm CertRelay is running on `127.0.0.1:8000`, IIS ARR proxy is enabled, URL Rewrite is installed, the rewrite target is correct, and local firewall/security software is not blocking the connection.

### Remote OTP verifies but `/api/options` returns 401

Confirm HTTPS is used, IIS sets the forwarded protocol correctly, proxy headers are trusted only from the local proxy, and the browser returns the secure cookie for the same host/IP.

### SMTP delivery fails

Confirm host, port, sender permission, STARTTLS requirement, firewall route, relay allowlist, and whether authentication is required. Test from the VM with company-approved tools without exposing credentials.

### Managed identity fails

Confirm selected identity, client ID for user-assigned identity, Azure role/access policy, Key Vault firewall/private endpoint, DNS, and destination name.

### ChatGPT provider unavailable

Confirm the environment variable for local testing or Key Vault/secret names for production, VM identity secret access, outbound HTTPS access to the approved OpenAI endpoint, valid model access, API quota, and account billing/limits.

### Copilot provider unavailable

Confirm the agent is published, Direct Line is enabled, the secret is current, Key Vault access succeeds, the endpoint is HTTPS, and outbound access to Direct Line is permitted.

### Approved Q&A gives an unrelated answer

Use specific titles and focused content. Separate broad documents into multiple entries. Review audience settings and choose external fallback when approved keyword matching is insufficient.

## Jira status

The current v13 AI Assistant provides guidance and escalation recommendations. Automated Jira ticket creation is not included in v13. Do not tell users that a Jira ticket was created unless a future approved connector returns a confirmed ticket key.

