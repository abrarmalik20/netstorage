/* Written by AM — CertRelay */
(() => {
  const widget=document.getElementById('assistantWidget');
  if(!widget)return;
  const admin=location.pathname.startsWith('/admin');
  const endpoint=admin?'/api/admin/assistant/chat':'/api/assistant/chat';
  const panel=document.getElementById('assistantPanel');
  const messages=document.getElementById('assistantMessages');
  const form=document.getElementById('assistantForm');
  const question=document.getElementById('assistantQuestion');
  document.getElementById('assistantToggle').onclick=()=>{panel.hidden=false;question.focus()};
  document.getElementById('assistantClose').onclick=()=>{panel.hidden=true};
  function message(text,kind){const p=document.createElement('p');p.className='assistant-'+kind;p.textContent=text;messages.append(p);messages.scrollTop=messages.scrollHeight;return p}
  form.onsubmit=async event=>{
    event.preventDefault();const value=question.value.trim();if(!value)return;
    message(value,'user');question.value='';const waiting=message('Working…','bot');
    try{const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:value})});const data=await response.json();if(!response.ok)throw new Error(data.detail||'Assistant request failed');waiting.textContent=data.answer;const small=document.createElement('small');small.textContent='Source: '+data.source;waiting.append(document.createElement('br'),small)}catch(error){waiting.textContent=error.message}
  };
  let welcomed=false;
  window.certRelayAssistant={show(enabled,email=''){widget.hidden=!enabled;if(!enabled){panel.hidden=true;return}if(!welcomed&&email){const username=email.split('@')[0]||email;const first=messages.querySelector('.assistant-bot');if(first)first.textContent=`Welcome ${username} to the CertRelay Assistant. How can I help you today?`;welcomed=true}}};
})();
