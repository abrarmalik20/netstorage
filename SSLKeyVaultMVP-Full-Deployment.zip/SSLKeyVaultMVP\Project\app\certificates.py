# Written by AM — SSL Key Vault Certificate Relay Portal
from dataclasses import dataclass
from datetime import datetime, timezone
import re
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.serialization import pkcs12


@dataclass
class PreparedCertificate:
    pfx: bytes
    password: bytes
    common_name: str
    expires_utc: str
    metadata: dict


def certificate_metadata(cert: x509.Certificate, chain_count: int = 0) -> dict:
    try:
        sans = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value.get_values_for_type(x509.DNSName)
    except x509.ExtensionNotFound:
        sans = []
    common_name = _cn(cert)
    public_key = cert.public_key()
    key_type = public_key.__class__.__name__.replace("PublicKey", "").replace("_", "")
    expires = cert.not_valid_after_utc
    try:
        key_usage = cert.extensions.get_extension_for_class(x509.KeyUsage).value
        usages = [name for name in ("digital_signature", "content_commitment", "key_encipherment",
                                    "data_encipherment", "key_agreement", "key_cert_sign", "crl_sign")
                  if getattr(key_usage, name)]
    except x509.ExtensionNotFound:
        usages = []
    try:
        eku = [oid._name or oid.dotted_string for oid in
               cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value]
    except x509.ExtensionNotFound:
        eku = []
    suggested = re.sub(r"[^a-z0-9-]+", "-", common_name.lower().replace("*", "wildcard")).strip("-")[:127]
    return {
        "common_name": common_name,
        "suggested_name": suggested or "certificate",
        "subject": cert.subject.rfc4514_string(),
        "issuer": cert.issuer.rfc4514_string(),
        "sans": sans,
        "not_before_utc": cert.not_valid_before_utc.isoformat(),
        "expires_utc": expires.isoformat(),
        "days_remaining": max(0, (expires - datetime.now(timezone.utc)).days),
        "serial_number": format(cert.serial_number, "X"),
        "sha256_thumbprint": cert.fingerprint(hashes.SHA256()).hex().upper(),
        "key_type": key_type,
        "key_size": getattr(public_key, "key_size", None),
        "signature_algorithm": cert.signature_algorithm_oid._name or cert.signature_algorithm_oid.dotted_string,
        "key_usage": usages,
        "extended_key_usage": eku,
        "chain_count": chain_count,
    }


def inspect_certificate(data: bytes, filename: str, supplied_password: str) -> dict:
    password = supplied_password.encode() if supplied_password else None
    lower = filename.lower()
    if lower.endswith((".pfx", ".p12")):
        key, cert, chain = pkcs12.load_key_and_certificates(data, password)
        if key is None or cert is None:
            raise ValueError("PFX must contain both a certificate and its private key.")
        return certificate_metadata(cert, len(chain or []))
    certs = _find_pem_certificates(data)
    if not certs:
        raise ValueError("PEM does not contain an X.509 certificate.")
    serialization.load_pem_private_key(data, password=password)
    return certificate_metadata(certs[0], max(0, len(certs) - 1))


def _find_pem_certificates(data: bytes) -> list[x509.Certificate]:
    marker = b"-----END CERTIFICATE-----"
    certs = []
    for part in data.split(marker):
        if b"-----BEGIN CERTIFICATE-----" in part:
            block = part[part.index(b"-----BEGIN CERTIFICATE-----"):] + marker + b"\n"
            certs.append(x509.load_pem_x509_certificate(block))
    return certs


def prepare_as_pfx(data: bytes, filename: str, supplied_password: str) -> PreparedCertificate:
    password = supplied_password.encode() if supplied_password else None
    lower = filename.lower()
    if lower.endswith((".pfx", ".p12")):
        key, cert, chain = pkcs12.load_key_and_certificates(data, password)
        if key is None or cert is None:
            raise ValueError("PFX must contain both a certificate and its private key.")
        metadata = certificate_metadata(cert, len(chain or []))
        return PreparedCertificate(data, password or b"", _cn(cert), cert.not_valid_after_utc.isoformat(), metadata)
    if not lower.endswith((".pem", ".crt", ".cer", ".key")):
        raise ValueError("Upload a PFX, P12, or PEM file.")
    certs = _find_pem_certificates(data)
    if not certs:
        raise ValueError("PEM does not contain an X.509 certificate.")
    try:
        key = serialization.load_pem_private_key(data, password=password)
    except (TypeError, ValueError) as exc:
        raise ValueError("PEM must include its private key; check the password if encrypted.") from exc
    # PKCS#12 password bytes must be valid UTF-8 for OpenSSL/cryptography.
    output_password = __import__("secrets").token_urlsafe(24).encode("ascii")
    pfx = pkcs12.serialize_key_and_certificates(
        name=_cn(certs[0]).encode(), key=key, cert=certs[0], cas=certs[1:] or None,
        encryption_algorithm=serialization.BestAvailableEncryption(output_password),
    )
    metadata = certificate_metadata(certs[0], max(0, len(certs) - 1))
    return PreparedCertificate(pfx, output_password, _cn(certs[0]), certs[0].not_valid_after_utc.isoformat(), metadata)


def _cn(cert: x509.Certificate) -> str:
    attrs = cert.subject.get_attributes_for_oid(x509.NameOID.COMMON_NAME)
    return attrs[0].value if attrs else "certificate"
