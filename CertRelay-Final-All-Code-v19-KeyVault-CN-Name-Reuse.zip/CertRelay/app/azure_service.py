# Written by AM — CertRelay
from dataclasses import dataclass
from azure.identity import DefaultAzureCredential, ManagedIdentityCredential
from azure.mgmt.resource import SubscriptionClient
from azure.mgmt.keyvault import KeyVaultManagementClient
from azure.keyvault.certificates import CertificateClient
from cryptography import x509
from cryptography.x509.oid import NameOID


@dataclass(frozen=True)
class Subscription:
    id: str
    name: str


class AzureService:
    def __init__(self, settings):
        self.settings = settings
        self.credential = DefaultAzureCredential(exclude_interactive_browser_credential=True)

    def subscriptions(self) -> list[Subscription]:
        if self.settings.app_mode == "mock":
            return [Subscription("00000000-0000-0000-0000-000000000001", "bsc-npn"),
                    Subscription("00000000-0000-0000-0000-000000000002", "bsc-prd")]
        allowed = {x.lower() for x in self.settings.allowed_subscriptions}
        result = [Subscription(s.subscription_id, s.display_name) for s in SubscriptionClient(self.credential).subscriptions.list()]
        return [s for s in result if not allowed or s.name.lower() in allowed]

    @staticmethod
    def environment_token(subscription_name: str) -> str:
        """Return the first naming token after the exact `bsc-` prefix."""
        normalized = subscription_name.strip().lower()
        if not normalized.startswith("bsc-") or len(normalized) <= 4:
            raise ValueError("Subscription name must follow the bsc-<environment> naming convention.")
        return normalized[4:].split("-", 1)[0]

    @staticmethod
    def name_matches(vault_name: str, environment: str, region_token: str) -> bool:
        segments = {segment for segment in vault_name.lower().split("-") if segment}
        return environment.lower() in segments and region_token.lower() in segments

    def matching_vaults(self, subscription_id: str, subscription_name: str, region_token: str) -> list[str]:
        override = self.settings.vault_overrides.get(f"{subscription_id}|{region_token}")
        if override:
            return [override]
        environment = self.environment_token(subscription_name)
        if self.settings.app_mode == "mock":
            sample = [
                f"kv-nw-{environment}-ics-sc-{region_token}-22",
                f"kv-app-{environment}-shared-{region_token}-01",
                f"kv-nw-other-ics-sc-{region_token}-99",
                f"kv-nw-{environment}-ics-sc-other-98",
            ]
            return sorted(v for v in sample if self.name_matches(v, environment, region_token))
        vaults = list(KeyVaultManagementClient(self.credential, subscription_id).vaults.list())
        candidates = sorted(v.name for v in vaults if self.name_matches(v.name, environment, region_token))
        if not candidates:
            raise ValueError(
                f"No Key Vault matches environment '-{environment}-' and region '-{region_token}-'."
            )
        return candidates

    def import_certificate(self, vault_name: str, cert_name: str, pfx: bytes, password: bytes):
        if self.settings.app_mode == "mock":
            return {"id": f"https://{vault_name}.vault.azure.net/certificates/{cert_name}/mock-version"}
        client = CertificateClient(f"https://{vault_name}.vault.azure.net", self.credential)
        result = client.import_certificate(cert_name, pfx, password=password.decode() or None)
        return {"id": result.id}

    @staticmethod
    def _managed_credential(identity_type: str, client_id: str = ""):
        return (ManagedIdentityCredential(client_id=client_id)
                if identity_type == "user" and client_id else ManagedIdentityCredential())

    @staticmethod
    def _normalized_common_name(value: str) -> str:
        return value.strip().casefold().rstrip(".")

    @classmethod
    def choose_certificate_name(cls, common_name: str, existing: list[tuple[str, str]],
                                fallback_name: str) -> dict:
        """Choose one existing Key Vault object name whose current cert CN matches."""
        target = cls._normalized_common_name(common_name)
        matches = sorted({name for name, cn in existing
                          if cls._normalized_common_name(cn) == target}, key=str.casefold)
        if len(matches) > 1:
            raise ValueError(
                "More than one Key Vault certificate has the uploaded certificate Common Name: "
                + ", ".join(matches)
                + ". Deactivate the duplicate or contact the Network Team before transferring."
            )
        name_collisions = sorted({name for name, cn in existing
                                  if name.casefold() == fallback_name.casefold()
                                  and cls._normalized_common_name(cn) != target},
                                 key=str.casefold)
        if not matches and name_collisions:
            raise ValueError(
                f"Key Vault already contains a certificate named {name_collisions[0]}, but its "
                "current Common Name does not match the uploaded certificate or cannot be read. "
                "Transfer is blocked to prevent updating the wrong certificate object. Contact "
                "the Network Team or CertRelay administrator."
            )
        return {"name": matches[0] if matches else fallback_name,
                "matched_existing": bool(matches)}

    def resolve_certificate_name(self, vault_name: str, common_name: str, fallback_name: str,
                                 production_enabled: bool, identity_type: str,
                                 client_id: str = "") -> dict:
        """Resolve the Key Vault object name without persisting certificate material.

        In production, the latest public certificate version for each Key Vault object is
        inspected in memory. If its X.509 CN matches, its existing object name is reused.
        Non-production mode performs no Azure read and returns the normalized CN fallback.
        """
        if not production_enabled or self.settings.app_mode == "mock":
            return {"name": fallback_name, "matched_existing": False}
        credential = self._managed_credential(identity_type, client_id)
        client = CertificateClient(f"https://{vault_name}.vault.azure.net", credential)
        existing = []
        for properties in client.list_properties_of_certificates():
            current = client.get_certificate(properties.name)
            certificate = None
            certificate_common_name = ""
            if not current.cer:
                existing.append((properties.name, certificate_common_name))
                continue
            try:
                certificate = x509.load_der_x509_certificate(bytes(current.cer))
                attributes = certificate.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
                if attributes:
                    certificate_common_name = attributes[0].value
            except ValueError:
                # Retain the object name so an unreadable certificate cannot be overwritten.
                certificate_common_name = ""
            finally:
                existing.append((properties.name, certificate_common_name))
                current = None
                certificate = None
        return self.choose_certificate_name(common_name, existing, fallback_name)

    def relay_certificate(self, vault_name: str, cert_name: str, pfx: bytes, password: bytes,
                          production_enabled: bool, identity_type: str, client_id: str = ""):
        if not production_enabled:
            return {"id": f"https://{vault_name}.vault.azure.net/certificates/{cert_name}/mock-version"}
        credential = self._managed_credential(identity_type, client_id)
        client = CertificateClient(f"https://{vault_name}.vault.azure.net", credential)
        result = client.import_certificate(cert_name, pfx, password=password.decode() or None)
        return {"id": result.id}

    def test_managed_identity(self, vault_name: str, identity_type: str, client_id: str = ""):
        credential = self._managed_credential(identity_type, client_id)
        client = CertificateClient(f"https://{vault_name}.vault.azure.net", credential)
        first = next(iter(client.list_properties_of_certificates()), None)
        if first is not None:
            client.get_certificate(first.name)
        return {"certificate_list_succeeded": True,
                "certificate_get_tested": first is not None}
