# Written by AM — CertRelay
import base64
import logging
import re
import sqlite3
import time
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.concurrency import run_in_threadpool
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from pydantic import BaseModel, Field

from .azure_service import AzureService
from .certificates import inspect_certificate, prepare_as_pfx
from .config import get_settings
from .config_store import ConfigStore
from .mailer import send_code
from .live_compare import compare_metadata, comparison_policy_blockers, fetch_live_certificate, live_metadata
from .security import OneTimeCodeStore, delivery_address, normalize_authorized_email, safe_certificate_name

settings = get_settings()
app = FastAPI(title="CertRelay", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")
codes = OneTimeCodeStore(settings.app_secret_key, settings.otp_ttl_hours)
signer = URLSafeTimedSerializer(settings.app_secret_key, salt="ssl-portal-session")
admin_signer = URLSafeTimedSerializer(settings.app_secret_key, salt="ssl-portal-admin-session")
comparison_signer = URLSafeTimedSerializer(settings.app_secret_key, salt="ssl-portal-live-comparison")
session_activity: dict[str, float] = {}
admin_session_activity: dict[str, float] = {}
azure = AzureService(settings)
store = ConfigStore(settings.config_db_path, settings.initial_admin_email)
log = logging.getLogger("ssl_portal")


class EmailRequest(BaseModel):
    email: str


class VerifyRequest(BaseModel):
    email: str
    code: str = Field(pattern=r"^\d{6}$")


class ResolveRequest(BaseModel):
    subscription_id: str
    region: str


class UploadRequest(BaseModel):
    filename: str
    content_b64: str
    password: str = ""
    certificate_name: str = ""  # Compatibility only; server generates the final name.
    subscription_id: str
    region: str
    confirmation_vault: str
    comparison_token: str = ""
    ticket_number: str = ""


class InspectRequest(BaseModel):
    filename: str
    content_b64: str
    password: str = ""


class CompareLiveRequest(InspectRequest):
    fqdn: str
    port: int = Field(default=443, ge=1, le=65535)


class IdentityTestRequest(BaseModel):
    vault_name: str


class DomainAdmin(BaseModel):
    domain: str
    delivery_domain: str


class UserAdmin(BaseModel):
    email: str
    role: str = Field(pattern=r"^(admin|user)$")


class SubscriptionAdmin(BaseModel):
    id: str
    name: str
    environment: str
    original_id: str | None = None


class RegionAdmin(BaseModel):
    token: str
    display_name: str
    original_token: str | None = None


class VaultAdmin(BaseModel):
    name: str
    subscription_id: str
    region: str
    original_name: str | None = None


class ActiveAdmin(BaseModel):
    table: str
    key: str
    active: bool


class DeleteAdmin(BaseModel):
    table: str
    key: str


def session_email(request: Request) -> str:
    token = request.cookies.get("ssl_session")
    if not token:
        raise HTTPException(401, "Sign in required.")
    try:
        email = signer.loads(token, max_age=7 * 24 * 3600)["email"]
    except (BadSignature, SignatureExpired, KeyError):
        raise HTTPException(401, "Session expired. Please sign in again.")
    now = time.time()
    idle_seconds = int(store.settings().get("user_idle_minutes", 15)) * 60
    last_seen = session_activity.get(token)
    if last_seen is None or now - last_seen > idle_seconds:
        session_activity.pop(token, None)
        raise HTTPException(401, "Session expired after inactivity. Please sign in again.")
    session_activity[token] = now
    return email


def require_admin(request: Request) -> str:
    token = request.cookies.get("ssl_admin_session")
    if not token:
        raise HTTPException(401, "Administrator sign-in required.")
    try:
        email = admin_signer.loads(token, max_age=7 * 24 * 3600)["email"]
    except (BadSignature, SignatureExpired, KeyError):
        raise HTTPException(401, "Administrator session expired. Sign in again.")
    now = time.time()
    idle_seconds = int(store.settings().get("admin_idle_minutes", 15)) * 60
    last_seen = admin_session_activity.get(token)
    if last_seen is None or now - last_seen > idle_seconds:
        admin_session_activity.pop(token, None)
        raise HTTPException(401, "Administrator session expired after inactivity.")
    admin_session_activity[token] = now
    user = store.one("users", email)
    if not user or not user["active"] or user["role"] != "admin":
        raise HTTPException(403, "Administrator access required.")
    return email


def authorization_for(email: str):
    """Authorize an active domain OR an explicitly active username."""
    email = email.strip().lower()
    if email.count("@") != 1:
        return None, None
    domain = store.one("domains", email.rsplit("@", 1)[1])
    user = store.one("users", email)
    active_domain = domain if domain and domain["active"] else None
    active_user = user if user and user["active"] else None
    return active_domain, active_user


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.update({"Cache-Control": "no-store", "Pragma": "no-cache", "X-Content-Type-Options": "nosniff",
                             "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
                             "Content-Security-Policy": "default-src 'self'; style-src 'self'; script-src 'self'"})
    return response


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    domains = [x["domain"] for x in store.snapshot()["domains"] if x["active"]]
    return templates.TemplateResponse(request, "index.html", {"allowed_domains": ", ".join("@" + d for d in domains),
                                      "delivery_domain": settings.delivery_domain, "mock": settings.app_mode == "mock"})


@app.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request):
    try:
        require_admin(request)
    except HTTPException:
        return RedirectResponse("/admin/login", status_code=303)
    return templates.TemplateResponse(request, "admin.html", {})


@app.get("/admin/login", response_class=HTMLResponse)
async def admin_login_page(request: Request):
    try:
        require_admin(request)
        return RedirectResponse("/admin", status_code=303)
    except HTTPException:
        return templates.TemplateResponse(request, "admin_login.html", {"mock": settings.app_mode == "mock"})


@app.post("/api/admin/auth/request-code")
async def admin_request_code(payload: EmailRequest):
    email = payload.email.strip().lower()
    user = store.one("users", email)
    if not user or not user["active"] or user["role"] != "admin":
        store.add_audit(user_email=email or "unknown", action="admin_login", status="failed",
                        detail="unauthorized_admin")
        raise HTTPException(403, "This account is not an active administrator.")
    runtime = store.settings()
    code = codes.issue("admin:" + email, int(runtime.get("admin_otp_minutes", 10)))
    if runtime.get("production_enabled"):
        if not runtime.get("relay_enabled"):
            raise HTTPException(503, "Email relay must be enabled for administrator sign-in.")
        await send_code(settings, email, code, runtime)
    body = {"message": f"Administrator code sent to {email}."}
    if not runtime.get("production_enabled"):
        body["development_code"] = code
        body["message"] = "Local development code generated."
    return body


@app.post("/api/admin/auth/verify")
async def admin_verify(payload: VerifyRequest, request: Request):
    email = payload.email.strip().lower()
    user = store.one("users", email)
    if not user or not user["active"] or user["role"] != "admin":
        raise HTTPException(403, "Administrator access required.")
    if not codes.verify("admin:" + email, payload.code):
        store.add_audit(user_email=email, action="admin_login", status="failed", detail="invalid_code")
        raise HTTPException(401, "Invalid or expired administrator code.")
    store.add_audit(user_email=email, action="admin_login", status="success")
    response = JSONResponse({"message": "Administrator signed in."})
    token = admin_signer.dumps({"email": email})
    admin_session_activity[token] = time.time()
    response.set_cookie("ssl_admin_session", token, httponly=True,
                        secure=request.url.scheme == "https", samesite="strict",
                        max_age=7 * 24 * 3600, path="/")
    return response


@app.post("/api/admin/auth/logout")
async def admin_logout(request: Request):
    token = request.cookies.get("ssl_admin_session")
    try:
        actor = require_admin(request)
        store.add_audit(user_email=actor, action="admin_logout", status="success")
    except HTTPException:
        pass
    if token:
        admin_session_activity.pop(token, None)
    response = JSONResponse({"message": "Signed out."})
    response.delete_cookie("ssl_admin_session", path="/")
    return response


@app.post("/api/auth/request-code")
async def request_code(payload: EmailRequest):
    email = payload.email.strip().lower()
    domain, user = authorization_for(email)
    if not domain and not user:
        store.add_audit(user_email=email or "unknown", action="user_otp_request", status="failed",
                        detail="unauthorized_email")
        raise HTTPException(403, "This email address is not authorized for this portal.")
    runtime = store.settings()
    code = codes.issue(email, int(runtime.get("user_otp_minutes", 15)))
    recipient = delivery_address(email, domain["delivery_domain"]) if domain else email
    is_admin = bool(user and user.get("role") == "admin")
    if runtime.get("production_enabled") and not is_admin and not runtime.get("relay_enabled"):
        store.add_audit(user_email=email, action="user_otp_request", status="failed",
                        detail="email_relay_disabled")
        raise HTTPException(503, "Email relay is disabled. Contact an administrator.")
    try:
        if not is_admin:
            await send_code(settings, recipient, code, runtime)
    except Exception as exc:
        store.add_audit(user_email=email, action="user_otp_request", status="failed",
                        detail=f"delivery_error={type(exc).__name__}")
        raise HTTPException(502, "Unable to deliver the one-time code. Contact an administrator.") from exc
    store.add_audit(user_email=email, action="user_otp_request", status="success",
                    detail="delivery=screen" if is_admin or not runtime.get("production_enabled") else "delivery=email")
    body = {"message": ("Administrator code generated on screen." if is_admin
                         else f"Code sent to {recipient}.")}
    if is_admin or not runtime.get("production_enabled"):
        body["development_code"] = code
    return body


@app.post("/api/auth/verify")
async def verify(payload: VerifyRequest, request: Request):
    email = payload.email.strip().lower()
    domain, user = authorization_for(email)
    if not domain and not user:
        store.add_audit(user_email=email or "unknown", action="user_login", status="failed",
                        detail="unauthorized_email")
        raise HTTPException(403, "This email address is not authorized for this portal.")
    if not codes.verify(email, payload.code):
        store.add_audit(user_email=email, action="user_login", status="failed",
                        detail="invalid_or_expired_code")
        raise HTTPException(401, "Invalid or expired code.")
    store.add_audit(user_email=email, action="user_login", status="success")
    response = JSONResponse({"message": "Signed in."})
    token = signer.dumps({"email": email})
    session_activity[token] = time.time()
    response.set_cookie("ssl_session", token, httponly=True,
                        secure=request.url.scheme == "https",
                        samesite="strict", max_age=7 * 24 * 3600)
    return response


@app.post("/api/auth/logout")
async def user_logout(request: Request):
    token = request.cookies.get("ssl_session")
    try:
        actor = session_email(request)
        store.add_audit(user_email=actor, action="user_logout", status="success")
    except HTTPException:
        pass
    if token:
        session_activity.pop(token, None)
    response = JSONResponse({"message": "Signed out."})
    response.delete_cookie("ssl_session", path="/")
    return response


@app.get("/api/options")
async def options(request: Request):
    email = session_email(request)
    user = store.one("users", email)
    subscriptions, regions = store.active_options()
    runtime = store.settings()
    policy_requires_comparison = any(runtime.get(key, False) for key in (
        "live_compare_block_issuer_mismatch", "live_compare_block_missing_names",
        "live_compare_block_same_serial"))
    return {"subscriptions": subscriptions, "regions": regions,
            "certificate_fields": runtime.get("certificate_fields", []),
            "production_enabled": runtime.get("production_enabled", False),
            "approved_ticket_required": runtime.get("approved_ticket_required", False),
            "live_compare_enabled": runtime.get("live_compare_enabled", True),
            "live_compare_required": runtime.get("live_compare_required", False) or policy_requires_comparison,
            "is_admin": bool(user and user["active"] and user["role"] == "admin")}


def _decode_certificate(content_b64: str) -> bytes:
    raw = base64.b64decode(content_b64, validate=True)
    if not raw or len(raw) > settings.max_cert_bytes:
        raise ValueError(f"Certificate must be between 1 byte and {settings.max_cert_bytes} bytes.")
    return raw


@app.post("/api/inspect")
async def inspect(payload: InspectRequest, request: Request):
    actor = session_email(request)
    if not store.settings().get("memory_relay_enabled", True):
        store.add_audit(user_email=actor, action="inspect", status="failed",
                        detail="memory_relay_disabled")
        raise HTTPException(503, "In-memory certificate relay is disabled by an administrator.")
    raw = b""
    try:
        raw = _decode_certificate(payload.content_b64)
        metadata = inspect_certificate(raw, payload.filename, payload.password)
        naming = store.next_certificate_name(metadata["common_name"])
        store.add_audit(user_email=actor, action="inspect", status="success")
        return {"metadata": metadata, "generated_name": naming["name"],
                "previous_name": naming["previous_name"], "previous_count": naming["previous_count"],
                "display_fields": store.settings().get("certificate_fields", [])}
    except Exception as exc:
        store.add_audit(user_email=actor, action="inspect", status="failed",
                        detail=f"certificate_processing_error:{type(exc).__name__}")
        raise HTTPException(400, str(exc))
    finally:
        raw = b""
        payload.password = ""
        payload.content_b64 = ""


@app.post("/api/compare-live")
async def compare_live(payload: CompareLiveRequest, request: Request):
    actor = session_email(request)
    runtime = store.settings()
    if not runtime.get("memory_relay_enabled", True):
        store.add_audit(user_email=actor, action="compare_live", status="failed",
                        detail="memory_relay_disabled")
        raise HTTPException(503, "In-memory certificate relay is disabled by an administrator.")
    if not runtime.get("live_compare_enabled", True):
        store.add_audit(user_email=actor, action="compare_live", status="failed",
                        detail="live_comparison_disabled")
        raise HTTPException(503, "Live certificate comparison is disabled by an administrator.")
    raw = b""
    try:
        raw = _decode_certificate(payload.content_b64)
        new_metadata = inspect_certificate(raw, payload.filename, payload.password)
        live_cert = await run_in_threadpool(
            fetch_live_certificate, payload.fqdn, port=payload.port,
            timeout=int(runtime.get("live_compare_timeout_seconds", 5)),
            allowed_suffixes=runtime.get("live_compare_allowed_suffixes", ["bsc.bscal.com"]),
            allow_private=bool(runtime.get("live_compare_allow_private", True)),
        )
        result = compare_metadata(payload.fqdn.strip().lower().rstrip("."), live_metadata(live_cert), new_metadata)
        result["transfer_blockers"] = comparison_policy_blockers(result, runtime)
        result["transfer_allowed"] = not result["transfer_blockers"]
        result["comparison_token"] = comparison_signer.dumps({
            "email": actor, "thumbprint": new_metadata["sha256_thumbprint"], "fqdn": result["fqdn"],
            "issuer_matches": result["issuer_matches"],
            "missing_in_new": result["missing_in_new"],
            "serial_numbers_match": result["serial_numbers_match"],
        })
        store.add_audit(user_email=actor, action="compare_live", status="success",
                        detail=f"comparison_complete;missing_names={len(result['missing_in_new'])};result={result['result']}")
        return result
    except Exception as exc:
        store.add_audit(user_email=actor, action="compare_live", status="failed",
                        detail=f"comparison_error:{type(exc).__name__}")
        raise HTTPException(400, str(exc))
    finally:
        raw = b""
        payload.password = ""
        payload.content_b64 = ""


def _resolve(payload, request):
    session_email(request)
    subscriptions, regions = store.active_options()
    subs = {s["id"]: s for s in subscriptions}
    if payload.subscription_id not in subs or payload.region not in {r["token"] for r in regions}:
        raise HTTPException(400, "Invalid subscription or region.")
    sub = subs[payload.subscription_id]
    vaults = store.matching_vaults(payload.subscription_id, payload.region)
    if not vaults:
        raise HTTPException(404, "No active Key Vault is configured for this subscription and region.")
    return sub, vaults


@app.post("/api/resolve-vault")
async def resolve_vault(payload: ResolveRequest, request: Request):
    actor = session_email(request)
    try:
        sub, vaults = _resolve(payload, request)
        store.add_audit(user_email=actor, action="destination_lookup", status="success",
                        subscription_name=sub["name"], region=payload.region,
                        detail=f"matching_vaults={len(vaults)}")
        return {"subscription": sub["name"], "region": payload.region, "vaults": vaults}
    except HTTPException as exc:
        store.add_audit(user_email=actor, action="destination_lookup", status="failed",
                        region=payload.region, detail=str(exc.detail))
        raise


@app.post("/api/upload")
async def upload(payload: UploadRequest, request: Request):
    actor = session_email(request)
    if not store.settings().get("memory_relay_enabled", True):
        store.add_audit(user_email=actor, action="transfer", status="failed",
                        detail="memory_relay_disabled")
        raise HTTPException(503, "In-memory certificate relay is disabled by an administrator.")
    sub, vaults = _resolve(payload, request)
    vault = payload.confirmation_vault
    if vault not in vaults:
        store.add_audit(user_email=actor, action="transfer", status="failed",
                        subscription_name=sub["name"], region=payload.region,
                        vault_name=vault, detail="destination_not_allowed")
        raise HTTPException(409, "Selected vault is not an allowed subscription/region match. Review again.")
    raw = b""
    prepared = None
    try:
        raw = _decode_certificate(payload.content_b64)
        prepared = prepare_as_pfx(raw, payload.filename, payload.password)
        naming = store.next_certificate_name(prepared.common_name)
        cert_name = safe_certificate_name(naming["name"])
        runtime = store.settings()
        ticket_number = payload.ticket_number.strip().upper()
        if runtime.get("approved_ticket_required", False) and not ticket_number:
            raise ValueError("An approved ticket number is required before certificate transfer.")
        if ticket_number and not re.fullmatch(r"[A-Z0-9][A-Z0-9._:/-]{0,99}", ticket_number):
            raise ValueError("Ticket number may contain letters, numbers, periods, underscores, colons, slashes, and hyphens (maximum 100 characters).")
        policy_requires_comparison = any(runtime.get(key, False) for key in (
            "live_compare_block_issuer_mismatch", "live_compare_block_missing_names",
            "live_compare_block_same_serial"))
        if runtime.get("live_compare_required", False) or policy_requires_comparison:
            if not payload.comparison_token:
                raise ValueError("A live certificate comparison is required before transfer.")
            try:
                comparison = comparison_signer.loads(payload.comparison_token, max_age=15 * 60)
            except (BadSignature, SignatureExpired, KeyError) as exc:
                raise ValueError("The live comparison expired or is invalid. Compare again.") from exc
            if comparison.get("email") != actor or comparison.get("thumbprint") != prepared.metadata["sha256_thumbprint"]:
                raise ValueError("The uploaded certificate does not match the completed live comparison.")
            enforcement_result = {
                "issuer_matches": comparison.get("issuer_matches", False),
                "missing_in_new": comparison.get("missing_in_new", []),
                "serial_numbers_match": comparison.get("serial_numbers_match", False),
            }
            blockers = comparison_policy_blockers(enforcement_result, runtime)
            if blockers:
                raise ValueError(" ".join(blockers))
        result = azure.relay_certificate(vault, cert_name, prepared.pfx, prepared.password,
                                         bool(runtime.get("production_enabled")),
                                         runtime.get("managed_identity_type", "system"),
                                         runtime.get("managed_identity_client_id", ""))
        if runtime.get("production_enabled"):
            store.add_certificate_history(common_name=prepared.common_name, generated_name=cert_name,
                                          user_email=actor, subscription_name=sub["name"],
                                          region=payload.region, vault_name=vault,
                                          ticket_number=ticket_number)
        store.add_audit(user_email=actor, action="transfer", status="success", subscription_name=sub["name"],
                        region=payload.region, vault_name=vault)
        log.info("certificate_import actor=%s subscription=%s region=%s vault=%s time=%s",
                 actor, sub["name"], payload.region, vault, datetime.now(timezone.utc).isoformat())
        return {"status": "complete", "vault": vault, "certificate": cert_name,
                "previous_certificate": naming["previous_name"], "version": naming["sequence"],
                "common_name": prepared.common_name, "expires_utc": prepared.expires_utc,
                "azure_id": result["id"]}
    except Exception as exc:
        store.add_audit(user_email=actor, action="transfer", status="failed",
                        subscription_name=sub["name"], region=payload.region, vault_name=vault,
                        detail=f"transfer_error:{type(exc).__name__}")
        raise HTTPException(400, str(exc))
    finally:
        raw = b""
        prepared = None
        payload.password = ""
        payload.content_b64 = ""


@app.get("/api/admin/config")
async def admin_config(request: Request):
    require_admin(request)
    return store.snapshot()


@app.post("/api/admin/settings")
async def admin_settings(payload: dict, request: Request):
    require_admin(request)
    try:
        store.update_settings(payload)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"status": "saved", "settings": store.settings()}


@app.post("/api/admin/test-identity")
async def admin_test_identity(payload: IdentityTestRequest, request: Request):
    require_admin(request)
    runtime = store.settings()
    try:
        azure.test_managed_identity(payload.vault_name, runtime.get("managed_identity_type", "system"),
                                    runtime.get("managed_identity_client_id", ""))
        return {"status": "success"}
    except Exception as exc:
        raise HTTPException(400, f"Managed identity test failed: {type(exc).__name__}")


@app.post("/api/admin/audit/clear")
async def admin_clear_audit(request: Request):
    require_admin(request)
    store.clear_audit()
    return {"status": "cleared"}


@app.get("/api/admin/certificate-history")
async def admin_certificate_history(request: Request, q: str = ""):
    require_admin(request)
    return {"rows": store.search_certificate_history(q)}


@app.post("/api/admin/domains")
async def admin_domain(payload: DomainAdmin, request: Request):
    require_admin(request)
    store.upsert("domains", {"domain": payload.domain.strip().lower().lstrip("@"),
                             "delivery_domain": payload.delivery_domain.strip().lower().lstrip("@"), "active": 1})
    return {"status": "saved"}


@app.post("/api/admin/users")
async def admin_user(payload: UserAdmin, request: Request):
    require_admin(request)
    email = payload.email.strip().lower()
    if email.count("@") != 1:
        raise HTTPException(400, "Enter a valid email address.")
    store.upsert("users", {"email": email, "role": payload.role, "active": 1})
    return {"status": "saved"}


@app.post("/api/admin/subscriptions")
async def admin_subscription(payload: SubscriptionAdmin, request: Request):
    require_admin(request)
    try:
        store.save_subscription(payload.id, payload.name, payload.environment, payload.original_id)
    except (ValueError, sqlite3.IntegrityError) as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"status": "saved"}


@app.post("/api/admin/regions")
async def admin_region(payload: RegionAdmin, request: Request):
    require_admin(request)
    try:
        store.save_region(payload.token, payload.display_name, payload.original_token)
    except (ValueError, sqlite3.IntegrityError) as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"status": "saved"}


@app.post("/api/admin/vaults")
async def admin_vault(payload: VaultAdmin, request: Request):
    require_admin(request)
    try:
        store.save_vault(payload.name, payload.subscription_id, payload.region, payload.original_name)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except sqlite3.IntegrityError as exc:
        raise HTTPException(400, "Select an existing subscription and region.") from exc
    return {"status": "saved"}


@app.post("/api/admin/active")
async def admin_active(payload: ActiveAdmin, request: Request):
    actor = require_admin(request)
    if payload.table == "users" and payload.key.lower() == actor and not payload.active:
        raise HTTPException(400, "You cannot deactivate your own administrator account.")
    try:
        store.set_active(payload.table, payload.key, payload.active)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"status": "saved"}


@app.post("/api/admin/delete")
async def admin_delete(payload: DeleteAdmin, request: Request):
    actor = require_admin(request)
    if payload.table == "users" and payload.key.lower() == actor:
        raise HTTPException(400, "You cannot delete your own administrator account.")
    try:
        store.delete(payload.table, payload.key)
    except (ValueError, sqlite3.IntegrityError) as exc:
        raise HTTPException(400, str(exc)) from exc
    store.add_audit(user_email=actor, action="admin_configuration_delete", status="success",
                    detail=f"type={payload.table}")
    return {"status": "deleted"}
