# CertRelay Configuration Runbook

Written by AM

This runbook completes the configuration after the portal files and Python dependencies are installed on a Windows Azure VM. It covers SMTP OTP email delivery, Azure managed identity, IIS access through the VM IP on ports 80 and 443, and installation of the IIS TLS certificate when it becomes available.

The final traffic path is:

```text
Remote client -> IIS port 80 or 443 -> 127.0.0.1:8000 -> FastAPI portal
```

Port 8000 remains private to the VM and must not be opened through Windows Firewall or the Azure NSG.

# 1 Configure SMTP OTP Email Delivery

## 1.1 Obtain the required SMTP information

Request the following information from the company email or Exchange team:

1. SMTP relay FQDN, such as `smtp-relay.example.internal`.
2. SMTP port. The company currently uses port 25.
3. Whether STARTTLS is required or supported on port 25.
4. Whether the relay authenticates the VM by source IP or requires a username and password.
5. Approved sender address, such as `sslrelay@blueshieldca.com`.
6. Confirmation that the relay can deliver to `blueshieldca.com` and `bse.bscal.com`.
7. Confirmation that the VM or NAT source IP is permitted to relay.

Do not invent a sender address. The SMTP team must permit the portal to send using that address.

## 1.2 Configure the environment file

Stop the portal with `Ctrl+C`, then open the environment file:

```powershell
Set-Location C:\SSLKeyVaultMVP\Project
notepad .env
```

For a typical IP-authorized company relay on port 25 without STARTTLS:

```text
SMTP_HOST=<approved-company-relay-FQDN>
SMTP_PORT=25
SMTP_USERNAME=
SMTP_PASSWORD=
SMTP_FROM=CertRelay <sslrelay@blueshieldca.com>
SMTP_STARTTLS=false
```

If the SMTP team confirms STARTTLS is required, use:

```text
SMTP_STARTTLS=true
```

If authentication is required, enter the approved service credential in `.env`:

```text
SMTP_USERNAME=<approved-service-account>
SMTP_PASSWORD=<approved-secret>
```

Restrict access to `.env` because it may contain an SMTP password:

```powershell
icacls "C:\SSLKeyVaultMVP\Project\.env" /inheritance:r
icacls "C:\SSLKeyVaultMVP\Project\.env" /grant:r "Administrators:F" "SYSTEM:F"
```

Do not place certificates, certificate passwords, private keys, preshared keys, or Azure client secrets in `.env`.

## 1.3 Configure SMTP in the Admin Portal

Open the protected Admin Portal and configure:

```text
Enable OTP email relay for regular users: Checked
SMTP Relay host: <approved-company-relay-FQDN>
SMTP port: 25
Sender address: CertRelay <sslrelay@blueshieldca.com>
Use STARTTLS: Checked only when required by the SMTP team
```

Click **Save operational settings**.

The current MVP also requires **Enable production transfers** for email delivery. Keep it enabled only after Key Vault destinations and permissions are correct. Do not press the final certificate-transfer button during SMTP-only testing.

## 1.4 Test DNS and port 25

```powershell
$SmtpHost = "<approved-company-relay-FQDN>"

Resolve-DnsName $SmtpHost
Test-NetConnection $SmtpHost -Port 25
```

Required result:

```text
TcpTestSucceeded : True
```

If the test fails, check DNS, Windows Firewall, Azure NSG, UDR, Azure Firewall, and the SMTP relay allowlist.

## 1.5 Restart and test OTP delivery

```powershell
Set-Location C:\SSLKeyVaultMVP\Project
.\Start-Portal.ps1
```

Use a regular-user account to request an OTP. Verify the mapped recipient address carefully. For example, an administrator-defined domain mapping may route:

```text
user@blueshieldca.com -> user@bse.bscal.com
```

Check the inbox, junk folder, quarantine, and Exchange message tracking. Use `/admin/login` when testing an administrator OTP.

# 2 Configure Azure Managed Identity

Use only one of the following identity models. System-assigned identity is simplest when the VM already has the required Key Vault role.

## 2.1 Enable the VM system-assigned identity

In Azure Portal:

1. Open the Azure VM.
2. Select **Identity**.
3. Select **System assigned**.
4. Set **Status** to **On**.
5. Select **Save**.
6. Record the displayed Object Principal ID for RBAC verification only.

In the portal Admin page configure:

```text
Managed identity type: VM system-assigned
User-assigned client ID: Leave blank
```

No Azure username, password, tenant secret, or client secret is required.

## 2.2 Assign Key Vault permissions

For every approved destination vault:

1. Open the Key Vault in Azure Portal.
2. Select **Access control IAM**.
3. Select **Add role assignment**.
4. Select **Key Vault Certificates Officer**.
5. Select **Managed identity** as the member type.
6. Select the VM system-assigned identity.
7. Review and assign the role.

Use the narrowest scope possible. Assign the role on approved Key Vaults rather than the entire subscription.

The VM must also have DNS and TCP 443 connectivity to the Key Vault endpoint. If the vault uses a private endpoint, verify private DNS, routing, NSGs, and Azure Firewall policy.

## 2.3 Optional user-assigned identity

Use this only when the organization provides a dedicated user-assigned managed identity.

In Azure Portal:

1. Create or open the user-assigned managed identity.
2. Attach it to the VM under **VM > Identity > User assigned**.
3. Assign **Key Vault Certificates Officer** to that identity on each approved vault.
4. Open the identity Overview page.
5. Copy its **Client ID**.

In the Admin Portal configure:

```text
Managed identity type: User-assigned
User-assigned client ID: <Client ID>
```

Do not enter the Object ID, Principal ID, resource ID, subscription ID, or tenant ID in the client-ID field.

## 2.4 Test the VM identity token

Run this only from the Azure VM:

```powershell
$Response = Invoke-RestMethod `
    -Headers @{Metadata="true"} `
    -Method GET `
    -Uri "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net"

$Response | Select-Object token_type,expires_in
```

Do not print, copy, or save the access token.

Then select an approved vault in Admin Portal and click **Test managed identity**. A successful test displays:

```text
Managed identity access succeeded.
```

# 3 Revert Uvicorn and Configure IIS

## 3.1 Revert Start Portal

Uvicorn must not listen on the VM IP, `0.0.0.0`, or `*` in the final design. IIS is the public listener.

Open the script:

```powershell
notepad C:\SSLKeyVaultMVP\Project\Start-Portal.ps1
```

Replace the Uvicorn command with:

```powershell
& $VenvPython -m uvicorn app.main:app `
    --host 127.0.0.1 `
    --port 8000 `
    --workers 1 `
    --proxy-headers `
    --forwarded-allow-ips 127.0.0.1
```

Save the file, stop the old process with `Ctrl+C`, and restart:

```powershell
Set-Location C:\SSLKeyVaultMVP\Project
.\Start-Portal.ps1
```

Verify that only loopback is listening:

```powershell
Get-NetTCPConnection -LocalPort 8000 -State Listen
Invoke-WebRequest http://127.0.0.1:8000 -UseBasicParsing
```

The listener must show `127.0.0.1:8000`.

## 3.2 Install IIS modules

Install IIS if needed:

```powershell
Install-WindowsFeature Web-Server,Web-Mgmt-Tools -IncludeManagementTools
```

Install these Microsoft x64 packages in this order:

1. URL Rewrite Module 2.1: `rewrite_amd64_en-US.msi`
   - Official Microsoft IIS download page: <https://www.iis.net/downloads/microsoft/url-rewrite>
   - Select the **x64** English installer named `rewrite_amd64_en-US.msi`.
2. Application Request Routing 3.0: `requestRouter_amd64.msi`
   - Official Microsoft IIS download page: <https://www.iis.net/downloads/microsoft/application-request-routing>
   - Select the **x64** installer named `requestRouter_amd64.msi`.

Download both installers from the Microsoft IIS pages above. Do not download these server modules from an unverified third-party website.

Example commands:

```powershell
Start-Process msiexec.exe `
    -ArgumentList '/i "C:\Install\rewrite_amd64_en-US.msi" /qn /norestart' `
    -Wait

Start-Process msiexec.exe `
    -ArgumentList '/i "C:\Install\requestRouter_amd64.msi" /qn /norestart' `
    -Wait
```

Restart IIS:

```powershell
iisreset
```

Verify the modules:

```powershell
& "$env:windir\System32\inetsrv\appcmd.exe" list modules |
    Select-String "Rewrite|RequestRouter|ApplicationRequestRouting"
```

## 3.3 Enable ARR reverse proxy

```powershell
$AppCmd = "$env:windir\System32\inetsrv\appcmd.exe"

& $AppCmd set config `
    /section:system.webServer/proxy `
    /enabled:true `
    /preserveHostHeader:true
```

## 3.4 Determine the VM IP

```powershell
Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object {
        $_.IPAddress -notlike "127.*" -and
        $_.IPAddress -notlike "169.254.*"
    } |
    Select-Object InterfaceAlias,IPAddress
```

Set the correct IP:

```powershell
$VmIp = "10.10.10.25"
```

Replace the example value throughout this runbook.

## 3.5 Back up the HTTPS web configuration

The supplied production configuration redirects HTTP to HTTPS. Back it up before temporary HTTP testing:

```powershell
Set-Location C:\SSLKeyVaultMVP\Project
Copy-Item .\web.config .\web.config-https-backup -Force
```

## 3.6 Create the temporary HTTP web configuration

Run this complete PowerShell block:

```powershell
@'
<?xml version="1.0" encoding="UTF-8"?>
<!-- Written by AM - Temporary HTTP configuration -->
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <clear />
        <rule name="Reverse proxy to SSL Relay" stopProcessing="true">
          <match url="(.*)" />
          <action type="Rewrite" url="http://127.0.0.1:8000/{R:1}" />
          <serverVariables>
            <set name="HTTP_X_FORWARDED_PROTO" value="http" />
          </serverVariables>
        </rule>
      </rules>
    </rewrite>
    <security>
      <requestFiltering removeServerHeader="true" />
    </security>
    <httpProtocol>
      <customHeaders>
        <remove name="X-Powered-By" />
      </customHeaders>
    </httpProtocol>
  </system.webServer>
</configuration>
'@ | Set-Content `
    -Path "C:\SSLKeyVaultMVP\Project\web.config" `
    -Encoding UTF8
```

## 3.7 Create the IIS port 80 site

```powershell
Import-Module WebAdministration

$VmIp = "10.10.10.25"
$PortalPath = "C:\SSLKeyVaultMVP\Project"
$AppCmd = "$env:windir\System32\inetsrv\appcmd.exe"

Stop-Website -Name "Default Web Site" -ErrorAction SilentlyContinue

if (Test-Path "IIS:\Sites\SSLRelayPortal") {
    Remove-Website -Name "SSLRelayPortal"
}

New-Website `
    -Name "SSLRelayPortal" `
    -PhysicalPath $PortalPath `
    -IPAddress $VmIp `
    -Port 80 `
    -HostHeader ""

& $AppCmd set config "SSLRelayPortal" `
    /section:system.webServer/rewrite/allowedServerVariables `
    /+"[name='HTTP_X_FORWARDED_PROTO']"

iisreset
```

## 3.8 Open port 80

On the VM:

```powershell
New-NetFirewallRule `
    -DisplayName "SSL Relay HTTP 80" `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 80 `
    -Action Allow `
    -ErrorAction SilentlyContinue
```

In the Azure NSG, allow TCP 80 only from approved internal client subnets. Do not open port 8000.

## 3.9 Test HTTP access

On the VM:

```powershell
$VmIp = "10.10.10.25"
Test-NetConnection $VmIp -Port 80
Invoke-WebRequest "http://$VmIp" -UseBasicParsing
```

On the remote client:

```powershell
Test-NetConnection 10.10.10.25 -Port 80
```

Then browse to:

```text
http://10.10.10.25
```

HTTP is for temporary connectivity and interface testing only. Do not submit real certificate files, passwords, private keys, or OTPs over unencrypted HTTP. Secure production cookies may not work correctly until HTTPS is configured.

# 4 Install and Bind the IIS TLS Certificate

Complete this section when the server certificate becomes available.

## 4.1 Validate certificate naming

For hostname access, the certificate SAN must include:

```text
certrelay.bsc.bscal.com
```

For IP access without a browser certificate warning, the SAN must also include the exact VM IP address. A normal DNS certificate does not validate `https://10.10.10.25` unless that IP is present in the SAN.

The recommended final URL is:

```text
https://certrelay.bsc.bscal.com
```

## 4.2 Copy and inspect the PFX

Copy the certificate to:

```text
C:\Install\certrelay-server.pfx
```

Do not store it in the portal project directory.

## 4.3 Import the PFX securely

```powershell
$PfxPath = "C:\Install\certrelay-server.pfx"
$PfxPassword = Read-Host "Enter the PFX password" -AsSecureString

$Certificate = Import-PfxCertificate `
    -FilePath $PfxPath `
    -CertStoreLocation "Cert:\LocalMachine\My" `
    -Password $PfxPassword

$Thumbprint = $Certificate.Thumbprint

$Certificate |
    Select-Object Subject,Thumbprint,NotBefore,NotAfter,HasPrivateKey
```

Required result:

```text
HasPrivateKey : True
```

## 4.4 Bind HTTPS using the VM IP

Use this binding only when IP access is required:

```powershell
Import-Module WebAdministration

$VmIp = "10.10.10.25"

New-WebBinding `
    -Name "SSLRelayPortal" `
    -Protocol https `
    -IPAddress $VmIp `
    -Port 443 `
    -HostHeader "" `
    -SslFlags 0

$HttpsBinding = Get-WebBinding `
    -Name "SSLRelayPortal" `
    -Protocol https

$HttpsBinding.AddSslCertificate($Thumbprint,"My")
```

## 4.5 Optional DNS hostname binding

After DNS is created:

```powershell
$PortalHost = "certrelay.bsc.bscal.com"

New-WebBinding `
    -Name "SSLRelayPortal" `
    -Protocol https `
    -IPAddress "*" `
    -Port 443 `
    -HostHeader $PortalHost `
    -SslFlags 1

(Get-WebBinding `
    -Name "SSLRelayPortal" `
    -Protocol https `
    -Port 443 `
    -HostHeader $PortalHost).AddSslCertificate($Thumbprint,"My")
```

## 4.6 Open port 443

```powershell
New-NetFirewallRule `
    -DisplayName "SSL Relay HTTPS 443" `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 443 `
    -Action Allow `
    -ErrorAction SilentlyContinue
```

In the Azure NSG, allow TCP 443 only from approved internal client subnets.

## 4.7 Restore HTTPS redirection

```powershell
Copy-Item `
    "C:\SSLKeyVaultMVP\Project\web.config-https-backup" `
    "C:\SSLKeyVaultMVP\Project\web.config" `
    -Force

iisreset
```

## 4.8 Test HTTPS

From the VM:

```powershell
$VmIp = "10.10.10.25"
Test-NetConnection $VmIp -Port 443
Invoke-WebRequest "https://$VmIp" -UseBasicParsing
```

From a remote client:

```powershell
Test-NetConnection 10.10.10.25 -Port 443
```

Test the appropriate browser URL:

```text
https://10.10.10.25
https://certrelay.bsc.bscal.com
```

If IP access produces a certificate-name warning, use the DNS hostname or obtain a certificate whose SAN contains the IP address.

## 4.9 Remove the PFX staging file

After the certificate is successfully imported and backed up according to company policy, securely remove the staging copy from `C:\Install` using the approved server file-handling process. Do not move it into the portal directory.

# 5 Final Verification

Run these checks:

```powershell
Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 8000 -State Listen
Get-Website -Name "SSLRelayPortal"
Get-WebBinding -Name "SSLRelayPortal"
Test-NetConnection 127.0.0.1 -Port 8000
Test-NetConnection $VmIp -Port 80
Test-NetConnection $VmIp -Port 443
```

Confirm:

1. Uvicorn listens only on `127.0.0.1:8000`.
2. IIS listens on ports 80 and 443.
3. Port 8000 is not allowed through Windows Firewall or the Azure NSG.
4. SMTP port 25 connectivity succeeds.
5. OTP email delivery succeeds.
6. Managed identity testing succeeds against an approved vault.
7. Regular users cannot access the Admin Portal.
8. Audit logs do not contain certificate bytes, certificate identifiers, passwords, private keys, preshared keys, or OTP values.
