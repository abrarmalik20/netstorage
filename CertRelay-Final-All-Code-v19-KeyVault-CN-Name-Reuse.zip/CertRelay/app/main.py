# Written by AM — CertRelay
import base64
import logging
import re
import sqlite3
import time
import csv
import io
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.concurrency import run_in_threadpool
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from pydantic import BaseModel, Field

from .azure_service import AzureService
from .assistant_service import external_answer, knowledge_match, redact
from .certificates import inspect_certificate, prepare_as_pfx
from .config import get_settings
from .config_store import ConfigStore
from .mailer import send_code, send_csv_report
from .live_compare import compare_metadata, comparison_policy_blockers, fetch_live_certificate, live_metadata
from .security import (OneTimeCodeStore, certificate_name_from_common_name,
                       delivery_address, normalize_authorized_email)
from .smp_service import verify_smp_ticket

settings = get_settings()
app = FastAPI(title="CertRelay", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")
codes = OneTimeCodeStore(settings.app_secret_key, settings.otp_ttl_hours)
signer = URLSafeTimedSerializer(settings.app_secret_key, salt="ssl-portal-session")
admin_signer = URLSafeTimedSerializer(settings.app_secret_key, salt="ssl-portal-admin-session")
comparison_signer = URLSafeTimedSerializer(settings.app_secret_key, salt="ssl-portal-live-comparison")
smp_signer = URLSafeTimedSerializer(settings.app_secret_key, salt="certrelay-smp-verification")
azure = AzureService(settings)
store = ConfigStore(settings.config_db_path, settings.initial_admin_email)
log = logging.getLogger("ssl_portal")


class EmailRequest(BaseModel):
    email: str


class VerifyRequest(BaseModel):
    email: str
    code: str = Field(pattern=r"^\d{6}$")


class ResolveRequest(BaseModel):
    subscription_id: str
    region: str


class CertificateNameResolveRequest(ResolveRequest):
    vault_name: str = Field(min_length=1, max_length=127)
    common_name: str = Field(min_length=1, max_length=255)


class UploadRequest(BaseModel):
    filename: str
    content_b64: str
    password: str = ""
    certificate_name: str = ""  # Compatibility only; server generates the final name.
    subscription_id: str
    region: str
    confirmation_vault: str
    comparison_token: str = ""
    ticket_number: str = ""
    smp_verification_token: str = ""


class InspectRequest(BaseModel):
    filename: str
    content_b64: str
    password: str = ""


class CompareLiveRequest(InspectRequest):
    fqdn: str
    port: int = Field(default=443, ge=1, le=65535)


class IdentityTestRequest(BaseModel):
    vault_name: str


class DomainAdmin(BaseModel):
    domain: str
    delivery_domain: str


class UserAdmin(BaseModel):
    email: str
    role: str = Field(pattern=r"^(admin|user)$")


class SubscriptionAdmin(BaseModel):
    id: str
    name: str
    environment: str
    original_id: str | None = None


class RegionAdmin(BaseModel):
    token: str
    display_name: str
    original_token: str | None = None


class VaultAdmin(BaseModel):
    name: str
    subscription_id: str
    region: str
    original_name: str | None = None


class ActiveAdmin(BaseModel):
    table: str
    key: str
    active: bool


class DeleteAdmin(BaseModel):
    table: str
    key: str


class SmpVerifyRequest(BaseModel):
    ticket_number: str
    subscription_id: str
    region: str
    vault_name: str


class ReportRequest(BaseModel):
    years: int = Field(ge=1, le=3)


class AssistantChatRequest(BaseModel):
    question: str = Field(min_length=2, max_length=4000)


class AssistantKnowledgeAdmin(BaseModel):
    id: int | None = None
    title: str = Field(min_length=1, max_length=200)
    content: str = Field(min_length=1, max_length=100000)
    audience: str = Field(pattern=r"^(all|user|admin)$")
    source_type: str = Field(pattern=r"^(qa|document)$")


class AssistantKnowledgeDelete(BaseModel):
    id: int


def _assistant_context(role: str, actor: str, question: str, runtime: dict):
    items = store.assistant_knowledge(role, "")
    matches = sorted(((knowledge_match(item, question), item) for item in items),
                     key=lambda value: value[0]["score"], reverse=True)
    best_match = matches[0][0] if matches else {"text": "", "score": 0, "confident": False}
    relevant = [(match, item) for match, item in matches if match["score"] > 0][:4]
    approved = "\n\n".join(f"[{item['title']}]\n{match['text'] or item['content'][:2500]}"
                             for match, item in relevant)
    operational = ""
    terms = question.lower()
    if runtime.get("ai_allow_audit_reports", True) and any(
            word in terms for word in ("audit", "login", "activity", "report", "history", "expire")):
        rows = store.audit_history()
        if role != "admin":
            rows = [row for row in rows if row["user_email"].lower() == actor.lower()]
        summary = rows[:25]
        operational = "Recent authorized audit metadata:\n" + "\n".join(
            f"{row['occurred_utc']} | {row['action']} | {row['status']} | {row.get('vault_name') or ''} | {row.get('detail') or ''}"
            for row in summary)
        if role == "admin" and any(word in terms for word in ("report", "history", "expire", "expiration")):
            certificates = store.certificate_report(3)[:50]
            operational += "\n\nAuthorized certificate report metadata:\n" + "\n".join(
                f"{row['generated_name']} | expires={row.get('expires_utc') or 'unknown'} | "
                f"imported={row['uploaded_utc']} | by={row['user_email']} | vault={row['vault_name']}"
                for row in certificates)
    return relevant, best_match, redact(
        (approved or "No matching approved knowledge was found.") + "\n\n" + operational)


async def _assistant_reply(role: str, actor: str, question: str):
    runtime = store.settings()
    enabled = runtime.get("admin_chatbot_enabled", False) if role == "admin" else runtime.get("user_chatbot_enabled", False)
    if not enabled:
        raise HTTPException(403, f"The {role} chatbot is disabled by an administrator.")
    relevant, best_match, context = _assistant_context(role, actor, question, runtime)
    mode = runtime.get("ai_answer_mode", "approved_plus_external")
    provider = runtime.get("ai_provider", "none")
    local = best_match["text"] if best_match.get("confident") else ""
    if mode == "approved_only" or provider == "none":
        answer = local or "I do not have an approved answer for that question. Please contact the CertRelay administrator."
        source = "approved_knowledge" if local else "no_match"
    elif mode == "external_fallback" and local:
        answer, source = local, "approved_knowledge"
    else:
        try:
            answer = await external_answer(provider, question, context, role, runtime)
            source = provider
        except Exception as exc:
            if local:
                answer, source = local, "approved_knowledge_fallback"
            else:
                answer = "I do not have an approved answer, and the external AI service is currently unavailable. Please contact the CertRelay administrator."
                source = "external_ai_unavailable"
    store.add_audit(user_email=actor, action=f"{role}_assistant", status="success",
                    detail=f"source={source}")
    return {"answer": answer, "source": source,
            "approved_sources": [item["title"] for match, item in relevant if match.get("confident")]}


def session_email(request: Request) -> str:
    token = request.cookies.get("ssl_session")
    if not token:
        raise HTTPException(401, "Sign in required.")
    try:
        email = signer.loads(token, max_age=7 * 24 * 3600)["email"]
    except (BadSignature, SignatureExpired, KeyError):
        raise HTTPException(401, "Session expired. Please sign in again.")
    idle_seconds = int(store.settings().get("user_idle_minutes", 15)) * 60
    if not store.touch_session(token, email, "user", idle_seconds):
        raise HTTPException(401, "Session expired after inactivity. Please sign in again.")
    return email


def require_admin(request: Request) -> str:
    token = request.cookies.get("ssl_admin_session")
    if not token:
        raise HTTPException(401, "Administrator sign-in required.")
    try:
        email = admin_signer.loads(token, max_age=7 * 24 * 3600)["email"]
    except (BadSignature, SignatureExpired, KeyError):
        raise HTTPException(401, "Administrator session expired. Sign in again.")
    idle_seconds = int(store.settings().get("admin_idle_minutes", 15)) * 60
    if not store.touch_session(token, email, "admin", idle_seconds):
        raise HTTPException(401, "Administrator session expired after inactivity.")
    user = store.one("users", email)
    if not user or not user["active"] or user["role"] != "admin":
        raise HTTPException(403, "Administrator access required.")
    return email


def authorization_for(email: str):
    """Authorize an active domain OR an explicitly active username."""
    email = email.strip().lower()
    if email.count("@") != 1:
        return None, None
    domain = store.one("domains", email.rsplit("@", 1)[1])
    user = store.one("users", email)
    active_domain = domain if domain and domain["active"] else None
    active_user = user if user and user["active"] else None
    return active_domain, active_user


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.update({"Cache-Control": "no-store", "Pragma": "no-cache", "X-Content-Type-Options": "nosniff",
                             "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
                             "Content-Security-Policy": "default-src 'self'; style-src 'self'; script-src 'self'"})
    return response


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    domains = [x["domain"] for x in store.snapshot()["domains"] if x["active"]]
    return templates.TemplateResponse(request, "index.html", {"allowed_domains": ", ".join("@" + d for d in domains),
                                      "delivery_domain": settings.delivery_domain, "mock": settings.app_mode == "mock"})


@app.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request):
    try:
        require_admin(request)
    except HTTPException:
        return RedirectResponse("/admin/login", status_code=303)
    return templates.TemplateResponse(request, "admin.html", {})


@app.get("/admin/login", response_class=HTMLResponse)
async def admin_login_page(request: Request):
    try:
        require_admin(request)
        return RedirectResponse("/admin", status_code=303)
    except HTTPException:
        return templates.TemplateResponse(request, "admin_login.html", {"mock": settings.app_mode == "mock"})


@app.post("/api/admin/auth/request-code")
async def admin_request_code(payload: EmailRequest):
    email = payload.email.strip().lower()
    user = store.one("users", email)
    if not user or not user["active"] or user["role"] != "admin":
        store.add_audit(user_email=email or "unknown", action="admin_login", status="failed",
                        detail="unauthorized_admin")
        raise HTTPException(403, "This account is not an active administrator.")
    runtime = store.settings()
    code = codes.issue("admin:" + email, int(runtime.get("admin_otp_minutes", 10)))
    if runtime.get("production_enabled"):
        if not runtime.get("relay_enabled"):
            raise HTTPException(503, "Email relay must be enabled for administrator sign-in.")
        await send_code(settings, email, code, runtime)
    body = {"message": f"Administrator code sent to {email}."}
    if not runtime.get("production_enabled"):
        body["development_code"] = code
        body["message"] = "Local development code generated."
    return body


@app.post("/api/admin/auth/verify")
async def admin_verify(payload: VerifyRequest, request: Request):
    email = payload.email.strip().lower()
    user = store.one("users", email)
    if not user or not user["active"] or user["role"] != "admin":
        raise HTTPException(403, "Administrator access required.")
    if not codes.verify("admin:" + email, payload.code):
        store.add_audit(user_email=email, action="admin_login", status="failed", detail="invalid_code")
        raise HTTPException(401, "Invalid or expired administrator code.")
    store.add_audit(user_email=email, action="admin_login", status="success")
    response = JSONResponse({"message": "Administrator signed in."})
    token = admin_signer.dumps({"email": email})
    store.create_session(token, email, "admin", 7 * 24 * 3600)
    response.set_cookie("ssl_admin_session", token, httponly=True,
                        secure=request.url.scheme == "https", samesite="strict",
                        max_age=7 * 24 * 3600, path="/")
    return response


@app.post("/api/admin/auth/logout")
async def admin_logout(request: Request):
    token = request.cookies.get("ssl_admin_session")
    try:
        actor = require_admin(request)
        store.add_audit(user_email=actor, action="admin_logout", status="success")
    except HTTPException:
        pass
    if token:
        store.delete_session(token)
    response = JSONResponse({"message": "Signed out."})
    response.delete_cookie("ssl_admin_session", path="/")
    return response


@app.post("/api/auth/request-code")
async def request_code(payload: EmailRequest):
    email = payload.email.strip().lower()
    domain, user = authorization_for(email)
    if not domain and not user:
        store.add_audit(user_email=email or "unknown", action="user_otp_request", status="failed",
                        detail="unauthorized_email")
        raise HTTPException(403, "This email address is not authorized for this portal.")
    runtime = store.settings()
    code = codes.issue(email, int(runtime.get("user_otp_minutes", 15)))
    recipient = delivery_address(email, domain["delivery_domain"]) if domain else email
    is_admin = bool(user and user.get("role") == "admin")
    if runtime.get("production_enabled") and not is_admin and not runtime.get("relay_enabled"):
        store.add_audit(user_email=email, action="user_otp_request", status="failed",
                        detail="email_relay_disabled")
        raise HTTPException(503, "Email relay is disabled. Contact an administrator.")
    try:
        if not is_admin:
            await send_code(settings, recipient, code, runtime)
    except Exception as exc:
        store.add_audit(user_email=email, action="user_otp_request", status="failed",
                        detail=f"delivery_error={type(exc).__name__}")
        raise HTTPException(502, "Unable to deliver the one-time code. Contact an administrator.") from exc
    store.add_audit(user_email=email, action="user_otp_request", status="success",
                    detail="delivery=screen" if is_admin or not runtime.get("production_enabled") else "delivery=email")
    body = {"message": ("Administrator code generated on screen." if is_admin
                         else f"Code sent to {recipient}.")}
    if is_admin or not runtime.get("production_enabled"):
        body["development_code"] = code
    return body


@app.post("/api/auth/verify")
async def verify(payload: VerifyRequest, request: Request):
    email = payload.email.strip().lower()
    domain, user = authorization_for(email)
    if not domain and not user:
        store.add_audit(user_email=email or "unknown", action="user_login", status="failed",
                        detail="unauthorized_email")
        raise HTTPException(403, "This email address is not authorized for this portal.")
    if not codes.verify(email, payload.code):
        store.add_audit(user_email=email, action="user_login", status="failed",
                        detail="invalid_or_expired_code")
        raise HTTPException(401, "Invalid or expired code.")
    store.add_audit(user_email=email, action="user_login", status="success")
    response = JSONResponse({"message": "Signed in."})
    token = signer.dumps({"email": email})
    store.create_session(token, email, "user", 7 * 24 * 3600)
    response.set_cookie("ssl_session", token, httponly=True,
                        secure=request.url.scheme == "https",
                        samesite="strict", max_age=7 * 24 * 3600)
    return response


@app.post("/api/auth/logout")
async def user_logout(request: Request):
    token = request.cookies.get("ssl_session")
    try:
        actor = session_email(request)
        store.add_audit(user_email=actor, action="user_logout", status="success")
    except HTTPException:
        pass
    if token:
        store.delete_session(token)
    response = JSONResponse({"message": "Signed out."})
    response.delete_cookie("ssl_session", path="/")
    return response


@app.get("/api/options")
async def options(request: Request):
    email = session_email(request)
    user = store.one("users", email)
    subscriptions, regions = store.active_options()
    runtime = store.settings()
    policy_requires_comparison = any(runtime.get(key, False) for key in (
        "live_compare_block_issuer_mismatch", "live_compare_block_missing_names",
        "live_compare_block_same_serial"))
    return {"subscriptions": subscriptions, "regions": regions,
            "user_email": email,
            "certificate_fields": runtime.get("certificate_fields", []),
            "production_enabled": runtime.get("production_enabled", False),
            "approved_ticket_required": runtime.get("approved_ticket_required", False),
            "certificate_name_append_year_sequence": False,
            "certificate_name_allow_custom": False,
            "user_chatbot_enabled": runtime.get("user_chatbot_enabled", False),
            "smp_enabled": runtime.get("smp_enabled", False),
            "smp_required": runtime.get("smp_required", False),
            "live_compare_enabled": runtime.get("live_compare_enabled", True),
            "live_compare_required": runtime.get("live_compare_required", False) or policy_requires_comparison,
            "is_admin": bool(user and user["active"] and user["role"] == "admin")}


@app.post("/api/assistant/chat")
async def user_assistant_chat(payload: AssistantChatRequest, request: Request):
    actor = session_email(request)
    return await _assistant_reply("user", actor, payload.question)


@app.post("/api/admin/assistant/chat")
async def admin_assistant_chat(payload: AssistantChatRequest, request: Request):
    actor = require_admin(request)
    return await _assistant_reply("admin", actor, payload.question)


def _decode_certificate(content_b64: str) -> bytes:
    raw = base64.b64decode(content_b64, validate=True)
    if not raw or len(raw) > settings.max_cert_bytes:
        raise ValueError(f"Certificate must be between 1 byte and {settings.max_cert_bytes} bytes.")
    return raw


@app.post("/api/inspect")
async def inspect(payload: InspectRequest, request: Request):
    actor = session_email(request)
    if not store.settings().get("memory_relay_enabled", True):
        store.add_audit(user_email=actor, action="inspect", status="failed",
                        detail="memory_relay_disabled")
        raise HTTPException(503, "In-memory certificate relay is disabled by an administrator.")
    raw = b""
    try:
        raw = _decode_certificate(payload.content_b64)
        metadata = inspect_certificate(raw, payload.filename, payload.password)
        runtime = store.settings()
        generated_name = certificate_name_from_common_name(metadata["common_name"])
        store.add_audit(user_email=actor, action="inspect", status="success")
        return {"metadata": metadata, "generated_name": generated_name,
                "previous_name": None, "previous_count": 0,
                "display_fields": runtime.get("certificate_fields", []),
                "allow_custom_name": False, "append_year_sequence": False}
    except Exception as exc:
        store.add_audit(user_email=actor, action="inspect", status="failed",
                        detail=f"certificate_processing_error:{type(exc).__name__}")
        raise HTTPException(400, str(exc))
    finally:
        raw = b""
        payload.password = ""
        payload.content_b64 = ""


@app.post("/api/compare-live")
async def compare_live(payload: CompareLiveRequest, request: Request):
    actor = session_email(request)
    runtime = store.settings()
    if not runtime.get("memory_relay_enabled", True):
        store.add_audit(user_email=actor, action="compare_live", status="failed",
                        detail="memory_relay_disabled")
        raise HTTPException(503, "In-memory certificate relay is disabled by an administrator.")
    if not runtime.get("live_compare_enabled", True):
        store.add_audit(user_email=actor, action="compare_live", status="failed",
                        detail="live_comparison_disabled")
        raise HTTPException(503, "Live certificate comparison is disabled by an administrator.")
    raw = b""
    try:
        raw = _decode_certificate(payload.content_b64)
        new_metadata = inspect_certificate(raw, payload.filename, payload.password)
        live_cert = await run_in_threadpool(
            fetch_live_certificate, payload.fqdn, port=payload.port,
            timeout=int(runtime.get("live_compare_timeout_seconds", 5)),
            allowed_suffixes=runtime.get("live_compare_allowed_suffixes", ["bsc.bscal.com"]),
            allow_private=bool(runtime.get("live_compare_allow_private", True)),
        )
        result = compare_metadata(payload.fqdn.strip().lower().rstrip("."), live_metadata(live_cert), new_metadata)
        result["transfer_blockers"] = comparison_policy_blockers(result, runtime)
        result["transfer_allowed"] = not result["transfer_blockers"]
        result["comparison_token"] = comparison_signer.dumps({
            "email": actor, "thumbprint": new_metadata["sha256_thumbprint"], "fqdn": result["fqdn"],
            "issuer_matches": result["issuer_matches"],
            "missing_in_new": result["missing_in_new"],
            "serial_numbers_match": result["serial_numbers_match"],
        })
        store.add_audit(user_email=actor, action="compare_live", status="success",
                        detail=f"comparison_complete;missing_names={len(result['missing_in_new'])};result={result['result']}")
        return result
    except Exception as exc:
        store.add_audit(user_email=actor, action="compare_live", status="failed",
                        detail=f"comparison_error:{type(exc).__name__}")
        raise HTTPException(400, str(exc))
    finally:
        raw = b""
        payload.password = ""
        payload.content_b64 = ""


def _resolve(payload, request):
    session_email(request)
    subscriptions, regions = store.active_options()
    subs = {s["id"]: s for s in subscriptions}
    if payload.subscription_id not in subs or payload.region not in {r["token"] for r in regions}:
        raise HTTPException(400, "Invalid subscription or region.")
    sub = subs[payload.subscription_id]
    vaults = store.matching_vaults(payload.subscription_id, payload.region)
    if not vaults:
        raise HTTPException(404, "No active Key Vault is configured for this subscription and region.")
    return sub, vaults


@app.post("/api/resolve-vault")
async def resolve_vault(payload: ResolveRequest, request: Request):
    actor = session_email(request)
    try:
        sub, vaults = _resolve(payload, request)
        store.add_audit(user_email=actor, action="destination_lookup", status="success",
                        subscription_name=sub["name"], region=payload.region,
                        detail=f"matching_vaults={len(vaults)}")
        return {"subscription": sub["name"], "region": payload.region, "vaults": vaults}
    except HTTPException as exc:
        store.add_audit(user_email=actor, action="destination_lookup", status="failed",
                        region=payload.region, detail=str(exc.detail))
        raise


async def _key_vault_certificate_name(vault_name: str, common_name: str, runtime: dict) -> dict:
    fallback = certificate_name_from_common_name(common_name)
    try:
        return await run_in_threadpool(
            azure.resolve_certificate_name, vault_name, common_name, fallback,
            bool(runtime.get("production_enabled")),
            runtime.get("managed_identity_type", "system"),
            runtime.get("managed_identity_client_id", ""),
        )
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError(
            "CertRelay could not inspect existing certificates in the selected Key Vault. "
            "Confirm that the VM managed identity has certificate List and Get permissions, "
            "then contact the Network Team if the problem continues."
        ) from exc


@app.post("/api/resolve-certificate-name")
async def resolve_certificate_name(payload: CertificateNameResolveRequest, request: Request):
    actor = session_email(request)
    sub, vaults = _resolve(payload, request)
    if payload.vault_name not in vaults:
        raise HTTPException(400, "The selected Key Vault is not an approved destination.")
    try:
        result = await _key_vault_certificate_name(
            payload.vault_name, payload.common_name, store.settings())
        store.add_audit(
            user_email=actor, action="certificate_name_lookup", status="success",
            subscription_name=sub["name"], region=payload.region,
            vault_name=payload.vault_name,
            detail="existing_name_reused" if result["matched_existing"] else "cn_name_selected",
        )
        return {"certificate_name": result["name"],
                "matched_existing": result["matched_existing"]}
    except ValueError as exc:
        store.add_audit(
            user_email=actor, action="certificate_name_lookup", status="failed",
            subscription_name=sub["name"], region=payload.region,
            vault_name=payload.vault_name, detail="name_lookup_failed",
        )
        raise HTTPException(400, str(exc)) from exc


@app.post("/api/smp/verify")
async def smp_verify(payload: SmpVerifyRequest, request: Request):
    actor = session_email(request)
    runtime = store.settings()
    if not runtime.get("smp_enabled", False):
        raise HTTPException(503, "SMP verification is disabled by an administrator.")
    ticket = payload.ticket_number.strip().upper()
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9._:/-]{0,99}", ticket):
        raise HTTPException(400, "Enter a valid SMP ticket number.")
    sub, vaults = _resolve(ResolveRequest(subscription_id=payload.subscription_id, region=payload.region), request)
    if payload.vault_name not in vaults:
        raise HTTPException(400, "The selected Key Vault is not an approved destination.")
    try:
        result = await verify_smp_ticket(ticket, runtime)
        mismatches = []
        for source_key, expected in (("subscription", sub["name"]), ("region", payload.region),
                                     ("key_vault", payload.vault_name)):
            actual = result.get(source_key)
            if actual and str(actual).lower() != str(expected).lower():
                mismatches.append(f"SMP {source_key.replace('_',' ')} does not match the selected destination.")
        if not result["approved"]:
            mismatches.append(f"SMP ticket status is {result['status']}; an approved status is required.")
        result["verification_errors"] = mismatches
        result["verified"] = not mismatches
        result["verification_token"] = (smp_signer.dumps({"email": actor, "ticket": ticket,
            "subscription_id": payload.subscription_id, "region": payload.region,
            "vault": payload.vault_name}) if result["verified"] else "")
        store.add_audit(user_email=actor, action="smp_verification",
                        status="success" if result["verified"] else "failed",
                        subscription_name=sub["name"], region=payload.region,
                        vault_name=payload.vault_name, detail=f"ticket={ticket};status={result['status']}")
        return result
    except HTTPException:
        raise
    except Exception as exc:
        store.add_audit(user_email=actor, action="smp_verification", status="failed",
                        detail=f"ticket={ticket};error={type(exc).__name__}")
        raise HTTPException(502, f"SMP verification failed: {type(exc).__name__}") from exc


@app.post("/api/upload")
async def upload(payload: UploadRequest, request: Request):
    actor = session_email(request)
    if not store.settings().get("memory_relay_enabled", True):
        store.add_audit(user_email=actor, action="transfer", status="failed",
                        detail="memory_relay_disabled")
        raise HTTPException(503, "In-memory certificate relay is disabled by an administrator.")
    sub, vaults = _resolve(payload, request)
    vault = payload.confirmation_vault
    if vault not in vaults:
        store.add_audit(user_email=actor, action="transfer", status="failed",
                        subscription_name=sub["name"], region=payload.region,
                        vault_name=vault, detail="destination_not_allowed")
        raise HTTPException(409, "Selected vault is not an allowed subscription/region match. Review again.")
    raw = b""
    prepared = None
    try:
        raw = _decode_certificate(payload.content_b64)
        prepared = prepare_as_pfx(raw, payload.filename, payload.password)
        runtime = store.settings()
        naming = await _key_vault_certificate_name(vault, prepared.common_name, runtime)
        cert_name = naming["name"]
        ticket_number = payload.ticket_number.strip().upper()
        if runtime.get("approved_ticket_required", False) and not ticket_number:
            raise ValueError("An approved ticket number is required before certificate transfer.")
        if ticket_number and not re.fullmatch(r"[A-Z0-9][A-Z0-9._:/-]{0,99}", ticket_number):
            raise ValueError("Ticket number may contain letters, numbers, periods, underscores, colons, slashes, and hyphens (maximum 100 characters).")
        if runtime.get("smp_required", False):
            if not payload.smp_verification_token:
                raise ValueError("SMP ticket verification is required before certificate transfer.")
            try:
                verified = smp_signer.loads(payload.smp_verification_token, max_age=15 * 60)
            except (BadSignature, SignatureExpired, KeyError) as exc:
                raise ValueError("The SMP verification expired or is invalid. Verify the ticket again.") from exc
            expected = {"email": actor, "ticket": ticket_number, "subscription_id": payload.subscription_id,
                        "region": payload.region, "vault": vault}
            if any(verified.get(key) != value for key, value in expected.items()):
                raise ValueError("The ticket or destination changed after SMP verification. Verify again.")
        policy_requires_comparison = any(runtime.get(key, False) for key in (
            "live_compare_block_issuer_mismatch", "live_compare_block_missing_names",
            "live_compare_block_same_serial"))
        if runtime.get("live_compare_required", False) or policy_requires_comparison:
            if not payload.comparison_token:
                raise ValueError("A live certificate comparison is required before transfer.")
            try:
                comparison = comparison_signer.loads(payload.comparison_token, max_age=15 * 60)
            except (BadSignature, SignatureExpired, KeyError) as exc:
                raise ValueError("The live comparison expired or is invalid. Compare again.") from exc
            if comparison.get("email") != actor or comparison.get("thumbprint") != prepared.metadata["sha256_thumbprint"]:
                raise ValueError("The uploaded certificate does not match the completed live comparison.")
            enforcement_result = {
                "issuer_matches": comparison.get("issuer_matches", False),
                "missing_in_new": comparison.get("missing_in_new", []),
                "serial_numbers_match": comparison.get("serial_numbers_match", False),
            }
            blockers = comparison_policy_blockers(enforcement_result, runtime)
            if blockers:
                raise ValueError(" ".join(blockers))
        result = azure.relay_certificate(vault, cert_name, prepared.pfx, prepared.password,
                                         bool(runtime.get("production_enabled")),
                                         runtime.get("managed_identity_type", "system"),
                                         runtime.get("managed_identity_client_id", ""))
        if runtime.get("production_enabled"):
            store.add_certificate_history(common_name=prepared.common_name, generated_name=cert_name,
                                          user_email=actor, subscription_name=sub["name"],
                                          region=payload.region, vault_name=vault,
                                          ticket_number=ticket_number,
                                          expires_utc=prepared.expires_utc)
        store.add_audit(user_email=actor, action="transfer", status="success", subscription_name=sub["name"],
                        region=payload.region, vault_name=vault)
        log.info("certificate_import actor=%s subscription=%s region=%s vault=%s time=%s",
                 actor, sub["name"], payload.region, vault, datetime.now(timezone.utc).isoformat())
        return {"status": "complete", "vault": vault, "certificate": cert_name,
                "previous_certificate": cert_name if naming["matched_existing"] else None,
                "version": None,
                "name_source": "existing_key_vault_certificate" if naming["matched_existing"] else "common_name",
                "common_name": prepared.common_name, "expires_utc": prepared.expires_utc,
                "azure_id": result["id"]}
    except Exception as exc:
        store.add_audit(user_email=actor, action="transfer", status="failed",
                        subscription_name=sub["name"], region=payload.region, vault_name=vault,
                        detail=f"transfer_error:{type(exc).__name__}")
        raise HTTPException(400, str(exc))
    finally:
        raw = b""
        prepared = None
        payload.password = ""
        payload.content_b64 = ""


@app.get("/api/admin/config")
async def admin_config(request: Request):
    actor = require_admin(request)
    result = store.snapshot()
    result["current_admin"] = actor
    return result


@app.post("/api/admin/settings")
async def admin_settings(payload: dict, request: Request):
    require_admin(request)
    try:
        store.update_settings(payload)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"status": "saved", "settings": store.settings()}


@app.post("/api/admin/assistant/knowledge")
async def admin_save_assistant_knowledge(payload: AssistantKnowledgeAdmin, request: Request):
    actor = require_admin(request)
    try:
        item_id = store.save_assistant_knowledge(
            item_id=payload.id, title=payload.title, content=payload.content,
            audience=payload.audience, source_type=payload.source_type)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    store.add_audit(user_email=actor, action="assistant_knowledge_save", status="success",
                    detail=f"item_id={item_id}")
    return {"status": "saved", "id": item_id}


@app.post("/api/admin/assistant/knowledge/delete")
async def admin_delete_assistant_knowledge(payload: AssistantKnowledgeDelete, request: Request):
    actor = require_admin(request)
    try:
        store.delete_assistant_knowledge(payload.id)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    store.add_audit(user_email=actor, action="assistant_knowledge_delete", status="success",
                    detail=f"item_id={payload.id}")
    return {"status": "deleted"}


@app.post("/api/admin/test-identity")
async def admin_test_identity(payload: IdentityTestRequest, request: Request):
    require_admin(request)
    runtime = store.settings()
    try:
        result = azure.test_managed_identity(
            payload.vault_name, runtime.get("managed_identity_type", "system"),
            runtime.get("managed_identity_client_id", ""))
        return {"status": "success", **result}
    except Exception as exc:
        raise HTTPException(400, f"Managed identity test failed: {type(exc).__name__}")


@app.post("/api/admin/audit/clear")
async def admin_clear_audit(request: Request):
    require_admin(request)
    store.clear_audit()
    return {"status": "cleared"}


@app.get("/api/admin/certificate-history")
async def admin_certificate_history(request: Request, q: str = ""):
    require_admin(request)
    return {"rows": store.search_certificate_history(q)}


@app.get("/api/admin/certificate-report")
async def admin_certificate_report(request: Request, years: int = 1):
    require_admin(request)
    try:
        rows = store.certificate_report(years)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"years": years, "generated_utc": datetime.now(timezone.utc).isoformat(), "rows": rows}


@app.post("/api/admin/certificate-report/email")
async def admin_email_certificate_report(payload: ReportRequest, request: Request):
    actor = require_admin(request)
    runtime = store.settings()
    rows = store.certificate_report(payload.years)
    output = io.StringIO(newline="")
    columns = ["expires_utc", "uploaded_utc", "generated_name", "common_name",
               "ticket_number", "user_email", "subscription_name", "region", "vault_name"]
    writer = csv.DictWriter(output, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    filename = f"certrelay-certificate-report-{payload.years}-years.csv"
    try:
        await send_csv_report(settings, actor, filename, output.getvalue().encode("utf-8-sig"), runtime)
    except Exception as exc:
        store.add_audit(user_email=actor, action="certificate_report_email", status="failed",
                        detail=f"delivery_error={type(exc).__name__}")
        raise HTTPException(502, f"Unable to email the report: {type(exc).__name__}") from exc
    finally:
        output.close()
    store.add_audit(user_email=actor, action="certificate_report_email", status="success",
                    detail=f"range_years={payload.years};rows={len(rows)}")
    return {"status": "sent", "recipient": actor, "rows": len(rows)}


@app.post("/api/admin/domains")
async def admin_domain(payload: DomainAdmin, request: Request):
    require_admin(request)
    store.upsert("domains", {"domain": payload.domain.strip().lower().lstrip("@"),
                             "delivery_domain": payload.delivery_domain.strip().lower().lstrip("@"), "active": 1})
    return {"status": "saved"}


@app.post("/api/admin/users")
async def admin_user(payload: UserAdmin, request: Request):
    require_admin(request)
    email = payload.email.strip().lower()
    if email.count("@") != 1:
        raise HTTPException(400, "Enter a valid email address.")
    store.upsert("users", {"email": email, "role": payload.role, "active": 1})
    return {"status": "saved"}


@app.post("/api/admin/subscriptions")
async def admin_subscription(payload: SubscriptionAdmin, request: Request):
    require_admin(request)
    try:
        store.save_subscription(payload.id, payload.name, payload.environment, payload.original_id)
    except (ValueError, sqlite3.IntegrityError) as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"status": "saved"}


@app.post("/api/admin/regions")
async def admin_region(payload: RegionAdmin, request: Request):
    require_admin(request)
    try:
        store.save_region(payload.token, payload.display_name, payload.original_token)
    except (ValueError, sqlite3.IntegrityError) as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"status": "saved"}


@app.post("/api/admin/vaults")
async def admin_vault(payload: VaultAdmin, request: Request):
    require_admin(request)
    try:
        store.save_vault(payload.name, payload.subscription_id, payload.region, payload.original_name)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except sqlite3.IntegrityError as exc:
        raise HTTPException(400, "Select an existing subscription and region.") from exc
    return {"status": "saved"}


@app.post("/api/admin/active")
async def admin_active(payload: ActiveAdmin, request: Request):
    actor = require_admin(request)
    if payload.table == "users" and payload.key.lower() == actor and not payload.active:
        raise HTTPException(400, "You cannot deactivate your own administrator account.")
    try:
        store.set_active(payload.table, payload.key, payload.active)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"status": "saved"}


@app.post("/api/admin/delete")
async def admin_delete(payload: DeleteAdmin, request: Request):
    actor = require_admin(request)
    if payload.table == "users" and payload.key.lower() == actor:
        raise HTTPException(400, "You cannot delete your own administrator account.")
    try:
        store.delete(payload.table, payload.key)
    except (ValueError, sqlite3.IntegrityError) as exc:
        raise HTTPException(400, str(exc)) from exc
    store.add_audit(user_email=actor, action="admin_configuration_delete", status="success",
                    detail=f"type={payload.table}")
    return {"status": "deleted"}
